# Claude Skills Cashflow Pack

ขอบคุณที่ซื้อ Claude Skills Cashflow Pack ครับ ❤️
ในแพคนี้คุณจะได้รับ:

- **Skills/** — 967 Claude Skills จัดหมวด 30 หมวด ตามประเภทงานธุรกิจออนไลน์
- **Bonus E-books/** — Bonus E-book 5 เล่ม สำหรับเริ่มใช้ Claude แบบมืออาชีพ
- **README.md** — ไฟล์นี้

## วิธีใช้ Skill 1 ตัว (3 ขั้นตอน)

1. เปิด `Skills/<หมวด>/<ชื่อ-skill>.SKILL.md` ในโปรแกรมเปิดไฟล์ Markdown
   (VS Code, Obsidian, Notion, หรือ text editor ทั่วไป)
2. คัดลอกเนื้อหาในไฟล์ทั้งหมด (Cmd/Ctrl+A → Cmd/Ctrl+C)
3. วางใน Claude.ai (Cmd/Ctrl+V) แล้วใส่ข้อมูลธุรกิจของคุณตามที่ Skill ถาม

## เริ่มจาก 5 Skills ที่ใช้บ่อย

- Skills/01-content-social-media/cross-platform-repost.SKILL.md
- Skills/03-ads-performance-marketing/ad-copy-product-sell.SKILL.md
- Skills/09-sales-page-landing-page/sales-page-AIDA.SKILL.md
- Skills/05-ebook-digital-product/ebook-outline-writer.SKILL.md
- Skills/04-sales-closing/inbox-closing-script.SKILL.md

## หมวดทั้งหมด

01-content-social-media          คอนเทนต์ & โซเชียลมีเดีย
02-short-video-reels-tiktok      วิดีโอสั้น Reels/TikTok
03-ads-performance-marketing     โฆษณา & Performance
04-sales-closing                 งานขาย & ปิดการขาย
05-ebook-digital-product         E-book & สินค้าดิจิทัล
06-online-course                 คอร์สออนไลน์
07-business-strategy             Business Strategy
08-branding-personal-brand       Branding & Personal Brand
09-sales-page-landing-page       Sales Page / Landing Page
10-funnel-sales-system           Funnel & ระบบขาย
11-ai-image-prompt               ภาพ AI / Image Prompt
12-automation-workflow-sop       Workflow & SOP
13-customer-support-admin        Customer Support & แอดมิน
14-research-analysis             Research & Analysis
15-product-creation              Product Creation
16-community-membership          Community & Membership
17-email-marketing               Email Marketing
18-line-oa-broadcast             LINE OA & Broadcast
19-webinar-live-selling          Webinar & Live Selling
20-agency-freelancer             Agency & Freelancer
21-notion-docs-knowledge-base    Notion / Docs / KB
22-hr-team-assistant             HR & ผู้ช่วยทีม
23-legal-business-documents      เอกสารธุรกิจ
24-accounting-finance-pricing    บัญชี การเงิน ราคา
25-data-spreadsheet-report       Data / Spreadsheet / Report
26-youtube-podcast               YouTube & Podcast
27-seo-blog-website-content      SEO / Blog / เว็บคอนเทนต์
28-marketplace-ecommerce         Marketplace / E-commerce
29-review-testimonial-social-proof  Review / Testimonial
30-crisis-reputation-drama       Crisis & Reputation

## ติดต่อ / Support

ทักเพจ AI Content Cashflow ผ่าน Messenger:
https://m.me/61589052824806

ใช้งานติดตรงไหน ทักได้ทันที แอดมินช่วยดูแลให้จนใช้งานได้ครับ

## License

Pack นี้ใช้ส่วนตัวและสำหรับธุรกิจของผู้ซื้อเท่านั้น
ห้ามแจกจ่าย ขายต่อ หรือเปลี่ยนชื่อแล้วนำไปเผยแพร่
