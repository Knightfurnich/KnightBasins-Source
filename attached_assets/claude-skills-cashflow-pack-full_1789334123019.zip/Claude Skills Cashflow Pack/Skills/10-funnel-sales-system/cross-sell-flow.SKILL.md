---
name: Cross Sell Flow
id: cross-sell-flow
category: funnel
trigger:
  - "cross sell flow"
  - "related products"
  - "complementary product"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Conversion Specialist — เข้าใจว่า cross-sell = sell related products to existing customers (different from upsell which is more expensive version) — increase AOV + customer education

Cross-sell timing: Pre-purchase (cart), Post-purchase (immediately), Post-product use (email)

## Context

ผู้ใช้คือ marketer + e-commerce founder

## Triggers

- **"cross sell e-commerce"** → e-commerce
- **"related products"** → related
- **"product bundle"** → bundle

## Tools

Pure prompt — รับ products inventory แล้ว design cross-sell

## Task

1. **Identify product relationships**
2. **Cross-sell timing**
3. **Recommendation engine**
4. **Email cross-sell sequences**

## Examples

### Cross-Sell — Maverick Skin Product Mapping

**PRIMARY PRODUCTS:**

- Maverick Reset (Niacinamide) — ฿590
- Maverick Toner — ฿390
- Maverick Eye Cream — ฿590
- Maverick Sunscreen — ฿390
- Maverick Cleanser — ฿290

**RELATIONSHIP MATRIX:**

| Buy This | Cross-sell That |
|----------|-----------------|
| Reset | Toner (preparation) |
| Reset | Sunscreen (morning protection) |
| Reset | Eye Cream (complete face) |
| Toner | Reset (treatment) |
| Eye Cream | Reset (face care) |
| Sunscreen | Cleanser (clean before sun) |
| Cleanser | Toner (post-cleanse) |

---

### CROSS-SELL TIMING

**Timing 1: Pre-Purchase (in cart)**

**During cart view:**
```
"You added Reset.
Customers also love:"

[Toner ฿390 - Add]
[Eye Cream ฿590 - Add]

[Continue Shopping]
```

**Take rate:** 10-25%

---

**Timing 2: Post-Purchase (immediately)**

**Order confirmation page:**
```
"Order confirmed!

While we ship Reset, complete your routine:"

[Add Toner ฿290 - 25% off]
[Add Eye Cream ฿490 - 17% off]
[Skip — just my Reset]
```

**Take rate:** 15-25%

---

**Timing 3: Post-Use (email)**

**Day 14 after first purchase:**
```
Subject: "Loving Maverick Reset?"

"You've been using Reset for 2 weeks.
Hopefully seeing results.

Many men add Eye Cream + Sunscreen to their routine.
That's a complete face care system."

[View Eye Cream]   [View Sunscreen]
```

**Take rate:** 5-15% (over time)

---

### CROSS-SELL — Course Business

**Buy: Scale Method (฿15,990)**

**Cross-sell:**
- Workbook printed edition (+฿590)
- Templates pack (+฿1,490)
- 1-on-1 strategy session (+฿2,990)
- Mastermind tier upgrade (+฿34,000)

**Email cross-sell after course start:**
- Day 30: "Add 1-on-1 session?"
- Day 60: "Templates pack helps with implementation"
- Day 90: "Ready for Mastermind tier?"

---

### RECOMMENDATION ENGINE

**Logic 1: Customer behavior**
- "People who bought X also bought Y"
- Based on purchase history

**Logic 2: Product affinity**
- "Use X + Y together"
- Based on usage logic

**Logic 3: Routine completion**
- "Step 1: Cleanser, Step 2: Toner, Step 3: Reset"
- Show next step

**Logic 4: Personal goal**
- Quiz result → recommend products
- Based on customer needs

---

### CROSS-SELL FORMATS

**Format 1: Product Cards**
```
[Card 1: Toner ฿390]
[Card 2: Eye Cream ฿590]
[Card 3: Sunscreen ฿390]
```

**Format 2: Bundle Pricing**
```
"Save ฿200 with this combo:
- Reset ฿590
- Toner ฿390
- Eye Cream ฿590

Bundle: ฿1,370 (save ฿200)"
```

**Format 3: Routine Builder**
```
"Build your routine:
[Step 1] [Step 2] [Step 3]

Total routine: ฿1,470 (with ฿100 discount)"
```

---

### CROSS-SELL EMAIL SEQUENCES

**For Reset buyer:**

**Day 7:** Educational
"How to use Reset + Toner together"

**Day 14:** Soft cross-sell
"Add Toner — 30% off this week"

**Day 21:** Story-based
"Customer success: Reset + Toner combo"

**Day 30:** Routine completion
"Build your full routine for ฿100 off"

**Day 60:** Subscription pitch
"Subscribe to all 3 products — save 15%"

---

### COMMON MISTAKES

**❌ Random cross-sells:**
- T-shirt with skincare
- No logical connection

**❌ Too many at once:**
- 5+ products shown
- Decision paralysis

**❌ Same cross-sell for all:**
- Personalization missing
- Lower take rate

**❌ Aggressive timing:**
- Cross-sell every email
- Customer fatigue

**❌ ไม่มี discount:**
- "Just buy more" no incentive
- Take rate low

---

### TYPICAL TAKE RATES

| Timing | Take Rate |
|--------|-----------|
| Cart cross-sell | 10-25% |
| Post-purchase | 15-25% |
| Email (Day 14) | 5-15% |
| Routine builder | 25-40% |

---

### TOOLS

**E-commerce:**
- Shopify (built-in related)
- ReConvert (cross-sell apps)
- AfterSell

**Email automation:**
- Klaviyo (Shopify-native)
- ConvertKit
- ActiveCampaign

**AI recommendation:**
- Algolia
- Nosto
- Bloomreach

## Output Format

```
## Cross-Sell Flow — [business]

### Product Relationship Matrix
| Buy This | Cross-sell That |

### Cross-Sell Timing
1. Pre-Purchase (cart)
2. Post-Purchase (immediately)
3. Post-Use (email)

### Recommendation Logic
1. Customer behavior
2. Product affinity
3. Routine completion
4. Personal goal

### Cross-Sell Formats
- Product Cards
- Bundle Pricing
- Routine Builder

### Email Sequences
- Day 7, 14, 21, 30, 60

### Take Rates by Timing
| Timing | Rate |

### Tools
- E-commerce / Email / AI

### Common Mistakes
❌ Random ❌ Too many ❌ Same for all ❌ Aggressive timing ❌ No discount
```

## Constraints

- Logical product relationships
- Multiple touchpoints
- Personalization
- Reasonable discount
- Track per-product take rate

## Anti-patterns

- ❌ Random cross-sells
- ❌ Show 5+ products
- ❌ ไม่มี personalization
- ❌ Aggressive frequency
- ❌ Generic recommendation

## Related Skills

- **upsell-flow** — upsell
- **order-bump** — bump
- **email-cross-sell** — email

## Memory

- `user.cross_sells` — cross-sells
- `stats.cross_sell_take_rate` — take rate
- `stats.aov_growth` — AOV
