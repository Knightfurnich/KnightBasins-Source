---
name: Financial Success Stories
id: financial-success-stories
category: finance
trigger:
  - "financial success"
  - "successful businesses"
  - "money success"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Case Study Curator (Financial) — เข้าใจว่า real success stories = roadmap

## Context

ผู้ใช้คือ business owner

## Triggers

- **"financial success"** → success

## Tools

Pure prompt — provide stories

## Task

1. **Real examples**
2. **Common patterns**
3. **Lessons**
4. **Apply**

## Examples

### FINANCIAL SUCCESS STORIES

**Story 1: Maverick (5 Years)**

```
Background:
- Solo Year 1 (฿1.5M)
- Year 5: ฿40M revenue, 25 people

Financial Practices:
- Hired accountant Year 2
- Premium pricing from start
- Cash reserves 6 months
- Invested in systems
- Tax planning early
- Documented financials
- Multi-bank strategy
- Personal wealth building

Outcome:
- 36% net margins (top tier)
- ฿100M+ founder wealth Y5
- Sale-ready by Y5

Effect: Financial excellence
```

—————————

**Story 2: Healthcare SaaS (50 People)**

```
Background:
- Bangkok health tech
- Series A funded
- 50 employees

Practices:
- VC-backed disciplines
- Strong financial reporting
- BOI tax holidays
- International expansion funded
- Diversified revenue

Outcome:
- 40% gross margins
- Investor confidence
- Successful Series B
- Industry recognition

Cost: ฿1M/year financial operations
Effect: Investment-grade
```

—————————

**Story 3: Boutique Design Studio (12 People)**

```
Background:
- Premium design agency
- Award-winning
- High-end clients

Practices:
- Premium pricing always
- Selective clients (high-margin)
- Strong cash reserves
- Long-term retainers
- Founder wealth building

Outcome:
- 60% margins (industry-leading)
- Steady ฿15M revenue
- Premium positioning
- Founder wealthy

Cost: ฿300K/year financial
Effect: Premium business
```

—————————

**Story 4: E-commerce Brand (15 People)**

```
Background:
- Skincare brand
- 15 employees
- ฿20M revenue

Practices:
- Inventory optimization
- Strong COGS management
- Profitable from Year 2
- Cash flow disciplined
- Tax efficient

Outcome:
- 30% net margins (e-commerce strong)
- ฿6M annual profit
- Sustainable growth
- Premium customer base

Cost: ฿200K/year financial
Effect: Sustainable + profitable
```

—————————

**Story 5: Tech Startup ($5M Exit)**

```
Background:
- B2B SaaS
- Bangkok-based
- 5-year journey
- Sold for $5M

Pre-Exit Prep:
- 3-year clean books
- Audited financials
- Strong recurring revenue
- Diversified clients
- Documented processes

Exit Process:
- 18 months prep
- Specialist M&A team
- Premium positioning
- Multiple offers

Outcome:
- $5M+ exit
- Founder wealth
- Smooth transition

Cost: ฿5M total financial/M&A
Return: ฿175M+

Effect: Major liquidity
```

---

### COMMON PATTERNS

**Pattern 1: Premium Pricing**

```
All success stories:
- Premium positioning
- Above-market pricing
- Value-based pricing
- Justified by quality

Effect: Higher margins
```

—————————

**Pattern 2: Cash Discipline**

```
All maintained:
- 3-6+ months reserves
- Aggressive collections
- Conservative spending
- Cash flow primary

Effect: Resilience
```

—————————

**Pattern 3: Specialist Support**

```
All used:
- Accountants (early)
- Tax advisors
- Specialty lawyers
- Financial planners (when scaling)

Effect: Right expertise
```

—————————

**Pattern 4: Long-Term Thinking**

```
All planned:
- 3-5 years ahead
- Build for compound
- Patient growth
- Strategic investments

Effect: Compounding benefits
```

—————————

**Pattern 5: Strong Margins**

```
All achieved:
- Top-tier margins (industry)
- Margin discipline
- Cost control
- Premium pricing

Effect: Profitability
```

—————————

**Pattern 6: Documentation**

```
All maintained:
- Clean books
- Audit-ready
- Defensible
- Investor-grade

Effect: Multiple options
```

—————————

**Pattern 7: Tax Efficiency**

```
All used:
- Legal optimization
- Strategic structure
- Maximize deductions
- Multi-year planning

Effect: Lower tax legally
```

—————————

**Pattern 8: Diversification**

```
All achieved:
- Multiple revenue streams
- Diverse customers
- External investments (founder)
- Multiple banks

Effect: Resilience
```

---

### KEY LESSONS

**Lesson 1: Hire Accountant Early**

```
- Year 1-2 if scaling
- Cost: ฿3-15K/month
- Return: Avoid mistakes
- Tax savings significant

Effect: Investment pays
```

—————————

**Lesson 2: Premium Pricing Wins**

```
Better than discount:
- Higher margins
- Better customers
- Less work for more revenue
- Sustainable

Effect: Premium strategy
```

—————————

**Lesson 3: Reserves Critical**

```
Build:
- 3 months minimum
- 6 months ideal
- Sleep at night
- Survive disruptions

Effect: Resilience
```

—————————

**Lesson 4: Track Everything**

```
- All transactions
- Monthly reviews
- Variance analysis
- Action on data

Effect: Active management
```

—————————

**Lesson 5: Long-Term Compound**

```
Patient + consistent:
- Year 1: Slow
- Year 3: Steady
- Year 5: Significant
- Year 10: Massive

Effect: Compounding wealth
```

—————————

**Lesson 6: Personal Wealth Separate**

```
Build alongside:
- Business equity (yes)
- Plus personal savings
- Plus investments
- Plus real estate

ไม่ all in business

Effect: Diversification
```

—————————

**Lesson 7: Plan Exits Early**

```
Years before:
- Build sellable
- Documentation
- Strong team
- Multiple options

Effect: Major liquidity events
```

---

### YOUR FINANCIAL PATH

**Match to Stage:**

```
Solo Year 1:
- Foundation right
- Specialist begins

Small Team Y2-3:
- Comprehensive systems
- Specialist team

Growing Y3-5:
- Mature operations
- Pre-exit thinking

Mature Y5+:
- Industry-leading
- Multiple options
- Wealth building

Effect: Right level
```

—————————

**Action Steps:**

```
Year 1:
- Accounting system
- Specialist begin
- Cash discipline
- Tax planning

Year 2-3:
- Comprehensive
- Premium pricing
- Reserves built
- Documentation

Year 5+:
- Pre-exit ready
- Premium positioning
- Wealth building
- Multiple options

Effect: Build over time
```

---

### FINANCIAL SUCCESS PRINCIPLES

**Principle 1: Foundation early**

✅ Year 1 priorities
- Late = expensive

—————————

**Principle 2: Specialists**

✅ Right expertise
- DIY major = mistakes

—————————

**Principle 3: Premium positioning**

✅ Higher prices possible
- Race to bottom = limit

—————————

**Principle 4: Cash discipline**

✅ Reserves + collections
- Cash = survival

—————————

**Principle 5: Long-term**

✅ Years compound
- Quick fixes limit

---

### COMMON SUCCESS MISTAKES

**❌ Compare end states:**
- "$5M exit"
- Different journey

**❌ Copy without context:**
- ไม่ understand
- Wrong fit

**❌ Skip foundation:**
- Want results
- Without work

**❌ Quick-fix mindset:**
- Compounds slowly

## Output Format

```
## Financial Success Stories — [match]

### 5 Real Stories
1. Maverick (5 yrs, ฿40M, 36% net)
2. Healthcare SaaS (50 ppl, Series A)
3. Boutique Design (12 ppl, 60% margin)
4. E-commerce Brand (15 ppl, ฿20M, 30% net)
5. Tech Startup ($5M exit)

### 8 Common Patterns
1. Premium pricing
2. Cash discipline (3-6 months)
3. Specialist support (accountants, advisors)
4. Long-term thinking (3-5 years)
5. Strong margins (industry top tier)
6. Documentation (audit-ready)
7. Tax efficiency
8. Diversification (revenue + investments)

### 7 Key Lessons
1. Hire accountant early
2. Premium pricing wins
3. Reserves critical
4. Track everything
5. Long-term compound
6. Personal wealth separate
7. Plan exits early

### Your Path by Stage
- Y1: Foundation
- Y2-3: Comprehensive
- Y3-5: Pre-exit thinking
- Y5+: Mature, multiple options

### Principles (5)
1. Foundation early
2. Specialists
3. Premium positioning
4. Cash discipline
5. Long-term

### Common Mistakes
❌ Compare end ❌ Copy without context ❌ Skip foundation ❌ Quick fixes
```

## Constraints

- Foundation Year 1
- Specialist relationships
- Premium positioning
- Cash discipline
- Long-term thinking

## Anti-patterns

- ❌ Compare to end states only
- ❌ Copy blindly
- ❌ Skip foundation
- ❌ Quick-fix mindset
- ❌ Ignore long-term

## Related Skills

- **financial-planning** — planning
- **financial-mistakes** — mistakes

## Memory

- `user.financial_success_path` — path
