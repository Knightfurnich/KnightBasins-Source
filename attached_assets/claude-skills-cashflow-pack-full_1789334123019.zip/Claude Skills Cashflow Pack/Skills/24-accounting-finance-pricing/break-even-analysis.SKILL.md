---
name: Break Even Analysis
id: break-even-analysis
category: finance
trigger:
  - "break even"
  - "breakeven"
  - "fixed costs"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Break-Even Specialist — เข้าใจว่า break-even = key threshold → know when profitable

## Context

ผู้ใช้คือ business

## Triggers

- **"break even"** → break even

## Tools

Pure prompt — รับ situation แล้ว calculate

## Task

1. **Calculate break-even**
2. **Strategic decisions**
3. **What-if scenarios**
4. **Use for planning**

## Examples

### BREAK-EVEN BASICS

**Concept:**

```
Break-even point:
- Revenue = Total Costs
- ไม่มี profit, ไม่มี loss
- Critical threshold
- Beyond = profit
- Below = loss

Effect: Survival metric
```

—————————

**Components:**

```
Fixed Costs:
- Rent
- Salaries (base)
- Insurance
- Utilities
- Subscriptions
- Other fixed

Variable Costs:
- Materials
- Direct labor (variable)
- Commissions
- Direct expenses
- Per-unit costs

Effect: Total cost structure
```

—————————

**Formula:**

```
Break-even (Units) = Fixed Costs / (Price per Unit - Variable Cost per Unit)

Or:
Break-even (Revenue) = Fixed Costs / Contribution Margin %

Where:
Contribution Margin = (Revenue - Variable Costs) / Revenue

Effect: Target known
```

---

### CALCULATE EXAMPLES

**Maverick Example (Service):**

```
Fixed costs (monthly):
- Salaries: ฿350K
- Rent + utilities: ฿30K
- Tools: ฿20K
- Other: ฿20K
Total: ฿420K/month

Variable costs:
- Per project (~10% of revenue)

Contribution margin: 90%

Monthly break-even:
฿420K / 0.90 = ฿466K/month

Annual: ฿5.6M

Maverick actual:
- Annual revenue: ฿15M (Y3)
- Profit margin from this point
- ฿15M - ฿5.6M = ฿9.4M "above break-even"
- = ฿9.4M × 90% = ฿8.5M contribution to profit (before tax)

Effect: Healthy margin above
```

—————————

**E-Commerce Example:**

```
Fixed costs (monthly):
- Rent + warehouse: ฿100K
- Salaries: ฿200K
- Other: ฿50K
Total: ฿350K

Variable per product:
- Cost: ฿200
- Selling price: ฿500
- Contribution: ฿300/unit

Break-even (units):
฿350K / ฿300 = 1,167 units/month

Effect: Sales target clear
```

—————————

**SaaS Example:**

```
Fixed costs (monthly):
- Salaries: ฿500K
- Servers: ฿50K
- Tools: ฿30K
Total: ฿580K

Variable per customer:
- Server cost: ฿50/customer
- Support: ฿100/customer
- Total: ฿150/customer
- Subscription: ฿1,000/customer
- Contribution: ฿850/customer

Break-even (customers):
฿580K / ฿850 = 683 customers/month

Effect: Customer target clear
```

---

### USE FOR DECISIONS

**Pricing Decisions:**

```
What if reduce price 10%?
- Lower contribution margin
- Higher break-even
- Need more volume

Calculation:
- Old: 1,000 units to break-even
- New: 1,200 units (need 20% more volume)

Decision:
- Worth it if volume increases enough
- Otherwise margin destroyed

Effect: Informed pricing
```

—————————

**Cost Cuts:**

```
Reduce fixed costs by ฿50K:
- Lower break-even
- Faster profitability

Example:
- Old: ฿420K fixed → ฿466K break-even
- New: ฿370K fixed → ฿411K break-even
- Saves: ฿55K/month margin

Effect: Profit improvement
```

—————————

**Scaling Decisions:**

```
Hire more staff (฿80K/month):
- Fixed costs increase
- Break-even higher
- Need additional revenue

Calculate:
- New break-even: + ฿88K (added cost / 0.9 margin)
- Need: At least ฿88K more revenue
- ROI: Will the hire generate this?

Effect: Hiring confidence
```

—————————

**New Product Launch:**

```
Calculate:
- Launch costs (fixed)
- Per-unit cost
- Selling price
- Break-even units
- Realistic volume?

If volume target unrealistic:
- ไม่ launch
- Reprice
- Reduce costs

Effect: Smart launch
```

—————————

**Office Move:**

```
New rent ฿100K (vs ฿30K):
- Fixed costs +฿70K
- Break-even +฿78K/month
- Need significant revenue boost

Decision:
- Worth it if scaling
- Wait if not

Effect: Real estate decisions
```

---

### WHAT-IF SCENARIOS

**Sensitivity Analysis:**

```
Test:
- Price changes
- Volume changes
- Cost changes
- Market shifts

For each:
- New break-even
- Profit impact
- Decision threshold

Effect: Prepared for changes
```

—————————

**Maverick Scenarios:**

```
Base Y3:
- Fixed: ฿420K/month
- Break-even: ฿466K/month

Worst case:
- Lose 30% of clients
- Revenue ฿1M → ฿700K
- Still above break-even
- Profitable but tight

Best case:
- Grow 50%
- Revenue ฿1M → ฿1.5M
- Strong profit margin

Decision:
- Maintain reserves (worst case)
- Plan for best case
- Manage middle

Effect: Strategic clarity
```

---

### MARGIN OF SAFETY

**Definition:**

```
Margin of Safety = (Actual Revenue - Break-Even Revenue) / Actual Revenue × 100

Maverick Y3:
Annual: (฿15M - ฿5.6M) / ฿15M = 63% margin of safety

Targets:
- < 20%: Risky
- 20-50%: Normal
- > 50%: Strong

Effect: Risk indicator
```

—————————

**Use:**

```
- Higher margin = more cushion
- Can absorb downturns
- Pricing flexibility
- Strategic options

Lower margin:
- Vulnerable
- ไม่มี cushion
- Stressed in downturn

Maverick: Strong (63%)
Effect: Resilient business
```

---

### BREAK-EVEN PRINCIPLES

**Principle 1: Calculate accurately**

✅ Know fixed vs variable
- Mistakes = wrong decisions

—————————

**Principle 2: Update regularly**

✅ Quarterly minimum
- Costs change

—————————

**Principle 3: Strategic tool**

✅ Decisions guided
- Not just academic

—————————

**Principle 4: Scenario plan**

✅ What-if analysis
- Prepared

—————————

**Principle 5: Healthy margin**

✅ Above break-even significantly
- Cushion important

---

### COMMON BREAK-EVEN MISTAKES

**❌ ไม่ calculate:**
- Don't know threshold
- Surprise losses

**❌ Wrong fixed/variable split:**
- Inaccurate result
- Bad decisions

**❌ ไม่ update:**
- Costs grow
- Old number wrong

**❌ Ignore margin of safety:**
- Tight to break-even
- Vulnerable

**❌ ไม่ scenarios:**
- Surprised by changes

## Output Format

```
## Break Even Analysis — [business type]

### Components
- Fixed Costs (rent, salaries, etc.)
- Variable Costs (materials, commissions)
- Selling Price
- Contribution Margin

### Formula
- BE Units = Fixed Costs / (Price - Variable Cost)
- BE Revenue = Fixed Costs / Contribution Margin %

### Maverick Y3
- Fixed: ฿420K/month
- Margin: 90%
- BE: ฿466K/month
- Actual: ฿1.25M/month
- Margin of safety: 63% ✅

### Use for Decisions
- Pricing changes
- Cost cuts
- Hiring + scaling
- New product launches
- Office moves

### What-If Scenarios
- Base / Best / Worst
- Sensitivity analysis
- Strategic preparation

### Margin of Safety
- (Actual - BE) / Actual × 100
- Target: > 50% (strong)
- < 20% risky

### Principles (5)
1. Calculate accurately
2. Update regularly
3. Strategic tool
4. Scenario plan
5. Healthy margin

### Common Mistakes
❌ ไม่ calculate ❌ Wrong split ❌ ไม่ update ❌ Ignore safety ❌ ไม่ scenarios
```

## Constraints

- Calculate break-even accurately
- Update quarterly
- Use for major decisions
- Scenario planning
- Maintain margin of safety

## Anti-patterns

- ❌ ไม่ calculate
- ❌ Inaccurate splits
- ❌ Outdated calculations
- ❌ Tight to break-even
- ❌ ไม่ scenarios

## Related Skills

- **financial-analysis** — analysis
- **profit-loss** — P&L

## Memory

- `user.break_even` — break-even
