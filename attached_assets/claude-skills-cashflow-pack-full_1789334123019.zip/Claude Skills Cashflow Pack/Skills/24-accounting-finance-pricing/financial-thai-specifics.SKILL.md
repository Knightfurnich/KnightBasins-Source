---
name: Financial Thai Specifics
id: financial-thai-specifics
category: finance
trigger:
  - "thai accounting"
  - "thai finance"
  - "บัญชีไทย"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Thai Financial Specialist — เข้าใจว่า Thai-specific = unique requirements → must comply

## Context

ผู้ใช้คือ Thai business

## Triggers

- **"thai accounting"** → Thai

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **Thai-specific requirements**
2. **Common practices**
3. **Compliance**
4. **Cultural considerations**

## Examples

### THAI-SPECIFIC REQUIREMENTS

**Financial Statements (Thai GAAP):**

```
Required:
- Thai language (or bilingual)
- Specific format
- Thai accounting standards
- Annual filings

Differences from US/EU:
- Thai-specific tax treatment
- VAT specific handling
- Local regulations

Effect: Thai compliance
```

—————————

**Audit Requirements:**

```
Limited Companies:
- All audited annually
- CPA license required
- Filed with DBD
- Public record

Sole Proprietorship:
- ไม่ required
- Just tax filing

Effect: Compliance
```

—————————

**Tax Filing Calendar:**

```
Monthly:
- VAT (PP.30): 15th of next month
- Withholding (PND.1, 3, 53): 7th
- Social Security: 15th

Half-year:
- Corporate income (PND.51)

Annually:
- Personal income (PND.91/94): March 31 / May 31
- Corporate income (PND.50): 150 days after fiscal year
- Annual VAT (PP.36): 90 days

Effect: Predictable cadence
```

—————————

**Currency:**

```
- THB primary
- Foreign currency accounts allowed
- Exchange rate considerations
- Conversion timing

Effect: Local + international
```

---

### THAI COMMON PRACTICES

**13-Month Bonus:**

```
- ไม่ legally required
- Industry standard
- Most companies provide
- Pay in December typically
- Equivalent to 1 month salary

Effect: Expected benefit
```

—————————

**Withholding Tax (3% B2B):**

```
When paying B2B services:
- Withhold 3% from payment
- Issue withholding certificate
- File monthly (PND.53)
- Recipient claims credit

Reverse: When receiving:
- Customer withholds 3%
- Get certificate
- Claim credit on annual

Effect: Mandatory compliance
```

—————————

**Provident Fund:**

```
Optional but valuable:
- Employer + employee contributions
- Tax-deductible
- Long-term wealth
- Common in established companies

Typical: 5-10% match
Effect: Worker benefit
```

—————————

**Social Security:**

```
Mandatory employees:
- 5% each (capped at ฿15K salary)
- ฿1,500/employee/month max
- Coverage: Medical, maternity, retirement

Voluntary self-employed:
- ฿432-9,000/month
- Optional

Effect: Worker safety net
```

—————————

**BOI Privileges:**

```
Specific industries:
- Tech, manufacturing, R&D
- Tourism
- Logistics
- 100% foreign ownership
- Tax holidays 3-8 years
- Application required

Cost-benefit:
- Setup ฿100-300K
- Tax savings significant
- Worth for eligible

Effect: Major tax advantage
```

---

### COMPLIANCE

**Annual Activities:**

```
Q1 (January-March):
- Annual employment statistics
- Year-end financial preparation
- Personal income tax (March 31)

Q2 (April-June):
- Personal income online (May 31)
- Corporate income (within 150 days)
- Annual VAT (within 90 days)

Q3-Q4:
- Half-year tax estimate
- Audit preparation

Effect: Year-round compliance
```

—————————

**License Renewals:**

```
- Business registration (DBD)
- Industry-specific
- VAT (continuous)
- Trademarks (every 10 years)
- Various per industry

Calendar all renewals
Effect: ไม่มี surprises
```

—————————

**PDPA Compliance:**

```
Personal Data Protection Act:
- Customer data
- Employee data
- Privacy policy
- Consent management
- Cross-border transfers

Penalties: Up to ฿5M
Effect: Mandatory
```

---

### CULTURAL CONSIDERATIONS

**Personal Relationships:**

```
Thai business culture:
- Relationships matter
- Personal connections
- "Krap/Ka" politeness
- Respect hierarchy
- Gift-giving (within reason)

Impact on finance:
- Bank relationships personal
- Vendor negotiations relationship-based
- Long-term thinking valued

Effect: Soft factors important
```

—————————

**Trust + Documentation:**

```
Balance:
- Trust in relationships
- ไม่ over-formalize
- But document important things
- Especially money

Effect: Both relationship + documentation
```

—————————

**Hierarchy:**

```
Decision-making:
- Senior approval often needed
- ไม่ independent often
- Patience required
- Multiple stakeholders

Effect: Plan accordingly
```

—————————

**Maverick Practices:**

```
- Bilingual financials (Thai + English)
- Thai accountant primary
- Specialist consultations
- Cultural sensitivity
- Long-term banking relationships
- Annual gifts (modest, appropriate)

Effect: Cultural fit + compliance
```

---

### THAI-SPECIFIC TOOLS

**Accounting Software:**

```
Thai-specific:
- FlowAccount (popular SME)
- AccCloud
- BusinessPlus
- Express

Built for:
- VAT compliance
- PND.1 forms
- Thai language
- Local bank integration

Cost: ฿500-3K/month
Effect: Local compliance
```

—————————

**International (with Thai support):**

```
- Xero (good Thai support)
- QuickBooks (less Thai)
- Bonsai (limited Thai)

Best for: Bilingual operations
Effect: Mixed approach
```

—————————

**Banks:**

```
Major Thai banks:
- BBL (international strength)
- KTB (government)
- SCB (digital best)
- K-Bank (SME focus)
- Krungsri (mid-tier)

International:
- UOB
- Citibank
- HSBC

Choose based on: Industry + needs
Effect: Right banking
```

---

### COMMON THAI MISTAKES

**❌ Skip Thai accountant:**
- Foreign accounting only
- Miss Thai-specific
- Compliance gaps

**❌ ไม่ understand VAT:**
- Late filings
- Incorrect calculations
- Penalties

**❌ Ignore relationships:**
- Pure transactional
- Lose advantages
- Cultural misfit

**❌ Skip BOI when eligible:**
- Miss major tax savings
- Wrong industry assumption

**❌ ไม่ Thai language:**
- Documentation only English
- Local team disadvantaged
- Some compliance need Thai

## Output Format

```
## Financial Thai Specifics — [topic]

### Thai-Specific Requirements
- Financial statements (Thai GAAP)
- Audit (limited companies)
- Tax filing calendar
- Currency THB

### Common Practices
- 13-month bonus (industry standard)
- Withholding 3% B2B
- Provident fund (optional)
- Social Security (mandatory)
- BOI privileges (specific industries)

### Compliance Calendar
- Monthly: VAT, withholding, SSO (15th)
- Half-year: Corporate estimate
- Annual: PIT (March), CIT (150 days), VAT (90 days)

### Cultural Considerations
- Personal relationships matter
- Trust + documentation balance
- Hierarchy in decisions
- Long-term thinking

### Thai Tools
- Accounting: FlowAccount, AccCloud, Xero
- Banks: BBL, KTB, SCB, K-Bank, Krungsri

### Maverick Practices
- Bilingual financials
- Thai accountant primary
- Cultural sensitivity
- Long-term banking relationships

### Common Mistakes
❌ Skip Thai accountant ❌ ไม่ understand VAT ❌ Ignore relationships ❌ Skip BOI ❌ ไม่ Thai language
```

## Constraints

- Thai-specific compliance
- Bilingual documentation
- Thai accountant relationship
- Cultural sensitivity
- BOI when eligible

## Anti-patterns

- ❌ Foreign-only approach
- ❌ Ignore VAT specifics
- ❌ Pure transactional
- ❌ Skip BOI eligible
- ❌ English-only

## Related Skills

- **tax-compliance** — tax
- **business-banking** — banking

## Memory

- `user.thai_financial` — Thai
