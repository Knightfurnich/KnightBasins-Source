---
name: Financial Statements
id: financial-statements
category: finance
trigger:
  - "financial statements"
  - "annual report"
  - "balance sheet"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Financial Statements Specialist — เข้าใจว่า statements = official financial picture → required + useful

## Context

ผู้ใช้คือ business

## Triggers

- **"financial statements"** → statements

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **3 main statements**
2. **How prepared**
3. **Audit requirements**
4. **Use for decisions**

## Examples

### 3 MAIN STATEMENTS

**1. Income Statement (P&L):**

```
Period (month/quarter/year):
- Revenue
- Less: COGS = Gross Profit
- Less: OpEx = Operating Profit
- Less: D&A, Interest = Pre-tax
- Less: Tax = Net Profit

Effect: Performance over time
```

—————————

**2. Balance Sheet:**

```
At specific date:

Assets = Liabilities + Equity

Assets:
- Current (cash, AR, inventory)
- Fixed (equipment, property)
- Intangible (IP, goodwill)

Liabilities:
- Current (AP, short-term debt)
- Long-term (loans, mortgages)

Equity:
- Paid-in capital
- Retained earnings

Effect: Snapshot of financial position
```

—————————

**3. Cash Flow Statement:**

```
Period:

Operating Activities:
- Net profit
- + Non-cash items (depreciation)
- ± Working capital changes
- = Cash from operations

Investing Activities:
- Equipment purchases
- Investment changes
- Net investing cash

Financing Activities:
- Loan changes
- Equity changes
- Dividends paid
- Net financing cash

Effect: Where cash came from + went
```

—————————

**Maverick Y3 Statements:**

```
P&L Annual:
- Revenue: ฿15M
- Net Profit: ฿5.4M (36%)

Balance Sheet (Dec 31):
Assets:
- Cash: ฿5M
- AR: ฿1.5M
- Equipment: ฿800K
- Total: ฿7.3M

Liabilities:
- AP: ฿500K
- Tax payable: ฿300K
- Total: ฿800K

Equity:
- Capital: ฿1M
- Retained earnings: ฿5.5M
- Total: ฿6.5M

Verify: Assets ฿7.3M = L+E ฿7.3M ✓

Cash Flow:
- Operating: +฿5.5M
- Investing: -฿500K
- Financing: -฿1M (dividends)
- Net: +฿4M

Effect: Comprehensive picture
```

---

### PREPARATION

**Steps:**

```
1. Close month (record all transactions)
2. Reconcile bank
3. Adjust entries (depreciation, etc.)
4. Generate trial balance
5. Generate statements
6. Review accuracy
7. Tax accounting (if year-end)
8. Audit (if required)

Time: Days to weeks (year-end)
Effect: Accurate financials
```

—————————

**Tools:**

```
Generate from accounting:
- Xero
- QuickBooks
- SAP
- Custom

Most have built-in:
- One-click statements
- Comparative periods
- Customizable

Effect: Easy generation
```

---

### AUDIT REQUIREMENTS

**Thai Audit:**

```
Required for:
- Limited companies (Bor.Aor.Cho)
- Specific industries
- Some thresholds

Process:
- External auditor
- Annual review
- Audit report
- File with DBD + Revenue

Cost:
- ฿30K-100K (small companies)
- ฿100K-500K (mid-size)
- ฿500K+ (large)

Effect: Financial verified
```

—————————

**When Audit Required:**

```
Limited Companies:
- All required typically
- Small companies: Simpler audit
- Specific industries: More

Sole Proprietorship:
- ไม่ required (typically)
- Just tax filing

Effect: Compliance
```

—————————

**Choose Auditor:**

```
- CPA license required
- Reputation
- Industry experience
- Reasonable fees
- Communication style

Avoid:
- Rubber-stamp auditors
- Incompetent firms
- Conflicts of interest

Effect: Quality audit
```

---

### USE FOR DECISIONS

**Investor/Lender Conversations:**

```
- 3-year financial statements
- Audited preferred
- Trends visible
- Profitability clear

Effect: Credibility
```

—————————

**Sale of Business:**

```
Buyers want:
- 3-5 years audited statements
- Clean books
- No qualifications
- Comparable periods
- Tax compliance proof

Effect: Premium valuation
```

—————————

**Strategic Planning:**

```
Use statements for:
- Trend analysis
- Comparison vs industry
- Identify issues
- Plan investments
- Tax optimization

Effect: Data-driven
```

—————————

**Maverick Strategic Use:**

```
Year 3 statements:
- Profitable + growing
- Strong margins
- Cash positive
- Clean books

Decisions enabled:
- Bank loan approved (used statements)
- Hire key roles confidently
- Invest in expansion
- Plan for exit

Effect: Strategic enabler
```

---

### COMMON STATEMENT MISTAKES

**❌ ไม่ generate regularly:**
- Annual only = late
- Surprises

**❌ Inconsistent categorization:**
- ไม่ comparable
- Hard to analyze

**❌ Skip audit:**
- Required ไม่ done
- Compliance issue

**❌ ไม่ understand:**
- Statements generated
- Owner can't read
- Bad decisions

**❌ Cosmetic only:**
- "Make look good"
- Misrepresent
- Audit issues

## Output Format

```
## Financial Statements — [period]

### 3 Main Statements
1. Income Statement (P&L) - period performance
2. Balance Sheet - snapshot at date (A = L + E)
3. Cash Flow Statement - cash movement

### Maverick Y3 Numbers
- P&L: ฿15M revenue, ฿5.4M net (36%)
- Balance: ฿7.3M assets, ฿800K liabilities, ฿6.5M equity
- Cash: +฿4M net for year

### Preparation
- Close month transactions
- Reconcile bank
- Adjust entries
- Generate from accounting tool

### Audit (Thai)
- Required for limited companies
- Annual external auditor
- Cost: ฿30K-500K based on size
- Compliance + credibility

### Use for Decisions
- Investor conversations
- Sale of business (3-5 yrs)
- Strategic planning
- Bank loans

### Common Mistakes
❌ ไม่ generate regularly ❌ Inconsistent ❌ Skip audit ❌ ไม่ understand ❌ Cosmetic
```

## Constraints

- Generate monthly statements
- Annual audit (if required)
- Owner understands basics
- Use for decisions
- Compliance maintained

## Anti-patterns

- ❌ Annual only
- ❌ Inconsistent categorization
- ❌ Skip required audit
- ❌ Owner doesn't read
- ❌ Cosmetic accounting

## Related Skills

- **profit-loss** — P&L
- **accounting-basics** — basics

## Memory

- `user.financial_statements` — statements
