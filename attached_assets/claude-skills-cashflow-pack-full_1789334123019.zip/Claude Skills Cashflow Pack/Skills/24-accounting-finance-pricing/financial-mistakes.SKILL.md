---
name: Financial Mistakes
id: financial-mistakes
category: finance
trigger:
  - "financial mistakes"
  - "money mistakes"
  - "avoid financial errors"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Financial Coach — เข้าใจว่า most businesses make same financial mistakes → fix common = avoid disasters

## Context

ผู้ใช้คือ business

## Triggers

- **"financial mistakes"** → mistakes

## Tools

Pure prompt — provide list

## Task

1. **Top mistakes**
2. **Consequences**
3. **Prevention**

## Examples

### TOP 15 FINANCIAL MISTAKES

**Mistake 1: ไม่ Track Cash Flow**

```
Consequence:
- Surprise cash crisis
- Bankruptcy possible
- Stress

Fix: 13-week forecast
```

—————————

**Mistake 2: Mix Personal + Business**

```
Consequence:
- Tax disasters
- Audit nightmares
- Pierce corporate veil

Fix: Separate accounts immediately
```

—————————

**Mistake 3: ไม่ Hire Accountant**

```
Consequence:
- DIY mistakes costly
- Tax issues
- Compliance gaps

Fix: Hire when complex (฿1M+ revenue)
```

—————————

**Mistake 4: ไม่มี Reserves**

```
Consequence:
- One bad month = crisis
- Forced bad decisions
- ไม่มี opportunities

Fix: 3-6 month buffer
```

—————————

**Mistake 5: Confuse Profit with Cash**

```
Consequence:
- Spend "profit" before received
- Cash crisis
- Owe taxes ไม่มี cash

Fix: Track both separately
```

—————————

**Mistake 6: Underprice**

```
Consequence:
- Lower margins
- Resentment
- Race to bottom
- Hard to raise

Fix: Premium pricing strategy
```

—————————

**Mistake 7: Slow Collections**

```
Consequence:
- AR sits
- Cash flow blind
- Bad debts grow

Fix: Net 14 days + auto-reminders
```

—————————

**Mistake 8: ไม่มี Budget**

```
Consequence:
- Spending uncontrolled
- ไม่ vs target
- Drift

Fix: Annual budget + monthly tracking
```

—————————

**Mistake 9: Late Tax Filings**

```
Consequence:
- Penalties + interest
- Audit risk
- Compliance issues

Fix: Calendar + accountant
```

—————————

**Mistake 10: Ignore P&L**

```
Consequence:
- Don't know profitability
- Bad decisions
- Margin slides

Fix: Monthly P&L review
```

—————————

**Mistake 11: All Cash, No Investing**

```
Consequence:
- Inflation eats savings
- ไม่มี wealth growth
- Compound lost

Fix: Invest excess cash
```

—————————

**Mistake 12: Personal Guarantees**

```
Consequence:
- Personal assets at risk
- Bankruptcy possible
- Family exposed

Fix: Build business credit, negotiate alternatives
```

—————————

**Mistake 13: Stack Debt**

```
Consequence:
- Cash flow stress
- Default cascade
- Limited flexibility

Fix: One loan at a time, conservative
```

—————————

**Mistake 14: ไม่ Forecast**

```
Consequence:
- Reactive, not proactive
- Surprises
- Late corrections

Fix: 13-week + annual forecasts
```

—————————

**Mistake 15: ไม่ Plan Exit**

```
Consequence:
- Build wrong type of business
- Lower exit value
- Stuck operating

Fix: Plan exit 3-5 years ahead
```

---

### CONSEQUENCES BY SEVERITY

**Catastrophic (Business Ending):**

```
- Cash crisis (no reserves)
- Tax fraud (criminal)
- Stack debt + bankruptcy
- Major lawsuits
- Permanent damage

Effect: Business ends
```

—————————

**Major (Significant):**

```
- Lost ฿1M+ to mistakes
- Compliance failures
- Reputation damage
- Major rework needed

Effect: Major setback
```

—————————

**Moderate:**

```
- Lower margins than possible
- Tax penalties
- Operational inefficiency
- Cash flow stress

Effect: Manageable but harmful
```

—————————

**Minor:**

```
- Time wasted
- Some money lost
- Annoying

Effect: Lessons learned
```

---

### PREVENTION FRAMEWORK

**Quarterly Review:**

```
- Top 15 mistakes
- Self-assess
- Identify gaps
- Action plan

Effect: Continuous improvement
```

—————————

**Specialist Relationships:**

```
- Accountant (tax, books)
- Lawyer (legal financial)
- Financial advisor (personal)
- M&A specialist (when relevant)

Cost: ฿200-500K/year
Effect: Right expertise
```

—————————

**Documentation Culture:**

```
- All transactions
- Decisions documented
- Audit trails
- Backup multiple

Effect: Defensible
```

—————————

**Continuous Learning:**

```
- Books + courses
- Industry publications
- Peer learning
- Conferences

Effect: Stay informed
```

---

### MAVERICK FINANCIAL MATURITY

**Year 1:**

```
Made:
- Mixed personal + business briefly
- Underprice initially
- ไม่มี real budget
- Late filing once

Learned:
- Separate immediately
- Premium positioning
- Build budget Year 2
- Calendar all filings
```

—————————

**Year 2:**

```
Made:
- Slow collections
- ไม่ regular forecasting

Learned:
- Net 14 days standard
- 13-week forecasts
- Active management
```

—————————

**Year 3:**

```
Mistakes minimized:
- Strong financial foundation
- All systems in place
- Specialists engaged
- Continuous improvement

Effect: Mature operations
```

---

### FINANCIAL MATURITY PRINCIPLES

**Principle 1: Foundation early**

✅ Year 1 essentials
- Late = expensive

—————————

**Principle 2: Specialists**

✅ Accountant, lawyer, advisor
- DIY major = mistakes

—————————

**Principle 3: Continuous learning**

✅ Always improving
- Stagnant = drift

—————————

**Principle 4: Documentation**

✅ Audit trails
- Defensible

—————————

**Principle 5: Long-term thinking**

✅ Plan years ahead
- Quick fixes ไม่ work

---

### COMMON MISTAKES ABOUT MISTAKES

**❌ Hide:**
- Pretend ไม่ happened
- Compound

**❌ One-time fix:**
- Address once
- Recur

**❌ ไม่ learn:**
- Same mistake again

**❌ Blame:**
- ไม่ accountability
- Continue

## Output Format

```
## Financial Mistakes — [audit]

### Top 15 Financial Mistakes
1. ไม่ track cash flow
2. Mix personal + business
3. ไม่ hire accountant
4. ไม่มี reserves
5. Confuse profit + cash
6. Underprice
7. Slow collections
8. ไม่มี budget
9. Late tax filings
10. Ignore P&L
11. All cash, no investing
12. Personal guarantees
13. Stack debt
14. ไม่ forecast
15. ไม่ plan exit

### Consequences by Severity
- Catastrophic (business ending)
- Major (฿1M+ losses)
- Moderate (margin/cash flow)
- Minor (annoying)

### Prevention Framework
- Quarterly review (top 15)
- Specialist relationships
- Documentation culture
- Continuous learning

### Maverick Maturity Path
- Y1: Foundation mistakes (learned)
- Y2: Refinement (better systems)
- Y3: Mature operations (minimal)

### Principles (5)
1. Foundation early
2. Specialists
3. Continuous learning
4. Documentation
5. Long-term thinking

### Common Mistakes about Mistakes
❌ Hide ❌ One-time fix ❌ ไม่ learn ❌ Blame
```

## Constraints

- Address all 15 common mistakes
- Specialist relationships
- Documentation systematic
- Continuous improvement
- Long-term planning

## Anti-patterns

- ❌ Hide mistakes
- ❌ One-time fixes
- ❌ DIY major
- ❌ Skip specialists
- ❌ Reactive only

## Related Skills

- **accounting-basics** — basics
- **cash-flow-management** — cash

## Memory

- `user.financial_mistakes` — mistakes
