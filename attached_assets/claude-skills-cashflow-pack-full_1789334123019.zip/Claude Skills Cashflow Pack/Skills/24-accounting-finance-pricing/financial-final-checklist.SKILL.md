---
name: Financial Final Checklist
id: financial-final-checklist
category: finance
trigger:
  - "financial checklist"
  - "finance audit"
  - "money checklist"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Financial Audit Specialist — เข้าใจว่า comprehensive checklist = catch gaps

## Context

ผู้ใช้คือ business

## Triggers

- **"financial checklist"** → checklist

## Tools

Pure prompt — รับ stage แล้ว audit

## Task

1. **Foundation checklist**
2. **Operational checklist**
3. **Strategic checklist**
4. **Annual review**

## Examples

### FOUNDATION CHECKLIST

**Setup:**

```
□ Business registration complete
□ Tax ID + VAT (if applicable)
□ Bank accounts (separate)
□ Accounting software chosen
□ Accountant hired (if scaling)
□ Tax planning in place
□ Insurance coverage
□ Documentation system
```

—————————

**Daily/Weekly:**

```
□ Transactions recorded
□ Receipts captured + categorized
□ Bank reconciled (weekly)
□ AR aging reviewed
□ AP processed
□ Invoices sent promptly
```

—————————

**Monthly:**

```
□ P&L generated
□ Balance sheet generated
□ Cash flow review
□ Variance analysis
□ Tax filings (VAT, withholding, SS)
□ Payroll processed
□ Bank reconciliation complete
□ KPIs tracked
```

—————————

**Quarterly:**

```
□ Comprehensive review
□ Forecast updated
□ Budget vs actual
□ Tax estimates
□ Strategic adjustments
□ Specialist meetings
```

—————————

**Annually:**

```
□ Annual financial statements
□ Tax returns filed
□ Audit (if required)
□ Insurance renewals
□ Major contract reviews
□ Strategic planning next year
□ Reserve targets set
□ Exit preparation (if applicable)
```

---

### OPERATIONAL CHECKLIST

**Cash Flow:**

```
□ 13-week forecast updated
□ Reserves adequate (3-6 months)
□ DSO < 30 days target
□ DPO 30+ days
□ AR aging managed
□ Cash buffer maintained
```

—————————

**Pricing + Margins:**

```
□ Premium positioning verified
□ Margin per service tracked
□ Annual price increases planned
□ Pricing strategy documented
□ Competitive analysis annual
```

—————————

**Costs:**

```
□ Quarterly cost audit
□ Vendor contracts reviewed
□ Software audit annual
□ Personnel costs analyzed
□ Operational efficiency tracked
```

—————————

**KPIs:**

```
□ Critical KPIs identified (10-15)
□ Tracked monthly
□ Industry benchmarked
□ Action on variances
□ Dashboard accessible
```

---

### STRATEGIC CHECKLIST

**Growth:**

```
□ Annual budget aligned with goals
□ Growth investments planned
□ Team scaling matched to revenue
□ Geographic expansion considered
□ Product/service expansion planned
```

—————————

**Reserves:**

```
□ Operating reserve (6 months)
□ Tax reserve (annual)
□ Investment reserve
□ Emergency reserve
□ Specific purpose funds
```

—————————

**Tax Strategy:**

```
□ Annual tax planning
□ Maximize deductions
□ BOI privileges considered
□ Multi-year strategy
□ Estate planning (founder)
```

—————————

**Wealth Building:**

```
□ Founder personal compensation reasonable
□ Personal investments diversified
□ Real estate considered
□ Tax-advantaged investments
□ Estate planning
```

—————————

**Exit Preparation:**

```
□ 5-year exit horizon (if applicable)
□ Build sellable business
□ Documented processes
□ Diversified revenue
□ Strong team
□ Audited financials
```

---

### MAVERICK Y3 FINANCIAL HEALTH

**Status:**

```
✅ Foundation comprehensive
✅ Operations smooth
✅ Strategic clarity
✅ Cash positive
✅ Margins top tier
✅ Reserves adequate
✅ Tax compliance clean
✅ Specialists engaged
✅ Documentation thorough
✅ Pre-exit thinking begun

Score: 10/10
Effect: Strong financial foundation
```

—————————

**Annual Audit Findings:**

```
Strengths:
- Top tier margins
- Strong cash position
- Clean compliance
- Investor-grade reporting

Opportunities:
- DSO improvement (35 → 25 days)
- Tax planning depth
- Geographic expansion analysis
- Exit preparation

Action items:
- Q4 implement DSO improvements
- Engage M&A advisor early Y4
- Tax planning specialist
- Document for exit

Effect: Continuous improvement
```

---

### LONG-TERM PLAN

**5-Year Financial Roadmap:**

```
Y1: Foundation (฿1.5M revenue)
- Basic systems
- Profitable
- Limited Co Y2 prep

Y2: Refinement (฿8M)
- Comprehensive systems
- Specialists hired
- Premium pricing

Y3: Scale (฿15M) ✅ NOW
- Mature operations
- Strong margins
- Pre-exit thinking

Y4: Growth (฿26M projected)
- Continued growth
- Geographic expansion
- Exit prep continues

Y5: Maturity (฿40M projected)
- Industry leader
- Exit decision
- Major liquidity event possible

Y5-7: Exit + transition
- Sale to strategic buyer
- ฿100M+ liquidity
- Founder wealth secured

Effect: Long-term path
```

—————————

**Personal Wealth Path:**

```
Y1: ฿2M
Y3: ฿15M
Y5: ฿50M
Y10: ฿200M+ post-exit

Drivers:
- Business equity growth
- Personal investments
- Tax efficiency
- Compound returns

Effect: Wealth building
```

---

### FINANCIAL HEALTH METRICS

**Score Yourself:**

```
Foundation (10 pts):
- Setup complete: __/2
- Specialists engaged: __/2
- Documentation: __/2
- Insurance: __/2
- Compliance: __/2

Operations (10 pts):
- Cash flow managed: __/2
- Premium pricing: __/2
- Margin discipline: __/2
- KPIs tracked: __/2
- Cost control: __/2

Strategic (10 pts):
- Long-term plan: __/2
- Reserves built: __/2
- Tax efficiency: __/2
- Wealth building: __/2
- Exit preparation: __/2

Total: __/30

Scores:
- 25-30: Excellent
- 20-24: Strong
- 15-19: Improving
- 10-14: Concerning
- < 10: Critical action

Effect: Self-assessment
```

---

### FINANCIAL FOUNDATION PRINCIPLES

**Principle 1: Comprehensive**

✅ All areas covered
- Gaps = vulnerabilities

—————————

**Principle 2: Documented**

✅ Audit-ready
- Memory ไม่ enough

—————————

**Principle 3: Specialist support**

✅ Right expertise
- DIY major = mistakes

—————————

**Principle 4: Continuous improvement**

✅ Quarterly + annual reviews
- ไม่ static

—————————

**Principle 5: Long-term thinking**

✅ Years not months
- Quick fixes limited

---

### COMMON FOUNDATION MISTAKES

**❌ Skip checklist:**
- Random
- Gaps

**❌ Static:**
- Year-old version
- Outdated

**❌ Skip critical:**
- Tax compliance
- Cash flow
- Insurance

**❌ ไม่ specialist:**
- DIY major
- Mistakes

**❌ Reactive only:**
- Crisis mode

## Output Format

```
## Financial Final Checklist — [stage]

### Foundation Checklist
- Setup (8 items)
- Daily/Weekly (6 items)
- Monthly (8 items)
- Quarterly (6 items)
- Annually (8 items)

### Operational Checklist
- Cash flow (6 items)
- Pricing + margins (5 items)
- Costs (5 items)
- KPIs (5 items)

### Strategic Checklist
- Growth (5 items)
- Reserves (5 items)
- Tax strategy (5 items)
- Wealth building (5 items)
- Exit preparation (6 items)

### Maverick Y3 Health
- 10/10 score
- Strong foundation
- Top tier margins
- Pre-exit ready

### Score Yourself
- Foundation: __/10
- Operations: __/10
- Strategic: __/10
- Total: __/30

### Long-Term Plan (5 Years)
- Y1: Foundation (฿1.5M)
- Y3: Scale (฿15M) ✅
- Y5: Maturity (฿40M, exit possible)
- Y10+: Post-exit ฿200M+

### Principles (5)
1. Comprehensive
2. Documented
3. Specialist support
4. Continuous improvement
5. Long-term thinking

### Common Mistakes
❌ Skip checklist ❌ Static ❌ Skip critical ❌ ไม่ specialist ❌ Reactive
```

## Constraints

- Comprehensive coverage
- Annual reviews
- Specialist support
- Continuous improvement
- Long-term planning

## Anti-patterns

- ❌ Random approach
- ❌ Static documentation
- ❌ Skip foundational
- ❌ DIY major
- ❌ Reactive only

## Related Skills

- **accounting-basics** — basics
- **financial-planning** — planning

## Memory

- `user.financial_foundation` — foundation
