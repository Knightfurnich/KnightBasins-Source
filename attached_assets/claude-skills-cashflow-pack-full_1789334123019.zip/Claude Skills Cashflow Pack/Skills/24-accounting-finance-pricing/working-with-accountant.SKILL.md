---
name: Working With Accountant
id: working-with-accountant
category: finance
trigger:
  - "work with accountant"
  - "find accountant"
  - "accountant relationship"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Accountant Relationship Specialist — เข้าใจว่า great accountant = key business partner

## Context

ผู้ใช้คือ business

## Triggers

- **"accountant"** → accountant

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **Find right accountant**
2. **Build relationship**
3. **Cost management**
4. **Effective work**

## Examples

### TYPES OF ACCOUNTANTS

**Bookkeeper:**

```
Tasks:
- Daily transactions
- Bank reconciliation
- Basic categorization

Cost: ฿3-10K/month
Best for: Small operations
```

—————————

**Accountant (CPA in Thailand: ผู้สอบบัญชีรับอนุญาต):**

```
Tasks:
- Financial statements
- Tax preparation
- Compliance
- Strategic advice

Cost: ฿5-30K/month
Best for: Growing businesses
```

—————————

**Tax Specialist:**

```
Specific tax matters:
- Complex situations
- BOI applications
- International tax
- Audit defense

Cost: ฿20-100K/project
Best for: Specific issues
```

—————————

**CFO/Finance Director:**

```
Strategic financial leadership:
- Strategic planning
- Investor relations
- M&A advisory
- Board reporting

Cost: ฿100K-500K/month (or fractional)
Best for: Larger businesses
```

---

### FIND RIGHT ACCOUNTANT

**Where to Look:**

```
- Referrals (best)
- Industry associations
- LinkedIn search
- Bar association lists
- Online directories

Effect: Quality matters
```

—————————

**What to Look For:**

```
- Industry experience
- Reasonable rates
- Communication style
- Responsiveness
- Strategic vs transactional
- Tech-forward

Verify:
- License current
- References from clients
- No major issues

Effect: Right fit
```

—————————

**Interview Questions:**

```
- "How many businesses like mine?"
- "Tax planning approach?"
- "Communication style?"
- "Response time?"
- "Fee structure?"
- "Tools you use?"
- "References?"

Effect: Match assessment
```

—————————

**Maverick Search:**

```
Y2: Asked 5 founder friends
- Got 3 referrals
- Met all 3
- Chose specialist (skincare experience)
- ฿8K/month rate

Effect: Right accountant found
```

---

### BUILD RELATIONSHIP

**Be Good Client:**

```
- Provide info promptly
- Respect their time
- Pay on time
- Refer others (if great)
- Long-term mindset

Effect: Priority + better service
```

—————————

**Communication:**

```
Effective:
- Specific questions
- Organized info
- Documented requests
- Professional tone

ไม่:
- Last-minute requests
- Disorganized info
- Vague questions
- Multiple per day

Effect: Smooth relationship
```

—————————

**Regular Meetings:**

```
Recommended:
- Monthly: Quick check-in
- Quarterly: Comprehensive review
- Annually: Strategic + tax planning
- As needed: Specific issues

Effect: Strong partnership
```

---

### COST MANAGEMENT

**Fee Structures:**

```
Hourly:
- ฿1-5K/hour
- Pay for time

Flat fee:
- Specific tasks
- Predictable

Retainer:
- Monthly fixed fee
- Set scope of work
- Predictable

Effect: Match to needs
```

—————————

**Be Efficient:**

```
- Organized info
- Specific questions
- Templates filled
- Documents ready

Effect: Lower bills
```

—————————

**Maverick Cost Pattern:**

```
Y1 (sole prop): ฿0/month (DIY + annual)
Y2 (limited co): ฿8K/month
Y3 (12 employees): ฿15K/month + audit ฿50K
Y5 (25 employees): ฿30K/month + audit ฿100K

Annual: 1-3% of revenue
ROI: Significant (avoid mistakes + tax savings)
Effect: Worth investment
```

---

### EFFECTIVE WORK

**Provide:**

```
Monthly:
- Bank statements
- Receipts
- Invoices
- Payment proofs
- Specific changes

Annually:
- Major decisions
- Strategic plans
- Tax planning needs
- Compliance updates

Effect: Smooth operations
```

—————————

**Strategic Use:**

```
Beyond compliance:
- Tax planning
- Cash flow advice
- Pricing strategy
- Growth decisions
- Exit preparation

Effect: Strategic value
```

—————————

**Specialist Adds:**

```
When needed:
- Tax specialist (BOI, international)
- M&A advisor (exit)
- Industry specialist
- CFO (fractional)

Cost: Project basis
Effect: Specific expertise
```

---

### COMMON MISTAKES

**❌ DIY too long:**
- Mistakes accumulate
- Tax issues

**❌ Wrong fit:**
- ไม่ industry experience
- Personality clash

**❌ Provide info late:**
- Last-minute panic
- Higher fees

**❌ ไม่ communicate:**
- Vague questions
- Wrong answers

**❌ Treat transactional:**
- ไม่ strategic value
- Limited benefit

## Output Format

```
## Working With Accountant — [stage]

### 4 Types
1. Bookkeeper (฿3-10K/month)
2. Accountant/CPA (฿5-30K/month)
3. Tax Specialist (project-based)
4. CFO/Finance Director (฿100K-500K)

### Find Right
- Referrals best
- Industry experience
- Communication style
- License + references

### Build Relationship
- Be good client
- Effective communication
- Regular meetings
- Long-term mindset

### Cost Management
- Match fee structure
- Be efficient (organized)
- Maverick: 1-3% revenue typical

### Effective Work
- Provide monthly + annual info
- Strategic use beyond compliance
- Add specialists when needed

### Principles (5)
1. Right fit
2. Long-term relationship
3. Be organized
4. Strategic use
5. Pay promptly

### Common Mistakes
❌ DIY too long ❌ Wrong fit ❌ Late info ❌ ไม่ communicate ❌ Treat transactional
```

## Constraints

- Find industry-experienced
- Build long-term relationship
- Be organized client
- Use strategically
- Pay promptly

## Anti-patterns

- ❌ DIY major matters
- ❌ Wrong accountant fit
- ❌ Last-minute requests
- ❌ Transactional only
- ❌ Constant rotation

## Related Skills

- **accounting-basics** — basics
- **tax-compliance** — tax

## Memory

- `user.accountant_relationship` — relationship
