---
name: Customer Profitability
id: customer-profitability
category: finance
trigger:
  - "customer profitability"
  - "profitable customers"
  - "ltv calculation"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Customer Economics Specialist — เข้าใจว่า ไม่มี all customers profitable → analyze + optimize

## Context

ผู้ใช้คือ business

## Triggers

- **"customer profitability"** → profitability

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **Calculate per customer**
2. **Identify unprofitable**
3. **Optimize portfolio**
4. **Strategic decisions**

## Examples

### CALCULATE PER CUSTOMER

**Customer Profitability Formula:**

```
Customer Profit = Revenue - COGS - Direct Costs

Per customer:
- Revenue from them
- Direct costs serving them
- Allocated overhead (?)
- Profit per customer

Effect: Real profitability
```

—————————

**Maverick Customer Analysis Y3:**

```
Customer A: ฿2.5M revenue, ฿200K direct costs = ฿2.3M profit (92% margin)
Customer B: ฿1.8M revenue, ฿180K = ฿1.62M (90%)
Customer C: ฿1.2M revenue, ฿200K = ฿1M (83%)
Customer D: ฿1M revenue, ฿250K = ฿750K (75%)
Customer E: ฿900K revenue, ฿180K = ฿720K (80%)

All profitable but range:
- Top 3: 87% avg margin
- Bottom 2: 78% avg margin

Effect: Identify variations
```

—————————

**Customer LTV:**

```
LTV = Average annual profit × Average tenure

Maverick:
- Avg annual profit: ฿1.5M per customer
- Avg tenure: 28 months
- LTV: ฿1.5M × 2.33 years = ฿3.5M

Effect: Long-term value
```

—————————

**Customer Acquisition Cost (CAC):**

```
CAC = Total acquisition spend / New customers

Maverick:
- Annual marketing: ฿500K
- Sales effort cost: ฿1M
- Total: ฿1.5M
- New customers: 5
- CAC: ฿300K per customer

LTV:CAC = ฿3.5M / ฿300K = 11.6:1
Effect: Very healthy ratio
```

---

### IDENTIFY UNPROFITABLE

**Unprofitable Signs:**

```
- Low margin (vs others)
- High service cost
- Frequent issues
- Drama-prone
- Slow paying
- Time consuming

Calculate true cost:
- Direct costs
- Indirect time
- Manager attention
- Specialist requests

Effect: True picture
```

—————————

**Common Reasons Unprofitable:**

```
- Underpriced
- High service demands
- Specific requirements
- Managing them takes time
- High customization
- Frequent revisions

Effect: Identify causes
```

—————————

**Decision: Fix or Drop:**

```
Fix attempts:
- Renegotiate pricing
- Reduce scope
- Set boundaries
- Train customer

If fixed: Continue
If ไม่ fixed: Drop respectfully

Effect: Active management
```

—————————

**Maverick Process:**

```
Y3 review:
- Identified 1 customer ~70% margin
- vs 87% average
- Investigated:
  - Heavy revisions
  - Slow decision-making
  - Management time high

Action:
- Renegotiated scope
- Stricter timelines
- Higher pricing for revisions
- Improved to 82% margin

Effect: Optimized
```

---

### OPTIMIZE PORTFOLIO

**80/20 Rule:**

```
Often:
- 20% of customers = 80% of profit
- 20% of customers = 80% of issues

Strategies:
- Double-down on top 20% (profit)
- Optimize bottom 20% (issues)
- Acquire similar to top 20%

Effect: Strategic focus
```

—————————

**Customer Mix:**

```
Ideal portfolio:
- Diverse industries
- Different sizes
- ไม่มี > 25% concentration
- Premium > basic
- Long-term > short-term

Maverick mix:
- Top customer: 17% revenue ✅
- Top 5: 49% revenue (good)
- All: Premium positioning ✅
- Average tenure: 28 months ✅

Effect: Healthy portfolio
```

—————————

**Acquisition Targeting:**

```
Look for:
- Similar to best customers
- High potential LTV
- Strategic fit
- Cultural alignment
- Premium tier

Effect: Quality over quantity
```

—————————

**Pruning:**

```
Drop customers if:
- Persistently unprofitable
- Drama beyond worth
- Cultural mismatch
- Major opportunity cost

Method:
- Direct conversation
- Maybe price increase first
- Graceful exit if needed

Effect: Stronger portfolio
```

---

### STRATEGIC DECISIONS

**Pricing Strategy:**

```
For unprofitable:
- Increase prices
- Or reduce scope
- Or end relationship

For premium customers:
- Maintain pricing
- Add value (don't discount)
- Long-term contracts

Effect: Margin optimization
```

—————————

**Service Delivery:**

```
Match service to customer value:
- Premium: White-glove
- Standard: Documented processes
- Basic: Self-service options

Avoid:
- Premium service for basic price
- Resource misallocation

Effect: ROI alignment
```

—————————

**Customer Success:**

```
For high-value customers:
- Dedicated account manager
- Premium support
- Strategic check-ins
- Proactive value delivery

Effect: Retention + expansion
```

—————————

**Maverick Strategy:**

```
- Top 5 customers: Premium service
- Mid-tier: Standard delivery
- Test customers: Defined scope
- Continuous: Move up tiers
- Drop unprofitable
- Acquire similar to top

Effect: Portfolio optimization
```

---

### CHURN COST

**Lose Customer:**

```
Direct costs:
- Lost LTV
- Replacement cost (CAC)
- Operational disruption

Indirect:
- Reputation impact
- Team morale
- Other customers learn

Maverick churn cost:
- Lost LTV: ฿3.5M average
- Replacement CAC: ฿300K
- Total impact: ~฿4M per loss

Effect: Retention worth investment
```

—————————

**Retention vs Acquisition:**

```
Retain existing:
- 5x cheaper than acquire
- Higher margins (no CAC)
- Compound LTV
- Easier to upsell

Effect: Retention focus
```

---

### COMMON MISTAKES

**❌ All customers equal:**
- ไม่ analyze
- Resources misallocated

**❌ ไม่ measure profitability:**
- Don't know who profitable
- Bad decisions

**❌ Tolerate unprofitable:**
- Hope they'll change
- Drain resources

**❌ Ignore CAC:**
- Spend too much acquiring
- Negative LTV

**❌ Customer concentration:**
- > 30% from one
- Risky

## Output Format

```
## Customer Profitability — [stage]

### Calculate
- Revenue - Direct costs = Customer profit
- Per customer LTV
- CAC per customer
- LTV:CAC ratio (target 3:1+)

### Maverick Y3 Stats
- Range: 75-92% margins
- Avg LTV: ฿3.5M
- CAC: ฿300K
- LTV:CAC: 11.6:1

### Identify Unprofitable
- Low margin
- High service cost
- Drama
- Slow paying
- Time consuming

### Optimize Portfolio
- 80/20 rule
- Diverse customer mix
- Quality acquisition
- Drop persistent unprofitable

### Strategic Decisions
- Pricing optimization
- Service delivery match
- Customer success focus
- Acquisition targeting

### Churn Cost
- Lost LTV: ฿3.5M
- CAC replacement: ฿300K
- Total: ~฿4M per churn
- Retention 5x cheaper

### Common Mistakes
❌ All equal ❌ ไม่ measure ❌ Tolerate unprofitable ❌ Ignore CAC ❌ Concentration
```

## Constraints

- Calculate per customer
- Optimize portfolio
- Drop persistently unprofitable
- ไม่ customer concentration
- Quality acquisition

## Anti-patterns

- ❌ All customers equal
- ❌ ไม่ analyze profitability
- ❌ Tolerate drains
- ❌ Ignore CAC
- ❌ Concentration risk

## Related Skills

- **recurring-revenue** — recurring
- **financial-kpis** — KPIs

## Memory

- `user.customer_profitability` — profitability
