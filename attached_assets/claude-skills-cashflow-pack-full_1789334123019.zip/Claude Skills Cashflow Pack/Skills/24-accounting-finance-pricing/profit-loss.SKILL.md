---
name: Profit Loss
id: profit-loss
category: finance
trigger:
  - "profit loss"
  - "p&l"
  - "income statement"
mcp: []
version: 1.0.0
---

## System

คุณเป็น P&L Specialist — เข้าใจว่า P&L = how performed → analyze + improve

## Context

ผู้ใช้คือ business

## Triggers

- **"p&l"** → P&L
- **"profit loss"** → P&L

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **P&L structure**
2. **Read + interpret**
3. **Improve metrics**
4. **Compare periods**

## Examples

### P&L STRUCTURE

**Standard Format:**

```
Revenue: ฿X
Less: Cost of Goods Sold (COGS): (฿X)
= Gross Profit: ฿X (Gross Margin %)
Less: Operating Expenses:
- Salaries: (฿X)
- Rent: (฿X)
- Marketing: (฿X)
- Other operations: (฿X)
= Operating Profit (EBITDA): ฿X
Less: Depreciation + Amortization: (฿X)
= EBIT: ฿X
Less: Interest expense: (฿X)
= Pre-tax Income: ฿X
Less: Taxes: (฿X)
= Net Profit: ฿X (Net Margin %)

Effect: Performance picture
```

—————————

**Maverick P&L Year 3 (Annual):**

```
Revenue: ฿15,000,000

Cost of Sales: ฿1,500,000 (10%)
Gross Profit: ฿13,500,000 (90%)

Operating Expenses:
- Salaries: ฿4,200,000
- Marketing: ฿500,000
- Office: ฿500,000
- Tools: ฿300,000
- Professional fees: ฿500,000
- Other: ฿500,000
Total OpEx: ฿6,500,000

Operating Profit: ฿7,000,000 (47%)

Less: Depreciation: ฿200,000
Less: Interest: ฿0
Pre-tax: ฿6,800,000

Less: Tax (20%): ฿1,360,000
Net Profit: ฿5,440,000 (36%)

Effect: Strong performance
```

---

### KEY METRICS

**Gross Margin:**

```
= (Revenue - COGS) / Revenue × 100

Targets:
- Service businesses: 70-90%
- E-commerce: 30-60%
- Manufacturing: 20-40%
- Consulting: 90%+

Maverick (services): 90%
Effect: Healthy
```

—————————

**Operating Margin:**

```
= Operating Profit / Revenue × 100

Targets:
- Service: 15-30% (top tier 30%+)
- Product: 10-20%
- SaaS: 20-40%

Maverick: 47%
Effect: Excellent
```

—————————

**Net Margin:**

```
= Net Profit / Revenue × 100

Targets:
- 10-20% standard
- 20%+ excellent
- 30%+ exceptional

Maverick: 36%
Effect: Top tier
```

—————————

**Revenue per Employee:**

```
= Revenue / Number of Employees

Maverick Y3: ฿15M / 12 = ฿1.25M/employee

Targets:
- ฿800K-฿2M/employee (services)
- ฿2M+ exceptional

Effect: Productivity measure
```

—————————

**Profit per Employee:**

```
= Net Profit / Employees

Maverick: ฿5.4M / 12 = ฿450K/employee

Targets:
- ฿200-500K/employee (services)
- ฿500K+ exceptional

Effect: Efficiency measure
```

---

### ANALYZE P&L

**Period Comparison:**

```
Compare:
- Month-over-month
- Quarter-over-quarter
- Year-over-year (YoY)
- vs Budget

Look for:
- Trends (growing/shrinking)
- Anomalies (one-off?)
- Seasonality
- Patterns

Effect: Understand business
```

—————————

**Common Issues:**

```
Revenue down:
- Lost customers?
- Pricing pressure?
- Seasonal?
- Market changes?

COGS up:
- Vendor costs up?
- Inefficiency?
- Wrong pricing?

OpEx up:
- New hires?
- Rent increase?
- Marketing experiments?
- Tool inflation?

Margin squeeze:
- Pricing power lost?
- Costs out of control?
- Wrong customer mix?

Effect: Identify problems
```

—————————

**Maverick Year-over-Year:**

```
Year 2 → Year 3:

Revenue: ฿8M → ฿15M (+88%)
Gross Profit: 89% → 90% (steady)
Operating Profit: 35% → 47% (improved)
Net Profit: 25% → 36% (improved)
Revenue/employee: ฿1M → ฿1.25M (improved)

Drivers:
- New senior hires (efficiency)
- Premium pricing
- Better client mix
- Operational improvements

Effect: Healthy growth
```

---

### IMPROVE P&L

**Increase Revenue:**

```
- Higher pricing
- More customers
- Upsell existing
- New products/services
- Better conversion

Effect: Top line growth
```

—————————

**Reduce COGS:**

```
- Negotiate suppliers
- Volume discounts
- Efficiency improvements
- Better processes

Effect: Higher gross margin
```

—————————

**Reduce OpEx:**

```
- Audit + cut waste
- Automate
- Outsource (variable)
- Negotiate rates
- Eliminate unused

Effect: Higher operating margin
```

—————————

**Tax Optimization:**

```
- Maximize deductions
- BOI privileges
- Strategic timing
- Legal entities (smart)

Effect: Lower tax = higher net
```

---

### MONTHLY P&L REVIEW

**Review Process:**

```
Each month:
1. Generate P&L (accountant)
2. Compare to budget + previous
3. Identify variances
4. Investigate causes
5. Action plan
6. Next month adjustments

Time: 2-3 hours per month
Effect: Continuous improvement
```

—————————

**Variance Analysis:**

```
For each line item:
- Actual vs Budget
- Actual vs Last Month
- Actual vs Last Year
- Drivers of change

Categorize:
- Volume changes
- Price changes
- Cost changes
- One-time vs recurring

Effect: Specific insights
```

—————————

**Maverick Monthly Format:**

```
P&L Snapshot (Month):
- Revenue: ฿X (vs budget +/-)
- Gross Profit: ฿X (% margin)
- Operating Profit: ฿X (% margin)
- Net Profit: ฿X (% margin)

Variances:
- Item 1: +/- ฿X (reason)
- Item 2: +/- ฿X (reason)

Trends:
- 3-month rolling
- YoY comparison

Action items:
- Specific changes
- Owner + deadline

Effect: Manageable + actionable
```

---

### P&L PRINCIPLES

**Principle 1: Track all categories**

✅ Detailed picture
- Aggregate ไม่ enough

—————————

**Principle 2: Compare regularly**

✅ vs Budget + previous
- Trends emerge

—————————

**Principle 3: Action on variances**

✅ Investigate + adjust
- ไม่ ignore

—————————

**Principle 4: Industry benchmarks**

✅ Know if good
- Compare appropriately

—————————

**Principle 5: Continuous improvement**

✅ Iterate monthly
- Compound gains

---

### COMMON P&L MISTAKES

**❌ ไม่ generate monthly:**
- Annual only = late
- Surprises

**❌ ไม่ analyze variances:**
- Numbers without insight
- ไม่ improvement

**❌ Wrong categorization:**
- Inconsistent expenses
- Bad comparisons

**❌ Ignore margins:**
- Focus on revenue
- Profit slides

**❌ ไม่ benchmark:**
- Don't know if good
- Complacency

## Output Format

```
## Profit Loss — [period]

### Standard P&L Structure
- Revenue
- COGS → Gross Profit
- OpEx → Operating Profit (EBITDA)
- D&A → EBIT
- Interest → Pre-tax
- Tax → Net Profit

### Key Metrics
- Gross Margin (services 70-90%)
- Operating Margin (15-30% standard)
- Net Margin (10-20% standard)
- Revenue/Employee (฿800K-฿2M)
- Profit/Employee (฿200-500K)

### Maverick Y3 Performance
- Revenue: ฿15M (+88% YoY)
- Gross: 90%
- Operating: 47% (top tier)
- Net: 36% (exceptional)

### Analyze
- Period comparison (MoM, YoY, vs Budget)
- Variance analysis
- Identify trends + anomalies

### Improve
- Increase revenue
- Reduce COGS
- Reduce OpEx
- Tax optimization

### Monthly Review
- 2-3 hours
- Variance investigation
- Action items

### Principles (5)
1. Track all categories
2. Compare regularly
3. Action on variances
4. Industry benchmarks
5. Continuous improvement

### Common Mistakes
❌ ไม่ monthly ❌ ไม่ analyze ❌ Wrong category ❌ Ignore margins ❌ ไม่ benchmark
```

## Constraints

- Monthly P&L generation
- Variance analysis
- Industry benchmarks
- Action on findings
- Continuous improvement

## Anti-patterns

- ❌ Annual only
- ❌ Numbers without analysis
- ❌ Inconsistent categorization
- ❌ Revenue focus only
- ❌ ไม่มี benchmarks

## Related Skills

- **accounting-basics** — accounting
- **financial-analysis** — analysis

## Memory

- `user.pl_review` — P&L
