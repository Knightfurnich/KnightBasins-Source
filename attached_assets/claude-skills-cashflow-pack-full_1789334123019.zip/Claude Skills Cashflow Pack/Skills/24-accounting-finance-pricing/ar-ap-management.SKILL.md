---
name: AR AP Management
id: ar-ap-management
category: finance
trigger:
  - "accounts receivable"
  - "accounts payable"
  - "ar ap"
mcp: []
version: 1.0.0
---

## System

คุณเป็น AR/AP Specialist — เข้าใจว่า AR (money owed to you) + AP (money you owe) = working capital management

## Context

ผู้ใช้คือ business

## Triggers

- **"ar"** → AR
- **"ap"** → AP

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **AR management**
2. **AP management**
3. **Optimization**
4. **Tools**

## Examples

### ACCOUNTS RECEIVABLE (AR)

**What's AR:**

```
Money customers owe you:
- Invoiced but ไม่ paid yet
- Asset on balance sheet
- Eventually cash

Effect: Future cash
```

—————————

**AR Aging:**

```
Categorize by age:
- Current (< 30 days): Healthy
- 30-60 days: Watch
- 60-90 days: Action
- 90+ days: Problem
- 120+ days: Likely bad debt

Maverick Y3:
- Current: 70%
- 30-60: 25%
- 60-90: 4%
- 90+: 1%
- Healthy

Effect: Collection priorities
```

—————————

**Manage AR:**

```
- Invoice promptly (same day)
- Net 14 days terms
- Auto-reminders (7 days, due, late)
- Personal follow-up (30+ days)
- Late fees enforced
- Stop work if chronic late
- Write off if uncollectable

Effect: Faster cash
```

—————————

**DSO Target:**

```
DSO (Days Sales Outstanding):
- < 30 days: Excellent
- 30-45: Good
- 45-60: Concerning
- 60+: Problem

Maverick Y3: 35 days
Target: < 30

Action:
- Stricter terms
- Faster reminders
- Personal calls

Effect: Cash flow
```

---

### ACCOUNTS PAYABLE (AP)

**What's AP:**

```
Money you owe vendors:
- Invoices received
- ไม่ paid yet
- Liability on balance sheet

Effect: Future outflow
```

—————————

**Manage AP:**

```
Strategy: Take maximum allowed time
- Net 30 typically
- Some Net 60+
- Pay on due date (ไม่ early)
- Use credit cards (30-60 day float)

Effect: Cash retained longer
```

—————————

**DPO Target:**

```
DPO (Days Payable Outstanding):
- < 15 days: Paying too fast
- 15-30: Standard
- 30-45: Optimal
- 45+: ตอน borderline (vendor unhappy)

Maverick Y3: 25 days
Target: 35 days

Action:
- Negotiate Net 30+ with vendors
- Use credit cards
- Pay on due date

Effect: Working capital
```

—————————

**ไม่ Stretch Too Far:**

```
ไม่:
- Pay 60+ days when Net 30
- Damage vendor relationships
- Lose discounts
- Reputation impact

Effect: Balance + relationships
```

---

### CASH CONVERSION CYCLE

**Formula:**

```
CCC = DSO + DIO - DPO

DSO: How fast collect (lower = better)
DIO: How fast inventory sells (lower = better)
DPO: How fast pay (higher = better for you)

Lower CCC = better cash position
```

—————————

**Maverick CCC:**

```
- DSO: 35 days
- DIO: 0 (services)
- DPO: 25 days
- CCC: 10 days

Target: < 5 days

Action:
- DSO 35 → 25 (-10 days)
- DPO 25 → 35 (+10 days)
- Net: -20 days CCC
- ฿800K cash freed

Effect: Significant
```

---

### TOOLS

**AR Management:**

```
Built-in (most accounting):
- Xero, QuickBooks, Bonsai
- Auto-reminders
- AR aging reports
- Invoice tracking

Specialized:
- Bill.com
- Specific collections software

Cost: Built-in mostly
Effect: Automated
```

—————————

**AP Management:**

```
Built-in accounting tools
Plus:
- Approval workflows
- Bulk payments
- Schedule payments
- Vendor management

Effect: Streamlined
```

—————————

**Maverick Tools:**

```
Xero handles both:
- AR aging report (weekly)
- Auto-reminders setup
- AP scheduling
- Bank integration

Cost: ฿2K/month
Effect: Comprehensive
```

---

### COMMON MISTAKES

**❌ Slow AR:**
- ไม่ chase
- Money sits

**❌ Pay AP too fast:**
- Lose float
- Cash earlier

**❌ ไม่ track aging:**
- Surprise bad debts

**❌ ไม่ enforce:**
- Late fees ignored
- Customers train

**❌ Damage vendor relationships:**
- Stretch too far
- Lose discounts

## Output Format

```
## AR AP Management — [stage]

### AR (Money Owed to You)
- Aging categories (current → 120+ days)
- Manage: Prompt invoicing + reminders + late fees
- DSO target < 30 days

### AP (Money You Owe)
- Strategy: Take maximum allowed time
- DPO target 30-45 days
- ไม่ stretch too far (relationships)

### Cash Conversion Cycle
- CCC = DSO + DIO - DPO
- Maverick: 10 days (target < 5)
- ฿800K cash potentially freed

### Tools
- Built-in: Xero, QuickBooks
- Specialized: Bill.com
- Maverick: Xero (฿2K/month)

### Common Mistakes
❌ Slow AR ❌ Pay AP too fast ❌ ไม่ track aging ❌ ไม่ enforce ❌ Damage relationships
```

## Constraints

- DSO < 30 days
- DPO 30-45 days
- Active aging management
- Tools automate
- Maintain relationships

## Anti-patterns

- ❌ Slow collections
- ❌ Pay vendors too early
- ❌ ไม่ track aging
- ❌ Tolerate slow payers
- ❌ Stretch vendors too far

## Related Skills

- **cash-flow-management** — cash
- **working-capital** — capital

## Memory

- `user.ar_ap` — AR/AP
