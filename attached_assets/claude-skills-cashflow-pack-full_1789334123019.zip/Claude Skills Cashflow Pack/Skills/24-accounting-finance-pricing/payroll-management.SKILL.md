---
name: Payroll Management
id: payroll-management
category: finance
trigger:
  - "payroll"
  - "salary processing"
  - "เงินเดือน"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Payroll Specialist (Thai overview) — เข้าใจว่า payroll = critical compliance + employee trust → ผิด = problems

## Context

ผู้ใช้คือ business

## Triggers

- **"payroll"** → payroll
- **"เงินเดือน"** → เงินเดือน

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **Payroll components**
2. **Tax + deductions**
3. **Process**
4. **Compliance**

## Examples

### PAYROLL COMPONENTS

**Gross Salary:**

```
Components:
- Base salary
- Bonuses
- Overtime (if applicable)
- Commissions
- Allowances (transport, meal)
- Benefits (housing)

Effect: Total earnings
```

—————————

**Deductions (From Gross):**

```
Mandatory:
- Personal income tax (PIT)
- Social Security (5%, capped)
- Workmen's Comp (employer pays separately)

Optional:
- Provident fund
- Insurance contributions
- Loans repayments
- Other deductions

Effect: Net pay calculated
```

—————————

**Net Salary:**

```
Net = Gross - Deductions

Example:
- Gross: ฿80,000
- PIT: ฿5,000
- Social Security: ฿750 (5% of ฿15K cap)
- Provident fund: ฿4,000 (5% match)
- Net: ฿70,250

Effect: Take-home
```

---

### CALCULATE PIT (Personal Income Tax)

**Annual Calculation:**

```
Annual gross: ฿1M
Less: Standard deductions
- 50% (or actual): ฿500K
- Personal allowance: ฿30K
- Other allowances: ฿20K

Taxable income: ฿450K

PIT (Brackets):
- ฿0-150K: 0% = 0
- ฿150K-300K: 5% = ฿7,500
- ฿300K-500K: 10% = ฿15,000
- Total annual: ฿22,500
- Monthly: ฿1,875

Effect: Withholding monthly
```

—————————

**Monthly Estimation:**

```
Estimate annual:
- Monthly × 12 = annual
- Calculate annual tax
- Divide by 12 = monthly
- Withhold + pay

Year-end:
- True-up
- Refund or additional

Effect: Smooth payment
```

—————————

**PND.1 Filing:**

```
Monthly:
- Filed by 7th of next month
- Per employee detail
- Total tax withheld
- Submit to Revenue Department

Online or paper
Effect: Compliance
```

---

### SOCIAL SECURITY

**Contribution:**

```
Both pay 5% (capped at salary ฿15K):
- Employer: 5% × ฿15K max = ฿750
- Employee: 5% × ฿15K max = ฿750
- Total: ฿1,500/employee/month

Coverage:
- Medical
- Maternity
- Disability/death
- Retirement
- Unemployment

Effect: Worker safety net
```

—————————

**Filing:**

```
Monthly:
- 15th of next month
- Online or branch
- Per employee
- Total contribution

Effect: Monthly compliance
```

---

### PAYROLL PROCESS

**End of Month:**

```
1. Calculate hours/days
2. Calculate gross (salary + extras)
3. Calculate deductions
4. Calculate net
5. Generate pay slips
6. Process payments
7. File taxes (next month)

Time: Hours to days depending on size
Effect: Monthly cycle
```

—————————

**Pay Slip Components:**

```
Required:
- Employee details
- Period covered
- Gross breakdown
- Deductions itemized
- Net amount
- Year-to-date totals
- Bank/account info

Effect: Transparency + records
```

—————————

**Payment Methods:**

```
- Bank transfer (most common)
- Bulk upload to bank
- Direct deposit
- Cheque (rare)
- Cash (small businesses)

Best: Bulk upload (efficient)
Effect: Smooth processing
```

—————————

**Maverick Process (12 Employees):**

```
End of month (last day):
- Calculate variable comp (bonuses)
- Verify hours
- Generate pay slips (Xero)
- Bulk upload to SCB
- Schedule for last day of month

Next month:
- 7th: PND.1 filed
- 15th: Social Security filed
- Pay slips distributed (digital)

Time: 4-6 hours total
Cost: ฿0 (in-house with Xero)
Effect: Efficient
```

---

### COMPLIANCE

**Tax Filing:**

```
- PND.1 (monthly): 7th of next month
- PND.91/94 (annual employees): March/May
- ภงด. (annual employer summary): March 31

Effect: Mandatory deadlines
```

—————————

**Records Retention:**

```
Keep 5+ years:
- Pay slips
- Tax filings
- Social Security records
- Employment contracts
- Bonuses + adjustments

Format: Digital + backup
Effect: Audit-ready
```

—————————

**Payroll Audit:**

```
Possible audits:
- Random Revenue audit
- Social Security audit
- Labor Department complaint

Be prepared:
- All records organized
- Compliance verified
- Specialists involved if audit

Effect: Smooth process
```

---

### TOOLS

**Free/Manual:**

```
- Excel templates
- Free Bank's HR tools
- Manual calculation

Best for: 1-3 employees
Cost: ฿0
Effect: Sufficient
```

—————————

**Paid:**

```
- Xero Payroll: ฿200-500/employee/month
- QuickBooks Payroll: similar
- Specific Thai HR (HumanSoft, etc.)
- HR + Payroll integrated

Cost: ฿2K-20K/month
Effect: Time saved + compliance
```

—————————

**Outsource:**

```
Payroll service:
- ฿1,000-3,000/employee/month
- Full service
- Compliance handled
- Records maintained

Best for:
- 10+ employees
- ไม่มี time
- Want hands-off

Effect: Outsource complexity
```

—————————

**Maverick Stack:**

```
- Xero Payroll (12 employees)
- ฿4K/month total
- Bank API integration (SCB)
- Automated filings
- Records auto-maintained

Effect: Efficient + compliant
```

---

### COMMON PAYROLL MISTAKES

**❌ Late filings:**
- PND.1, Social Security
- Penalties accrue

**❌ Wrong calculations:**
- Tax errors
- Employee disputes
- Compliance issues

**❌ ไม่ pay slips:**
- Required by law
- Employee trust

**❌ Mix with personal:**
- Same account
- Audit nightmare

**❌ Skip overtime:**
- Required by law
- Lawsuits possible

## Output Format

```
## Payroll Management — [size]

### Components
- Gross (salary + bonuses + allowances)
- Deductions (PIT, Social Security, optional)
- Net = Gross - Deductions

### PIT Calculation
- Standard 50% deduction or actual
- Plus allowances
- Brackets 0-35%
- Monthly withholding

### Social Security
- 5% each (employee + employer)
- Capped at ฿15K salary
- ฿1,500/employee/month max
- Monthly filing 15th

### Process
- End of month: Calculate + generate
- Bulk upload bank
- 7th: PND.1 filed
- 15th: Social Security filed
- Records 5+ years

### Tools
- Manual: Excel
- Software: Xero (฿2-20K/month)
- Outsource: ฿1K-3K/employee

### Maverick Setup
- Xero Payroll
- 12 employees
- ฿4K/month
- Automated

### Compliance
- Monthly filings (PND.1, SSO)
- Annual filings
- 5-year records
- Audit-ready

### Common Mistakes
❌ Late filings ❌ Wrong calculations ❌ ไม่ pay slips ❌ Mix accounts ❌ Skip overtime
```

## Constraints

- File on time (PND.1 7th, SSO 15th)
- Accurate calculations
- Pay slips required
- 5-year retention
- Compliance maintained

## Anti-patterns

- ❌ Late filings
- ❌ Calculation errors
- ❌ Skip pay slips
- ❌ Mix accounts
- ❌ Skip overtime

## Related Skills

- **employment-law** — employment
- **tax-compliance** — tax

## Memory

- `user.payroll` — payroll
