---
name: Financial Dashboard
id: financial-dashboard
category: finance
trigger:
  - "financial dashboard"
  - "kpi dashboard"
  - "metrics dashboard"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Dashboard Specialist — เข้าใจว่า dashboard = at-a-glance health → ไม่มี = blind

## Context

ผู้ใช้คือ business

## Triggers

- **"dashboard"** → dashboard

## Tools

Pure prompt — รับ business แล้ว design

## Task

1. **Critical metrics**
2. **Visualization**
3. **Update cadence**
4. **Actions**

## Examples

### CRITICAL METRICS (Top Section)

**Daily/Weekly:**

```
- Cash position
- AR aging
- Sales pipeline
- Major issues

Effect: Quick check
```

—————————

**Monthly Strategic:**

```
- Revenue (vs budget + YoY)
- Profit (margin %)
- Cash flow
- Key KPIs vs targets

Effect: Strategic view
```

—————————

**Quarterly:**

```
- Trend analysis
- Scenario tracking
- Strategic adjustments
- Industry comparisons

Effect: Direction
```

---

### MAVERICK DASHBOARD

**Top Section (Daily View):**

```
💰 CASH POSITION
- Operating cash: ฿5M
- vs Last week: +฿200K
- Runway: 6 months

📊 THIS MONTH
- Revenue: ฿1.2M (target ฿1.25M)
- New leads: 8
- Active projects: 12

🎯 KPI DASHBOARD
- DSO: 32 days (target < 30) ⚠️
- Utilization: 78% (target 75%) ✅
- Customer retention: 92% ✅
- All revenue tier 1: ฿900K ✅

⚠️ ALERTS
- Brand A invoice overdue (Day 45)
- Office lease renewal Q4
```

—————————

**Mid Section (Weekly):**

```
📈 TRENDING
- Revenue: 88% YoY ✅
- Margin: 47% (top tier) ✅
- New clients: 4 this quarter

⚖️ FINANCIAL HEALTH
- Current ratio: 6.7 ✅
- Quick ratio: 6.2 ✅
- Debt-to-equity: 0.1 ✅

🛒 PIPELINE
- New: 4 leads
- Discovery: 3 calls
- Proposal: 2 active
- Close this month: 1 expected

🎓 TEAM
- Headcount: 12
- Utilization: 78%
- Engagement: 4.5/5
- New hires: 2 in Q4
```

—————————

**Bottom Section (Strategic):**

```
🚀 GROWTH PROJECTS
- Q4 marketing campaign launched
- New service line testing
- Geographic expansion analysis

📋 ACTIONS NEEDED
1. DSO improvement (Q4)
2. Hire senior marketer
3. Annual planning Q4

🎯 ANNUAL VISION
- Revenue: ฿15M ✅ (97% to target)
- Net Profit: ฿5M+ ✅
- Customer base: 14 ✅
- Team: 12 (planned 12) ✅
```

---

### VISUALIZATION

**Key Charts:**

```
1. Revenue trend (12 months bar chart)
2. Margin trend (line chart)
3. Cash position (area chart)
4. AR aging (stacked bar)
5. KPI gauge (vs target)

Tools:
- Looker Studio (free)
- Power BI
- Tableau
- Excel/Sheets

Effect: Quick comprehension
```

—————————

**Color Coding:**

```
- Green: Above target
- Yellow: Mixed
- Red: Below target
- Gray: Neutral

Effect: At-a-glance status
```

—————————

**Layout Principles:**

```
- Most critical at top
- Visual + numbers
- Whitespace generous
- ไม่ cluttered
- Single screen ideally

Effect: Easy use
```

---

### UPDATE CADENCE

**Auto-Update (Real-Time):**

```
Connected to:
- Bank API (cash)
- Accounting system
- CRM (pipeline)
- HR system (team)
- Project tools

Effect: Live data
```

—————————

**Daily:**

```
- Cash position
- New leads
- Major changes

Time: 5 mins/day
Effect: Daily pulse
```

—————————

**Weekly:**

```
- Pipeline progress
- Team metrics
- Operational status

Time: 15-30 mins
Effect: Weekly rhythm
```

—————————

**Monthly:**

```
- Comprehensive review
- vs Budget analysis
- Strategic adjustments

Time: 2-3 hours
Effect: Strategic
```

---

### TOOLS

**Free:**

```
- Looker Studio (Google Data Studio)
- Excel + Sheets
- Notion (basic)

Effect: Sufficient for many
```

—————————

**Paid:**

```
- Tableau (฿2K-5K/user/month)
- Power BI (฿700-2K/user)
- Domo (enterprise)

Effect: More powerful
```

—————————

**Integrated:**

```
- Xero dashboards (built-in)
- QuickBooks dashboards
- Specific accounting + dashboard

Effect: Integrated data
```

—————————

**Maverick Stack:**

```
- Looker Studio (main dashboard)
- Connected to:
  - Xero (financials)
  - HubSpot (CRM)
  - Notion (operations)
- Cost: ฿0/month
- Effect: Comprehensive free
```

---

### DASHBOARD PRINCIPLES

**Principle 1: Action-driving**

✅ Every metric → decision
- Vanity = waste

—————————

**Principle 2: Visual + numbers**

✅ Both
- Numbers alone = ไม่ scan

—————————

**Principle 3: Real-time when possible**

✅ Auto-update
- Stale = misleading

—————————

**Principle 4: Single screen**

✅ ไม่ scroll forever
- Critical visible

—————————

**Principle 5: Update + iterate**

✅ Refine over time
- Stale = decline

---

### COMMON DASHBOARD MISTAKES

**❌ Too many metrics:**
- Information overload
- Can't focus

**❌ Vanity metrics:**
- Followers, likes
- ไม่ action-driving

**❌ Stale data:**
- Manual updates
- Outdated

**❌ ไม่ visual:**
- Spreadsheet only
- Hard to scan

**❌ ไม่ใช้:**
- Build + ignore
- Wasted

## Output Format

```
## Financial Dashboard — [scope]

### Critical Metrics by Cadence
- Daily: Cash, leads, alerts
- Weekly: Pipeline, team, ops
- Monthly: P&L, KPIs, trends
- Quarterly: Strategic + scenarios

### Maverick Dashboard
- Top: Cash + this month + KPIs
- Mid: Trends + health + pipeline
- Bottom: Growth + actions + vision

### Visualization
- Key charts (revenue, margin, cash)
- Color coding (red/yellow/green)
- Single screen layout

### Update Cadence
- Auto (real-time)
- Daily check (5 min)
- Weekly review (15-30 min)
- Monthly strategic (2-3 hrs)

### Tools
- Free: Looker Studio, Sheets, Notion
- Paid: Tableau, Power BI

### Maverick Stack
- Looker Studio main
- Connected to Xero + HubSpot + Notion
- ฿0/month
- Comprehensive

### Principles (5)
1. Action-driving
2. Visual + numbers
3. Real-time when possible
4. Single screen
5. Update + iterate

### Common Mistakes
❌ Too many metrics ❌ Vanity ❌ Stale data ❌ ไม่ visual ❌ ไม่ใช้
```

## Constraints

- Action-driving metrics only
- Visual + numbers
- Real-time data
- Single screen
- Daily use

## Anti-patterns

- ❌ 30+ metrics
- ❌ Vanity metrics
- ❌ Manual updates
- ❌ Spreadsheet only
- ❌ Build + ignore

## Related Skills

- **financial-kpis** — KPIs
- **financial-analysis** — analysis

## Memory

- `user.financial_dashboard` — dashboard
