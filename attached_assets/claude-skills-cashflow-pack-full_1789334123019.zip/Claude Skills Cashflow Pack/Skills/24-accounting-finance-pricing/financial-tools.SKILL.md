---
name: Financial Tools
id: financial-tools
category: finance
trigger:
  - "financial tools"
  - "accounting software"
  - "bookkeeping software"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Financial Tools Specialist — เข้าใจว่า right tools = automate + insights → wrong = waste time

## Context

ผู้ใช้คือ business

## Triggers

- **"financial tools"** → tools
- **"accounting software"** → software

## Tools

Pure prompt — รับ situation แล้ว recommend

## Task

1. **Tool categories**
2. **Compare options**
3. **Right stack per stage**
4. **Integration**

## Examples

### CATEGORIES OF FINANCIAL TOOLS

**Accounting:**

```
Solo/Small:
- Wave (free)
- Manager.io (free)
- ZipBooks (free + paid)

Mid-size:
- Bonsai (฿700/month)
- FreshBooks (฿700-2K)
- QuickBooks (฿700-3K)
- Xero (฿700-2.5K)

Enterprise:
- SAP
- Oracle
- NetSuite

Effect: Books maintained
```

—————————

**Invoicing:**

```
Built-in (most accounting tools)
Or specialized:
- Bonsai
- HoneyBook
- Wave Invoicing

Effect: Bills sent
```

—————————

**Expense Tracking:**

```
- Expensify
- Receipt Bank
- Bonsai
- Built into accounting

Effect: Expenses captured
```

—————————

**Time Tracking:**

```
- Toggl
- Harvest
- Clockify
- Built-in tools

Effect: Hours tracked
```

—————————

**Cash Flow Forecasting:**

```
- Float
- Pulse
- Excel templates
- Custom dashboards

Effect: 13-week visibility
```

—————————

**Financial Analysis:**

```
- Excel/Sheets (powerful + free)
- Looker Studio (free)
- Tableau (paid)
- Power BI (Microsoft)

Effect: Insights
```

—————————

**Budgeting:**

```
- Built-in (most accounting tools)
- Specific: PlanGuru, Vena
- Excel/Sheets templates

Effect: Plan + track
```

—————————

**Tax Software:**

```
- Bonsai (basic)
- Specific Thai tax software
- Outsource to accountant

Effect: Tax compliance
```

—————————

**Payroll:**

```
- Xero Payroll
- QuickBooks Payroll
- Specific HR software
- Outsource

Effect: Salary processing
```

—————————

**Banking:**

```
- Bank online (SCB, BBL, etc.)
- API integration where possible
- PromptPay
- Multi-currency

Effect: Transaction processing
```

---

### COMPARE TOP TOOLS

**Bonsai:**

```
Pros:
- All-in-one (invoicing, contracts, time, taxes)
- Freelance + small business focused
- Easy + intuitive
- Affordable

Cons:
- Less powerful for larger
- Limited customization
- Thai support limited

Best for: Solo, freelancers, small SME
Cost: ฿700/month
```

—————————

**Xero:**

```
Pros:
- Very powerful
- Many integrations
- Strong financial reports
- Multi-currency
- Bank feeds (some Thai banks)

Cons:
- Higher cost
- Learning curve
- Less Thai-specific

Best for: Growing SME, scaling
Cost: ฿700-2.5K/month
```

—————————

**QuickBooks:**

```
Pros:
- Industry standard
- Many features
- Strong reports
- Robust

Cons:
- Higher cost
- Complex
- Less Thai-specific

Best for: Established companies
Cost: ฿700-3K/month
```

—————————

**Wave:**

```
Pros:
- Free
- Decent features
- Good for solo
- Bank feeds

Cons:
- Limited features
- Less powerful
- Less support

Best for: Solo founders, very small
Cost: Free
```

—————————

**Specific Thai (FlowAccount, etc.):**

```
Pros:
- Thai-specific
- VAT compliance
- PND.1 forms
- Local support

Cons:
- Less features overall
- Smaller ecosystem

Best for: Thai-specific businesses
Cost: ฿500-3K/month
```

---

### MAVERICK FINANCIAL STACK

**Year 1 (Solo):**

```
- Wave (accounting + invoicing)
- Toggl (time tracking)
- Excel (analysis + budget)

Cost: ฿0/month
Effect: Sufficient
```

—————————

**Year 2 (Limited Co, ฿2M):**

```
- Bonsai (all-in-one)
- Toggl Pro (฿200)
- Excel/Sheets

Cost: ฿900/month
Effect: Comprehensive
```

—————————

**Year 3 (12 employees, ฿15M):**

```
- Xero (accounting + payroll)
- Looker Studio (dashboards)
- Toggl (time)
- Bank API integration
- Notion (analysis docs)

Cost: ฿4K/month
Effect: Mature stack
```

—————————

**Year 5+ (25 employees, ฿40M):**

```
- Xero + advanced
- Custom dashboards
- Specialized analytics
- Treasury management
- Multi-bank integration

Cost: ฿15K-30K/month
Effect: Enterprise capability
```

---

### INTEGRATION

**Why Integrate:**

```
Benefits:
- Auto data flow
- Less manual entry
- Real-time insights
- ไม่มี errors
- Time saved

Common integrations:
- Bank → Accounting
- Accounting → Dashboards
- POS → Accounting
- Time → Payroll
- Invoicing → Accounting

Effect: Automation
```

—————————

**Setup:**

```
Through:
- Native integrations (built-in)
- Zapier (connect anything)
- Make.com (advanced)
- API custom (developers)

Cost:
- Native: Free
- Zapier: ฿700-2.5K/month
- Make: ฿700-1.5K
- API: One-time dev

Effect: Connected stack
```

—————————

**Maverick Integrations:**

```
- SCB → Xero (auto bank feed)
- Stripe → Xero (auto)
- Bonsai → Xero (data sync)
- Xero → Looker (dashboards)
- Notion → Various (project mgmt)

Effect: Single source of truth
```

---

### CHOOSING TOOLS

**Match to Stage:**

```
Solo: Free tools (Wave)
Small (2-10): Mid-tier (Bonsai/Xero starter)
Mid (10-50): Robust (Xero/QuickBooks)
Large (50+): Enterprise

Effect: Right complexity
```

—————————

**Annual Audit:**

```
Each year:
- Tools still appropriate?
- Outgrown current?
- New features needed?
- Cost vs value?

Action:
- Upgrade if needed
- Drop unused
- Consolidate

Effect: Right stack
```

—————————

**Migration:**

```
When upgrading:
- Plan migration carefully
- Year-end timing best
- Backup all data
- Train team
- Run parallel briefly

Effect: Smooth transition
```

---

### TOOL PRINCIPLES

**Principle 1: Match to size**

✅ Right complexity
- Over-tooled = waste

—————————

**Principle 2: Integrate**

✅ Connected stack
- Silos = manual

—————————

**Principle 3: Don't over-tool**

✅ Master few
- Many = complexity

—————————

**Principle 4: Annual review**

✅ Stay current
- Static = outdated

—————————

**Principle 5: Train team**

✅ Use fully
- Subscribe + ไม่ใช้ = waste

---

### COMMON TOOL MISTAKES

**❌ Over-tooled:**
- 10 different tools
- Switching cost
- Complexity

**❌ Under-tooled:**
- Manual everything
- Errors + slow

**❌ ไม่ integrate:**
- Manual data entry
- Time wasted

**❌ Wrong tier:**
- Solo with enterprise
- Or large with simple

**❌ ไม่ train team:**
- Tool unused
- Money wasted

## Output Format

```
## Financial Tools — [stage]

### Tool Categories
- Accounting (Wave/Xero/QuickBooks)
- Invoicing
- Expense tracking (Expensify)
- Time tracking (Toggl)
- Forecasting (Float)
- Analysis (Looker, Tableau)
- Budgeting
- Tax software
- Payroll (Xero Payroll)
- Banking (online + API)

### Compare Top Tools
- Bonsai (all-in-one, ฿700/month)
- Xero (powerful, ฿700-2.5K)
- QuickBooks (industry std, ฿700-3K)
- Wave (free, basic)
- Thai-specific (FlowAccount)

### Maverick Stack by Stage
- Y1: Wave + Excel (฿0)
- Y2: Bonsai (฿900)
- Y3: Xero + Looker (฿4K)
- Y5+: Enterprise (฿15-30K)

### Integration
- Bank → Accounting
- Accounting → Dashboards
- Native or Zapier/Make
- Single source of truth

### Principles (5)
1. Match to size
2. Integrate
3. Don't over-tool
4. Annual review
5. Train team

### Common Mistakes
❌ Over-tooled ❌ Under-tooled ❌ ไม่ integrate ❌ Wrong tier ❌ ไม่ train
```

## Constraints

- Match tools to stage
- Integrate where possible
- Master 3-5 core tools
- Annual stack review
- Train team to use

## Anti-patterns

- ❌ 10+ tool sprawl
- ❌ Manual everything
- ❌ Disconnected silos
- ❌ Wrong tier complexity
- ❌ Tools unused

## Related Skills

- **accounting-basics** — accounting
- **freelancer-tools-stack** — tools

## Memory

- `user.financial_tools` — tools
