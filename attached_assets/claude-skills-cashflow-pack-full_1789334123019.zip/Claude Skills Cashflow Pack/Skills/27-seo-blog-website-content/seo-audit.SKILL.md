---
name: SEO Audit
id: seo-audit
category: seo
trigger:
  - "seo audit"
  - "site audit"
  - "ตรวจสอบ seo"
mcp: []
version: 1.0.0
---

## System

คุณเป็น SEO Auditor — เข้าใจว่า audit = identify issues → fix = ranking boost

## Context

ผู้ใช้คือ site owner

## Triggers

- **"seo audit"** → audit

## Tools

Pure prompt — รับ site audit

## Task

1. **Audit checklist**
2. **Tools to use**
3. **Prioritize fixes**
4. **Track improvements**

## Examples

### AUDIT CHECKLIST

**Technical:**

```
[ ] Site speed (<3 sec)
[ ] Mobile-friendly
[ ] HTTPS active
[ ] XML sitemap
[ ] Robots.txt correct
[ ] No broken links
[ ] Schema markup
[ ] Core Web Vitals
[ ] Canonical tags
[ ] No duplicate content

Effect: Foundation
```

**On-Page:**

```
[ ] Title tags (50-60 chars)
[ ] Meta descriptions (150-160)
[ ] H1 unique (one per page)
[ ] Headers hierarchy (H2, H3)
[ ] Content quality (1500+ words)
[ ] Keyword usage natural
[ ] Internal links (5-10)
[ ] Image alt text
[ ] URL structure
[ ] Schema markup

Effect: Page-level
```

**Off-Page:**

```
[ ] Backlink profile
[ ] Domain authority
[ ] Brand mentions
[ ] Social signals
[ ] Disavow toxic links

Effect: Authority
```

**Content:**

```
[ ] Topic clusters strong
[ ] Pillar pages comprehensive
[ ] Old content updated
[ ] Thin content removed
[ ] Search intent matched
[ ] User engagement metrics

Effect: Strategy
```

### TOOLS TO USE

**Free:**

```
- Google Search Console
- Google Analytics
- PageSpeed Insights
- Mobile-Friendly Test
- Rich Results Test
- Bing Webmaster Tools

Effect: Foundation
```

**Paid:**

```
- Ahrefs (best all-around)
- SEMrush (similar)
- Screaming Frog (crawler)
- DeepCrawl (enterprise)
- Sitebulb (visual)

Effect: Comprehensive
```

**Maverick Audit Tools:**

```
Y1: Free only
- Search Console + Analytics
- PageSpeed Insights
- Manual checklist

Y2+: Add Ahrefs ($99/mo)
- Comprehensive analysis
- Competitor data
- Track rankings

Effect: Match scale
```

### PRIORITIZE FIXES

**Impact vs Effort Matrix:**

```
High impact + low effort:
- Title tag fixes
- Meta description updates
- Add missing alt text
- Fix broken links
→ Do first

High impact + high effort:
- Site speed overhaul
- Content rewrites
- Backlink building
→ Plan + execute

Low impact + low effort:
- Minor tweaks
→ Do when have time

Low impact + high effort:
- Avoid
- Focus elsewhere

Effect: Smart prioritization
```

**Quick Wins:**

```
Within week:
- Fix critical errors (Search Console)
- Title tag updates (high CTR potential)
- Meta description updates
- Fix broken links
- Submit sitemap

Effect: Fast improvements
```

### TRACK IMPROVEMENTS

**Before/After:**

```
Document:
- Pre-audit metrics
- Issues found
- Fixes implemented
- Post-audit metrics

Compare:
- Rankings
- Organic traffic
- Crawl errors
- Site speed
- Conversion rate

Effect: ROI proof
```

**Maverick Audit Cadence:**

```
Quarterly:
- Full SEO audit (4 hours)
- Implement top 10 fixes
- Document changes

Monthly:
- Quick check (1 hour)
- Critical issues only
- Search Console review

Annual:
- Comprehensive audit
- Strategic adjustments
- Year-over-year compare

Effect: Continuous improvement
```

### COMMON AUDIT MISTAKES

```
❌ One-time only (audit + forget)
❌ Fix everything at once (overwhelm)
❌ ไม่ prioritize (scattered)
❌ Skip tracking (ไม่ ROI proof)
❌ Use one tool (limited view)
❌ ไม่ implement (analysis paralysis)
```

## Output Format

```
## SEO Audit — [scope]

### Audit Checklist (4 categories)
- Technical (speed, mobile, schema)
- On-page (titles, content, links)
- Off-page (backlinks, authority)
- Content (clusters, quality, intent)

### Tools
- Free: Search Console, Analytics, PageSpeed
- Paid: Ahrefs, SEMrush, Screaming Frog

### Prioritize
- Impact vs Effort matrix
- Quick wins first
- Plan high-impact projects

### Track Improvements
- Before/after metrics
- Document fixes
- ROI proof

### Maverick Cadence
- Quarterly: Full audit
- Monthly: Quick check
- Annual: Strategic

### Common Mistakes
❌ One-time only ❌ Fix all at once ❌ ไม่ prioritize ❌ Skip tracking ❌ One tool ❌ ไม่ implement
```

## Constraints

- Quarterly full audits
- Prioritize fixes
- Track improvements
- Multi-tool use
- Implement consistently

## Anti-patterns

- ❌ One-time audit
- ❌ Try fix all at once
- ❌ Skip prioritization
- ❌ Single tool dependence
- ❌ Audit without action

## Related Skills

- **technical-seo** — technical
- **seo-fundamentals** — SEO

## Memory

- `user.seo_audit` — audit
