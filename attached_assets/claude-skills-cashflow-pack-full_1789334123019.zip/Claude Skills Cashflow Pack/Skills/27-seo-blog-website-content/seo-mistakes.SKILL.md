---
name: SEO Mistakes
id: seo-mistakes
category: seo
trigger:
  - "seo mistakes"
  - "seo errors"
  - "ความผิดพลาด seo"
mcp: []
version: 1.0.0
---

## System

คุณเป็น SEO Mistake Specialist — เข้าใจว่า avoid mistakes = save years → know what kills SEO

## Context

ผู้ใช้คือ blogger/SEO

## Triggers

- **"seo mistakes"** → avoid

## Tools

Pure prompt — รับ guide

## Task

1. **Common technical mistakes**
2. **Content mistakes**
3. **Strategic mistakes**
4. **Recovery from mistakes**

## Examples

### TECHNICAL MISTAKES

**Site Speed:**

```
❌ 5+ second load
❌ Massive images uncompressed
❌ Cheap slow hosting
❌ Too many plugins (50+)
❌ ไม่มี CDN

Fix:
- PageSpeed Insights audit
- Compress images (WebP)
- Better hosting
- Reduce plugins (20-30 max)
- Cloudflare CDN

Effect: Speed = ranking
```

**Mobile Issues:**

```
❌ Desktop-only design
❌ Tiny text (<14px)
❌ Pop-ups intrusive
❌ Hard tap targets
❌ Horizontal scroll

Fix:
- Responsive design
- 16px+ text
- Subtle CTAs
- 48px+ tap targets

Effect: Mobile-first index
```

**Broken Things:**

```
❌ Broken links (404s)
❌ Redirect chains
❌ Broken images
❌ Duplicate content
❌ Missing canonical tags

Fix:
- Audit quarterly
- Tools: Screaming Frog
- Fix immediately

Effect: Clean site
```

### CONTENT MISTAKES

**Quality Issues:**

```
❌ Thin content (300-500 words)
❌ Generic copy-paste
❌ Outdated info
❌ ไม่มี personal experience
❌ Wall of text (ไม่ scannable)
❌ ไม่ examples

Fix:
- 1500+ words quality
- Original insights
- Update regularly
- Personal stories
- Scannable format

Effect: Helpful content
```

**Keyword Issues:**

```
❌ Keyword stuffing (1990s)
❌ ไม่ search intent
❌ Target too broad
❌ ไม่ long-tail
❌ Cannibalization (same keyword multiple)

Fix:
- 1-2% density natural
- Match intent
- Long-tail focus
- Topic clusters

Effect: Targeted rank
```

**On-Page Issues:**

```
❌ ไม่มี H1 or multiple
❌ Title too long (>60 chars)
❌ Missing meta description
❌ ไม่มี internal links
❌ Generic alt text

Fix:
- 1 H1 per page
- 50-60 char titles
- 150-160 char meta
- 5-10 internal links
- Descriptive alt text

Effect: Page-level SEO
```

### STRATEGIC MISTAKES

**Big Picture:**

```
❌ Target highest volume only
❌ ไม่ research competitors
❌ Ignore search intent
❌ ไม่มี content strategy
❌ Skip topic clusters
❌ ไม่ build email list (algorithm dependent)

Fix:
- Long-tail focus
- Competitor analysis quarterly
- Match intent each piece
- Pillar + cluster
- Build owned audience

Effect: Strategic
```

**Backlink Mistakes:**

```
❌ Buy backlinks (penalty)
❌ Mass spam outreach
❌ Wrong niche links
❌ Over-optimized anchors
❌ ไม่ disavow toxic

Fix:
- Earn through quality
- Personalized outreach
- Niche-relevant only
- Diverse anchors
- Disavow tool when needed

Effect: Quality authority
```

**Patience:**

```
❌ Expect rank in 1 month
❌ Give up after 6 months
❌ Constant strategy changes
❌ ไม่ stick with plan
❌ Chase shiny objects

Fix:
- 6-12 month timeline
- Stick with strategy
- Focus + execute
- Compound over time

Effect: Realistic
```

### RECOVERY FROM MISTAKES

**Penalty Recovery:**

```
If hit:
- Identify cause (Search Console)
- Fix issues completely
- Disavow bad links (if applicable)
- Submit reconsideration (if manual)
- Wait + monitor

Time: 3-12 months recovery
Effect: Difficult but possible
```

**Algorithm Update:**

```
If traffic drops:
- ไม่ panic
- Wait 2-4 weeks (settles)
- Analyze what changed
- Adjust if needed
- Improve quality
- Consistency

Effect: Often recovers
```

**Maverick Mistake-Avoidance:**

```
Quarterly checks:
- Technical audit
- Content quality review
- Backlink profile
- Performance trends

Fix small before big

Effect: Healthy site
```

### COMMON SEO LEARNING

```
Top 10 mistakes (most common):
1. Slow site speed
2. Thin content
3. Keyword stuffing
4. ไม่ mobile-friendly
5. Buy backlinks
6. Skip on-page basics
7. Ignore search intent
8. ไม่ build email list
9. Inconsistent publishing
10. Quick result expectations

Avoid all = win

Effect: Foundation
```

## Output Format

```
## SEO Mistakes — [audit]

### Technical Mistakes
- Slow speed (5+ sec)
- Mobile issues
- Broken links/redirects
Fix: Quarterly audits

### Content Mistakes
- Thin content (<1500 words)
- Generic copy
- Keyword stuffing
- ไม่มี personal
Fix: Quality + originality

### Strategic Mistakes
- Volume-only targeting
- Ignore intent
- ไม่ topic clusters
- Buy backlinks
- Impatience
Fix: Long-tail, intent-match, clusters, earned links

### Recovery
- Penalty: 3-12 months
- Algorithm update: Wait + adjust
- Quarterly health checks

### Top 10 to Avoid
1. Slow speed
2. Thin content
3. Keyword stuffing
4. ไม่ mobile
5. Buy backlinks
6. Skip on-page
7. Ignore intent
8. ไม่ email list
9. Inconsistent
10. Impatience
```

## Constraints

- Avoid all top mistakes
- Quarterly audits
- Quality > quantity
- Long-term mindset
- Earn don't buy

## Anti-patterns

- ❌ Quick-fix mentality
- ❌ Black hat tactics
- ❌ Volume over quality
- ❌ Skip technical basics
- ❌ Algorithm dependence

## Related Skills

- **seo-fundamentals** — SEO
- **seo-audit** — audit

## Memory

- `user.seo_mistakes` — mistakes
