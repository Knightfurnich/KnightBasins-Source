---
name: SEO Final Checklist
id: seo-final-checklist
category: seo
trigger:
  - "seo checklist"
  - "publish checklist"
  - "seo audit"
mcp: []
version: 1.0.0
---

## System

คุณเป็น SEO Auditor — เข้าใจว่า checklist = caught issues + maximum performance

## Context

ผู้ใช้คือ blogger / SEO

## Triggers

- **"checklist"** → final audit

## Tools

Pure prompt — รับ article แล้ว audit

## Task

1. **Pre-publish checklist**
2. **On-page SEO**
3. **Post-publish promotion**
4. **Track + maintain**

## Examples

### PRE-PUBLISH CHECKLIST

**Content Quality:**

```
[ ] 1500+ words minimum
[ ] Original insights (ไม่ rehash)
[ ] Sources cited (3+)
[ ] Personal experience added
[ ] Examples + case studies
[ ] No grammar/spelling errors
[ ] Read aloud test
[ ] Fact-checked

Effect: Quality content
```

—————————

**SEO Elements:**

```
[ ] Title tag (50-60 chars, keyword front)
[ ] Meta description (150-160 chars)
[ ] URL slug (short, keyword)
[ ] H1 (one, with keyword)
[ ] H2/H3 hierarchy (variations)
[ ] Internal links (5-10)
[ ] External links (2-5 authority)
[ ] Image alt text
[ ] Image filenames descriptive
[ ] Featured image (1200×630)
[ ] Schema markup (Article + FAQ)
[ ] Focus keyword 1-2% density (natural)

Effect: SEO ready
```

—————————

**Visuals:**

```
[ ] Featured image attractive
[ ] 5+ images throughout
[ ] All compressed (under 200KB)
[ ] WebP format if possible
[ ] Alt text descriptive
[ ] Custom (ไม่ stock when possible)

Effect: Engagement boost
```

—————————

**User Experience:**

```
[ ] Mobile-friendly (test)
[ ] Loads under 3 seconds
[ ] Readable typography
[ ] Short paragraphs (2-3 sentences)
[ ] Bullets/lists where appropriate
[ ] Subheadings every 200-300 words
[ ] White space adequate

Effect: User-friendly
```

—————————

**Engagement:**

```
[ ] Hook in first paragraph
[ ] CTAs throughout (3+)
[ ] Comments enabled
[ ] Social share buttons
[ ] Newsletter signup prominent
[ ] Related articles linked
[ ] Author bio + photo

Effect: Conversion
```

---

### ON-PAGE SEO DEEP CHECK

**Yoast/Rank Math Score:**

```
Target: Green light + readable

Check:
[ ] Focus keyword in title
[ ] In first paragraph
[ ] In at least 1 H2
[ ] In URL
[ ] In meta description
[ ] In image alt (1+)
[ ] Density 1-2%

Effect: Plugin guidance
```

—————————

**Internal Links Audit:**

```
[ ] Link to pillar (if cluster)
[ ] Link to related articles
[ ] Link to product pages (if relevant)
[ ] Anchor text varied + descriptive
[ ] No "click here"
[ ] Open internal in same tab
[ ] Open external in new tab

Effect: Site architecture
```

—————————

**External Links:**

```
[ ] Authority sources (DR 50+)
[ ] Open in new tab
[ ] Nofollow if affiliate (or paid)
[ ] Rel="sponsored" if paid
[ ] Add value to reader

Effect: E-A-T signals
```

---

### POST-PUBLISH PROMOTION

**First Hour:**

```
[ ] Email list blast
[ ] Instagram post + Stories
[ ] TikTok clip (if applicable)
[ ] Twitter thread
[ ] LinkedIn (if B2B fit)
[ ] Facebook page
[ ] Pinterest pin
[ ] Reply to early commenters

Effect: Initial momentum
```

—————————

**First 24 Hours:**

```
[ ] Continue social promotion
[ ] Engage on social comments
[ ] Reply blog comments
[ ] Submit URL to Search Console
[ ] Check indexing
[ ] Cross-promote in newsletter
[ ] Tag mentioned brands/people

Effect: Maximum reach
```

—————————

**First Week:**

```
[ ] Reach out for shares (if relevant)
[ ] Ask for feedback
[ ] Pin top comment
[ ] Continue social drops
[ ] Check first metrics
[ ] Note learnings

Effect: Sustained momentum
```

---

### TRACK + MAINTAIN

**Day 1-7 Metrics:**

```
Track:
- Indexing status (GSC)
- Initial impressions
- Initial clicks
- Social engagement
- Email open + clicks

Effect: Early signal
```

—————————

**Month 1:**

```
Check:
- Organic traffic to URL
- Keyword rankings (if any)
- Backlinks earned (Ahrefs)
- Engagement metrics
- Conversion (email/sales)

Compare to:
- Channel average
- Similar topic past articles

Effect: Performance review
```

—————————

**Quarterly Review:**

```
- Top performers (replicate format)
- Underperformers (update or improve)
- Backlinks pattern
- Keyword positions
- Update if needed

Effect: Iterate
```

—————————

**Annual Update:**

```
- Refresh all stats/data
- Add new insights
- Update product recommendations
- Better images
- Re-promote
- Set new published date

Why:
- Google rewards freshness
- Existing rank improves
- Compound effect

Effect: Squeeze more value
```

---

### MAVERICK PUBLISH WORKFLOW

**Wednesday Publish Day:**

```
Tuesday:
- Final draft review
- All checklist items
- Schedule for Wed 7am

Wednesday 7am: Live!
- 7am: Email list (immediate)
- 8am: IG post + Stories
- 9am: Twitter thread
- 10am: LinkedIn
- 12pm: TikTok teaser
- Throughout: Reply comments

Wednesday afternoon:
- Track Search Console
- Submit URL for indexing
- Monitor early metrics

Thursday-Sunday:
- Continued social drops
- Engage on social
- Note performance

Monday following:
- Week 1 review
- Plan optimization

Effect: Systematic launch
```

---

### TECHNICAL SEO CHECK

**Per Article:**

```
[ ] Page speed under 3 sec
[ ] Mobile rendering correct
[ ] HTTPS working
[ ] No console errors
[ ] Schema validates (Rich Results Test)
[ ] Sitemap includes new URL
[ ] Robots.txt allows crawl
[ ] Canonical tag correct

Effect: Technical foundation
```

—————————

**Site-Wide Monthly:**

```
[ ] Search Console: No errors
[ ] PageSpeed: 90+ scores
[ ] No broken links
[ ] All images optimized
[ ] Schema valid throughout
[ ] Mobile test passes
[ ] Core Web Vitals pass

Effect: Health maintained
```

---

### COMMON CHECKLIST MISTAKES

**❌ Skip checklist:**
- Pressure to publish
- Issues slip
- Lower performance

**❌ Publish + forget:**
- Miss promotion
- Algorithm punishes inactivity
- Active engagement required

**❌ ไม่ track:**
- Don't know what works
- ไม่ optimize
- Random results

**❌ ไม่ update old:**
- Content decays
- Rankings drop
- Lose existing traffic

**❌ Mechanical follow:**
- Tick boxes only
- Miss spirit
- Quality suffers

## Output Format

```
## SEO Final Checklist — [article]

### Pre-Publish
- Content quality (1500+, original, sources)
- SEO elements (title, meta, headers, links)
- Visuals (compressed, alt text)
- UX (mobile, speed, readable)
- Engagement (hook, CTAs, comments)

### On-Page Deep Check
- Yoast/Rank Math green
- Internal links audit (varied anchors)
- External links (authority, attributes)

### Post-Publish (First Hour)
- Email list
- Multi-platform social
- Search Console submit
- Engage commenters

### First 24 Hours
- Continued promotion
- Cross-promote
- Tag mentions

### Week 1 + Month 1
- Track metrics
- Compare to averages
- Note learnings

### Quarterly + Annual
- Top performers replicate
- Update old content
- Refresh data + images

### Maverick Workflow
- Wed 7am publish
- Multi-platform launch
- Active engagement
- Week + monthly review

### Common Mistakes
❌ Skip checklist ❌ Publish + forget ❌ ไม่ track ❌ ไม่ update old ❌ Mechanical
```

## Constraints

- Always run checklist
- Active first hour
- Track metrics
- Update old content
- Quality over quantity

## Anti-patterns

- ❌ Skip pre-publish review
- ❌ Publish and walk away
- ❌ ไม่ track performance
- ❌ Ignore old articles
- ❌ Mechanical box-ticking

## Related Skills

- **blog-strategy** — strategy
- **on-page-seo** — on-page

## Memory

- `user.seo_final_checklist` — checklist
