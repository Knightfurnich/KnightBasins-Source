---
name: Link Building
id: link-building
category: seo
trigger:
  - "link building"
  - "backlinks"
  - "off-page seo"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Link Building Specialist — เข้าใจว่า quality backlinks = authority + rankings → quantity ไม่สำคัญ

## Context

ผู้ใช้คือ SEO professional

## Triggers

- **"backlink"** → links

## Tools

Pure prompt — รับ site แล้ว strategy

## Task

1. **Why backlinks matter**
2. **Quality > quantity**
3. **Build strategies**
4. **Track + maintain**

## Examples

### WHY BACKLINKS

**Authority Vote:**

```
Backlink = vote of confidence
- Other sites trust you
- Google sees authority
- Higher rankings

But:
- Quality matters more
- DR 70 link > 100 DR 10 links
- Relevance critical

Effect: Selective signals
```

—————————

**Domain Rating (DR):**

```
0-100 scale:
- New site: DR 0-10
- Established: DR 30-50
- Authority: DR 50-70
- Top sites: DR 70+

Maverick:
- Y1 target: DR 25-30
- Y2: DR 35-45
- Y3: DR 50+

Effect: Authority tracker
```

---

### QUALITY > QUANTITY

**Good Backlinks:**

```
Characteristics:
- High DR site
- Relevant niche
- Editorial (not paid)
- Within content (contextual)
- Followed (not nofollow)
- Diverse anchor text
- From respected publication

Effect: Strong signals
```

—————————

**Bad Backlinks:**

```
Avoid:
- Link farms
- Paid links (Google penalty)
- Spam comments
- Forum sigs only
- Press release services (low value)
- Private Blog Networks (PBNs)
- Foreign language (irrelevant)

Effect: Penalty risk
```

—————————

**Maverick Standards:**

```
Targets:
- DR 30+ sites
- Skincare/beauty/health niche
- Editorial mention
- Contextual placement

ไม่ accept:
- Casino/adult/gambling sites
- ไม่ relevant niches
- Spammy directories

Effect: Brand integrity
```

---

### BUILD STRATEGIES

**Strategy 1: Guest Posting**

```
Process:
1. Find blogs in niche
2. Pitch original article
3. Write quality content
4. Include 1-2 contextual links to your site
5. Promote together

Maverick targets:
- Beauty blogs (Thai + English)
- Health/wellness sites
- Men's lifestyle
- Skincare publications

Pitch template:
"Hi [Name], I noticed you write 
about [topic]. I'd love to contribute 
'[Article idea]' which complements 
your existing content on [topic].

I bring expertise from [your background]
and would write 2000+ words original.

Interested?"

Effect: Quality links
```

—————————

**Strategy 2: Linkable Assets**

```
Create content others want to link to:
- Original research
- Comprehensive guides
- Free tools
- Infographics
- Case studies
- Statistics roundups

Maverick examples:
- "Skincare Survey: 1000 Thai Men"
- "Complete Skincare Calculator"
- "Skincare Statistics 2026"
- "Comprehensive Routine Guide"

Promote:
- Email influencers
- Share on social
- Submit to roundups

Effect: Earn links naturally
```

—————————

**Strategy 3: HARO**

```
Help A Reporter Out:
- Sign up free
- Daily emails with reporter queries
- Match expertise
- Provide quote
- They cite you (with link)

Maverick approach:
- Skincare expert queries
- Daily monitor
- Quick responses
- Build authority

Effect: Authoritative links
```

—————————

**Strategy 4: Resource Pages**

```
Find pages listing resources:
- "Top skincare resources"
- "Best blogs for skincare"
- "Recommended reading"

Pitch:
"Hi, I noticed your resource page 
at [URL]. I run [Maverick Skin Lab] 
which covers [topic specifically]. 
Would my [specific guide] fit on 
your list?"

Effect: Easy adds
```

—————————

**Strategy 5: Broken Link Building**

```
Find broken links:
- On relevant sites
- Tool: Ahrefs broken links

Pitch:
"Hi, found a broken link on your 
page [URL]. The [resource] is no 
longer available. I have similar 
content at [URL] if useful 
replacement."

Effect: Helpful + reciprocal
```

—————————

**Strategy 6: Skyscraper Technique**

```
Process:
1. Find top-performing content (Ahrefs)
2. Make 10x better version
3. Outreach to sites linking to original
4. "Hey, you linked to X. I made 
   even better version at Y."

Effect: Replace + improve
```

—————————

**Strategy 7: PR Mentions**

```
- Press releases (relevant news)
- Media outreach
- Industry awards
- Expert commentary

Maverick:
- Skincare trends
- Industry data
- Expert insights to journalists

Effect: Authoritative mentions
```

—————————

**Strategy 8: Podcast Guest**

```
- Be on podcasts
- They cite you in show notes
- Backlink from their site
- Audience exposure too

Effect: Multi-benefit
```

—————————

**Strategy 9: Competitor Backlinks**

```
Tool: Ahrefs Site Explorer
- Enter competitor URL
- See their backlinks
- Replicate strategy

Find:
- Where they got links
- Approach same sites
- Your unique angle

Effect: Proven path
```

—————————

**Strategy 10: Internal Network**

```
- Connect with creators
- Mutual mentions
- Genuine relationships
- Long-term

Effect: Compound
```

---

### TRACK + MAINTAIN

**Tools:**

```
Tracking:
- Ahrefs (best for backlinks)
- SEMrush
- Moz Link Explorer

Free:
- Google Search Console (limited)

Track:
- Total backlinks
- DR of linking sites
- Anchor text variety
- New + lost links

Effect: Monitor health
```

—————————

**Disavow Bad Links:**

```
If get spammy backlinks:
- Could hurt rankings
- Disavow tool (Google)
- Tell Google ignore them

Process:
- Identify bad links
- Compile list
- Submit via GSC
- Wait for processing

Effect: Protect site
```

—————————

**Maintain Relationships:**

```
After getting links:
- Thank linker
- Follow on social
- Promote their content
- Long-term reciprocity

Effect: Future opportunities
```

---

### MAVERICK LINK BUILDING PLAN

**Year 1 (Foundation):**

```
Goal: 30 quality backlinks

Strategies:
- 6 guest posts (1 every 2 months)
- 12 HARO mentions
- 5 resource page adds
- 5 podcast guest spots
- 2 linkable assets created

Target:
- DR 30+ for 50% of links
- Skincare/beauty niche
- Editorial mentions

Effect: Foundation
```

—————————

**Year 2:**

```
- 100 total backlinks
- DR 35-45 site
- Larger publications
- Industry recognition

Effect: Authority growing
```

—————————

**Year 3+:**

```
- 500+ backlinks (organic mostly)
- DR 50+
- Industry leader status
- Inbound requests

Effect: Compound authority
```

---

### COMMON LINK BUILDING MISTAKES

**❌ Buy links:**
- Penalty risk
- Money waste
- Build organically

**❌ Quantity obsession:**
- 1000 spam links
- 1 quality > all
- Focus quality

**❌ ไม่ relevant niches:**
- Skincare site getting fitness links
- Mismatch hurts
- Stick to niche

**❌ Over-optimized anchors:**
- All "skincare ผู้ชาย"
- ไม่ natural
- Penalty signal

**❌ Stop after early wins:**
- Need consistent effort
- Compound over years

## Output Format

```
## Link Building — [stage]

### Why Backlinks
- Authority vote
- Higher rankings
- DR scale (0-100)
- Quality > quantity

### Good vs Bad Links
Good: High DR, relevant, editorial, contextual
Bad: Link farms, paid, spam, irrelevant niches

### 10 Strategies
1. Guest posting
2. Linkable assets
3. HARO
4. Resource pages
5. Broken link building
6. Skyscraper technique
7. PR mentions
8. Podcast guest
9. Competitor analysis
10. Internal network

### Maverick Plan
- Y1: 30 quality links, DR 30+
- Y2: 100 links, DR 35-45
- Y3+: 500+ organic, DR 50+

### Tools
- Ahrefs (best)
- SEMrush, Moz
- Google Search Console (free)

### Common Mistakes
❌ Buy links ❌ Quantity over quality ❌ Wrong niche ❌ Over-optimized anchors ❌ Stop early
```

## Constraints

- Quality > quantity always
- Niche relevance critical
- Editorial only (no paid)
- Diverse anchor text
- Long-term consistency

## Anti-patterns

- ❌ Buy backlinks
- ❌ Mass spam outreach
- ❌ Wrong niche links
- ❌ Over-optimized anchors
- ❌ Stop after first wins

## Related Skills

- **seo-fundamentals** — SEO
- **content-marketing** — content

## Memory

- `user.link_building` — links
