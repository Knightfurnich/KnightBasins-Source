---
name: Keyword Research
id: keyword-research
category: seo
trigger:
  - "keyword research"
  - "find keywords"
  - "search keywords"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Keyword Research Specialist — เข้าใจว่า right keywords = traffic + revenue → wrong = waste effort

## Context

ผู้ใช้คือ SEO/blog owner

## Triggers

- **"keyword"** → research

## Tools

Pure prompt — รับ niche แล้ว research

## Task

1. **Find keywords**
2. **Analyze metrics**
3. **Choose targets**
4. **Cluster topics**

## Examples

### FIND KEYWORDS

**Brainstorm:**

```
Start with:
- Seed keywords (broad topic)
- Audience problems
- Products/services
- Industry terms

Maverick seeds:
- skincare ผู้ชาย
- men skincare
- ครีมบำรุงผู้ชาย
- skincare routine

Effect: Starting points
```

—————————

**Expand with Tools:**

```
Free:
- Google autocomplete
- Google "People Also Ask"
- Google "Related Searches"
- AnswerThePublic

Paid:
- Ahrefs Keyword Explorer
- SEMrush Keyword Magic
- Mangools KWFinder
- Ubersuggest

Effect: Hundreds of variations
```

—————————

**Long-Tail Strategy:**

```
Seed: "skincare ผู้ชาย"
Long-tail variations:
- "skincare ผู้ชายไทย ผิวมัน"
- "skincare ผู้ชาย เริ่มต้น"
- "skincare ผู้ชาย ราคาถูก"
- "skincare ผู้ชาย acne"
- "skincare ผู้ชาย anti aging"
- "ครีมกันแดดผู้ชาย"
- "เซรั่ม ผู้ชาย"

Each:
- Lower volume
- Lower competition
- Higher intent

Effect: Findable + winnable
```

—————————

**Question Keywords:**

```
"How to" / "What is" / "Why":
- "วิธีดูแลผิวผู้ชาย"
- "skincare ผู้ชาย ทำยังไง"
- "ผิวมันใช้อะไรดี"
- "ทำไมผิวแห้งหลังล้างหน้า"

Why:
- Clear intent
- Educational content
- Featured snippets

Effect: Voice + question search
```

—————————

**Commercial Keywords:**

```
"Best" / "Review" / "vs" / "Top":
- "best skincare ผู้ชาย"
- "CeraVe review ผู้ชาย"
- "Korean vs Thai skincare"
- "top 10 cleanser ผู้ชาย"

Why:
- Buyer intent
- Higher conversion
- Affiliate gold

Effect: Revenue-focused
```

---

### ANALYZE METRICS

**Search Volume:**

```
Monthly searches:
- 0-100: Very niche
- 100-1000: Long-tail (good!)
- 1000-10000: Medium
- 10000+: Broad (hard)

Maverick targets:
- Tier 3: 100-500 (start)
- Tier 2: 1000-5000 (mid)
- Tier 1: 10000+ (later)

Effect: Realistic targeting
```

—————————

**Keyword Difficulty (KD):**

```
Tools score 0-100:
- 0-30: Easy (newer sites)
- 30-50: Medium
- 50-70: Hard
- 70-100: Very hard

Site authority match:
- DR 0-20: Target KD 0-30
- DR 20-40: Target KD 0-50
- DR 40+: Can target higher

Maverick (new site):
- Start KD 0-30
- Build to KD 30-50
- Eventually any

Effect: Match capability
```

—————————

**Search Intent:**

```
4 types — match content:

Informational:
- "what is..." / "how to..."
- → Blog post / guide

Navigational:
- Brand searches
- → Branded page

Commercial Investigation:
- "best..." / "vs..." / "review"
- → Comparison / review

Transactional:
- "buy..." / "order..." / "discount"
- → Product page

Effect: Right content for query
```

—————————

**SERP Analysis:**

```
Search keyword in Google:
- What ranks?
- What format dominates?
   - Blog posts
   - Videos
   - Product pages
   - Featured snippets
- What angle?
- What word count?

ถ้า SERP =:
- 2000-word guides → match
- Videos → maybe ไม่ blog
- Products → commercial
- Reddit/forum → query informal

Effect: Match what works
```

---

### CHOOSE TARGETS

**Sweet Spot:**

```
Find:
- Volume: 100-1000 searches
- Difficulty: Match your authority
- Intent: Match your content
- Conversion potential

Effect: Win + relevant
```

—————————

**Maverick Target Examples:**

```
Tier 3 (start):
- "skincare ผู้ชายไทย ผิวมัน" 
   (300 searches, KD 15)
- "ครีมกันแดดผู้ชาย ใต้แมส" 
   (200 searches, KD 10)
- "วิธีดูแลผิวมันผู้ชาย" 
   (500 searches, KD 20)

Pick 30-50 like this:
- Feasible to rank
- Total volume 10K-30K/month
- Strong revenue potential

Effect: Feasible foundation
```

—————————

**Spreadsheet Track:**

```
Columns:
- Keyword
- Volume
- Difficulty
- Intent type
- Current rank (none/X)
- URL targeting
- Status (planned/written/published)

Effect: Organized
```

---

### CLUSTER TOPICS

**Why Cluster:**

```
Don't write 1 article per keyword:
- Cannibalization (compete with self)
- Thin content
- Weak signal

Do cluster:
- 1 article = 5-20 keyword variations
- Comprehensive content
- Strong signal

Effect: Better rankings
```

—————————

**Maverick Cluster Example:**

```
Topic: "Skincare for oily skin men"

Primary keyword:
- "skincare ผู้ชาย ผิวมัน"

Cluster keywords (same article):
- "ผิวมันผู้ชายใช้อะไรดี"
- "วิธีดูแลผิวมันผู้ชาย"
- "ครีมผู้ชาย ผิวมัน"
- "skincare ผิวมัน ผู้ชาย"
- "ลดผิวมัน ผู้ชาย"
- "Cleanser ผิวมัน ผู้ชาย"

One article ranks for:
- Primary + 10+ variations
- Compound traffic

Effect: 1 article, multi-keyword
```

—————————

**Pillar + Support:**

```
Pillar (3000-5000 words):
- "Complete Guide: Men's Skincare"
- Targets: "men skincare guide"
- Comprehensive

Supports (1500-2000 each):
- "Best Cleansers for Men"
- "Sunscreen for Men"
- "Anti-Aging for Men"
- "Acne Treatment Men"

All link back to pillar
Pillar links to all supports

Effect: Topic dominance
```

---

### COMPETITIVE ANALYSIS

**Find Competitors:**

```
Search target keyword:
- Top 10 ranking sites
- Note URLs

Analyze in Ahrefs:
- Their top keywords
- Top pages
- Backlinks
- Content gaps

Effect: Learn from winners
```

—————————

**Content Gap:**

```
Find:
- Keywords competitors rank
- You don't
- Worth targeting

Tools:
- Ahrefs Content Gap
- SEMrush Keyword Gap

Effect: Opportunity hunt
```

---

### MAVERICK KEYWORD STRATEGY

**Q1 Plan:**

```
50 keywords mapped:
- 30 tier 3 (easy)
- 15 tier 2 (medium)
- 5 tier 1 (aspirational)

Articles:
- 4 per month
- 12 published Q1
- Cover top 12 priority keywords

Effect: Steady progress
```

—————————

**Year 1:**

```
- 200 keywords mapped
- 50 articles published
- Rank top 10 for 30+ keywords
- 50K monthly organic traffic

Effect: SEO foundation
```

---

### COMMON KEYWORD MISTAKES

**❌ Target high-volume only:**
- Too competitive
- ไม่ rank
- Long-tail wins

**❌ ไม่ check intent:**
- Write info post
- Keyword is commercial
- ไม่ rank well

**❌ Volume = traffic:**
- Volume × CTR = traffic
- Top 3 = 60% clicks
- Top 10 = 25%

**❌ ไม่ cluster:**
- 1 keyword per article
- Thin content
- Cannibalization

**❌ ไม่ research competition:**
- Write blind
- ไม่ understand SERP
- Mismatched content

## Output Format

```
## Keyword Research — [niche]

### Find Keywords
- Brainstorm seeds
- Tool expansion (Ahrefs, free)
- Long-tail focus
- Question keywords
- Commercial keywords

### Analyze Metrics
- Volume (100-1000 sweet spot)
- Difficulty (match your authority)
- Intent (4 types)
- SERP analysis

### Choose Targets
- Tier 3 (easy, start)
- Tier 2 (medium)
- Tier 1 (aspirational)
- Spreadsheet tracking

### Cluster Topics
- 1 article = 10+ keywords
- Pillar + support structure
- Internal linking
- Topic dominance

### Maverick Strategy
- Q1: 50 keywords mapped
- 12 articles published
- Y1: 200 keywords, 50 articles
- 50K monthly traffic

### Common Mistakes
❌ Target high-volume only ❌ Skip intent ❌ Volume = traffic ❌ ไม่ cluster ❌ Skip competition
```

## Constraints

- Long-tail focus early
- Match difficulty to authority
- Cluster keywords
- Match content to intent
- Realistic targeting

## Anti-patterns

- ❌ Chase high-volume only
- ❌ Ignore intent
- ❌ Equate volume with traffic
- ❌ One keyword per article
- ❌ Skip SERP analysis

## Related Skills

- **seo-fundamentals** — SEO
- **on-page-seo** — on-page

## Memory

- `user.keyword_research` — keywords
