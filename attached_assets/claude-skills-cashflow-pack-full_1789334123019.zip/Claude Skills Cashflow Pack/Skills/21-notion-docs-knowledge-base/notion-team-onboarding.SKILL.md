---
name: Notion Team Onboarding
id: notion-team-onboarding
category: notion
trigger:
  - "team onboarding notion"
  - "new hire notion"
  - "onboarding template"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Onboarding Specialist — เข้าใจว่า new hire onboarding = first 30 days set tone → great onboarding = quality + retention

Components: Pre-day-1, First week, First 30 days, First 90 days

## Context

ผู้ใช้คือ team manager

## Triggers

- **"new hire onboarding"** → onboarding
- **"team onboarding"** → team
- **"first day"** → first day

## Tools

Pure prompt — รับ role แล้ว design

## Task

1. **Pre-arrival prep**
2. **First day experience**
3. **First 30 days plan**
4. **90-day review**

## Examples

### MAVERICK NEW HIRE ONBOARDING TEMPLATE

**Pre-Day 1 (1-2 weeks before):**

```
□ Send welcome email
□ Share team contact info
□ Send first-day logistics:
  - Office location/Zoom link
  - Time to arrive
  - Dress code
  - Materials needed
□ Share Notion access info (will create on day 1)
□ Order equipment (laptop, etc.)
□ Setup email account
□ Calendar invite for first week sessions
□ Notify team
```

—————————

**Day 1: Welcome + Setup**

```
9:00 AM - Welcome + Office Tour
- Meet founder + immediate team
- Office tour
- Workstation setup
- Coffee + snacks

10:00 AM - Notion + Tools Setup
- Notion workspace access
- Slack access
- Email access
- Other tools

11:00 AM - Read Welcome Materials
- Mission, vision, values
- Brand guidelines
- Communication norms
- HR policies

12:00 PM - Team Lunch
- Casual conversation
- Get to know team

1:00 PM - Role-Specific Reading
- Their role's SOPs
- Department overview
- Past projects relevant

3:00 PM - First Project Brief
- Specific first project (small)
- Pair with senior
- Goals + timeline

5:00 PM - Day Wrap-Up
- Q&A
- Tomorrow's schedule
- Send home with reading

Effect:
- Welcomed feeling
- Equipment ready
- Initial work begins
```

—————————

**First Week: Shadow + Learn**

```
Day 2-3:
- Shadow senior team member
- Observe client calls (with permission)
- Read all role-relevant SOPs
- Take notes (in Notion!)

Day 4-5:
- First small client work
- Senior reviews
- Feedback loop
- Build confidence

End of week:
- 1-on-1 with manager
- Review progress
- Address concerns
- Set Week 2 goals
```

—————————

**First 30 Days:**

```
Week 1: Foundation
- Setup + reading
- Shadow + observe
- First small work

Week 2: Pair Work
- Pair with senior
- Take ownership of small tasks
- Quality reviewed

Week 3: Independent Small
- Lead small projects
- Senior reviews completed work
- Mentor available

Week 4: Independent Larger
- Take ownership of meaningful work
- Less oversight
- Quality maintained

End of 30 days:
- Performance review
- Adjustments made
- Goals for next 60 days
```

—————————

**Day 30 Review Template:**

```
# 30-Day Review - [New Hire Name]

## What's Going Well
- ___
- ___

## What's Challenging
- ___
- ___

## Skills Demonstrated
- ___
- ___

## Areas for Growth
- ___
- ___

## Cultural Fit
- Living values?
- Team integration?
- Communication style?

## Decision
□ Continue (formal hire)
□ Extend trial period
□ Part ways respectfully

## Next 60 Days Plan
- Specific projects
- Skills to develop
- Mentors assigned

## Compensation Update (if needed)
- Adjust based on performance

Effect: Clear assessment + path forward
```

—————————

**90-Day Review:**

```
At 90 days:
- More comprehensive review
- Performance vs expectations
- Growth trajectory
- Cultural integration
- Compensation review (if warranted)
- Long-term path discussion
- Goals for next quarter

Outcomes:
- Promotion path clarified
- Continued development plan
- Solid contributor + part of team
```

---

### ROLE-SPECIFIC ONBOARDING

**Marketing Specialist:**

```
Role-specific reading:
- Marketing strategy doc
- Brand voice guidelines
- Performance ad SOPs
- Content calendar
- Analytics dashboards

First projects:
- Audit existing campaigns
- Recommend optimizations
- Take over 1-2 small clients

Tools to master:
- Facebook Ads Manager
- TikTok Ads Manager
- Notion (we work in)
- Looker Studio
- Slack
```

—————————

**Designer:**

```
Role-specific reading:
- Brand guidelines
- Visual identity standards
- Past work examples
- Design system

First projects:
- Update existing assets
- Small redesigns
- Take over for senior on 1 client

Tools:
- Figma
- Adobe Creative Cloud
- Canva (sometimes)
- Notion
```

—————————

**Project Manager:**

```
Role-specific reading:
- All client onboarding SOPs
- Project management standards
- Communication norms
- Tools mastery

First projects:
- Shadow senior PM
- Coordinate small project
- Build to lead 2-3 clients

Tools:
- Notion (project DB)
- Asana (if used)
- Slack
- Calendar
```

—————————

**Junior Marketer:**

```
Role-specific reading:
- Marketing fundamentals
- All SOPs
- Examples of good work
- Writing standards

First projects:
- Reporting (build templates)
- Content calendar setup
- Support senior team

Tools:
- All tools
- Notion (specifically)
- Reporting tools
```

---

### ONBOARDING TEMPLATE IN NOTION

**Page Structure:**

```
🎉 Welcome [Name] - First Day

📅 Today's Schedule
[Pre-built day 1 schedule]

📋 Welcome Checklist
□ Office tour
□ Tools setup
□ Read welcome docs
□ Lunch with team
□ First project brief
□ Q&A session

📚 Required Reading (Day 1)
- Mission + Values
- Communication Norms
- [Your role] Overview

📅 First Week Schedule
[Pre-built week 1 schedule]

🎯 First 30 Days Goals
- Week 1: ___
- Week 2: ___
- Week 3: ___
- Week 4: ___

👥 Your Team
- Manager: ___ (DM directly)
- Mentor: ___ (Q&A go-to)
- Buddy: ___ (informal questions)

📞 Quick Help
- Tech issues: [contact]
- HR questions: [contact]
- Project questions: [manager]

🤝 Cultural Notes
- Communication: Slack, async-first
- Meetings: Camera on, prepared
- Feedback: Direct + kind
- Wins: Celebrate openly

Effect:
- Self-serve onboarding
- Less manager interruption
- Consistent experience
```

---

### ONBOARDING PRINCIPLES

**Principle 1: Plan ahead**

✅ Pre-day 1 prep
- Last-minute = chaos

—————————

**Principle 2: Cultural fit**

✅ Live values from day 1
- Skills + culture both

—————————

**Principle 3: Gradual ownership**

✅ Pair → Independent → Full
- All-at-once = overwhelm

—————————

**Principle 4: Frequent feedback**

✅ Weekly 1-on-1s
- Catch issues early

—————————

**Principle 5: Document everything**

✅ Reusable for next hire
- Each hire builds template

---

### COMMON ONBOARDING MISTAKES

**❌ ไม่ prep:**
- Day 1 chaos
- New hire feels unwelcome

**❌ Information overload:**
- 200 pages day 1
- Overwhelm

**❌ ไม่มี check-ins:**
- Issues unspoken
- Surprise at 30 days

**❌ ไม่ document:**
- Each new hire from scratch
- Inconsistent

**❌ Skip cultural fit:**
- Skills hire only
- Personality clashes

## Output Format

```
## Notion Team Onboarding — [role]

### Onboarding Phases (4)
1. Pre-Day 1: Welcome + setup
2. Day 1: Welcome + tools + first project
3. First Week: Shadow + small work
4. First 30 Days: Independent work
5. 30-Day Review (formal)

### Day 1 Schedule
- 9 AM: Welcome + tour
- 10 AM: Tools setup
- 11 AM: Welcome materials
- 12 PM: Team lunch
- 1 PM: Role-specific reading
- 3 PM: First project brief
- 5 PM: Day wrap-up

### Role-Specific Templates
- Marketing Specialist
- Designer
- Project Manager
- Junior Marketer

### 30-Day Review Template
- What's going well / Challenging
- Skills demonstrated / Growth areas
- Cultural fit
- Decision (continue/extend/part)
- Next 60 days plan

### Notion Onboarding Page Structure
- Schedule / Checklist / Reading
- Goals / Team / Quick help
- Cultural notes

### Principles (5)
1. Plan ahead
2. Cultural fit (skills + values)
3. Gradual ownership
4. Frequent feedback
5. Document everything

### Common Mistakes
❌ ไม่ prep ❌ Information overload ❌ ไม่มี check-ins ❌ ไม่ document ❌ Skip cultural fit
```

## Constraints

- Pre-day 1 prep complete
- 30-day formal review
- Documented onboarding plan
- Weekly check-ins
- Cultural fit assessed

## Anti-patterns

- ❌ Day-1 chaos (no prep)
- ❌ Information overload
- ❌ Solo onboarding
- ❌ Skip 30-day review
- ❌ Skill-only hiring

## Related Skills

- **notion-business-wiki** — wiki
- **agency-team-building** — team

## Memory

- `user.onboarding_template` — template
