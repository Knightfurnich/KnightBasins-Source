---
name: Notion Team Collaboration
id: notion-team-collaboration
category: notion
trigger:
  - "notion team"
  - "team collaboration notion"
  - "notion sharing"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Team Collaboration Specialist — เข้าใจว่า Notion teams = central hub → multi-user access + permissions = scale

Components: Permissions, Comments, Mentions, Real-time editing

## Context

ผู้ใช้คือ team using Notion

## Triggers

- **"team notion"** → team
- **"sharing notion"** → sharing
- **"notion permissions"** → permissions

## Tools

Pure prompt — รับ team setup แล้ว design

## Task

1. **Workspace structure**
2. **Permissions**
3. **Collaboration practices**
4. **Adoption**

## Examples

### MAVERICK TEAM NOTION SETUP

**Workspace Structure:**

```
Maverick HQ:
├─ 🏢 Company (everyone view)
├─ 📚 Operations Manual (everyone edit)
├─ 👥 Team Hub (relevant access)
├─ 🤝 Clients (account managers + above)
├─ 💼 Sales + Marketing (sales team)
├─ 💰 Finance (finance team only)
└─ 🔐 Confidential (founder only)

Permission levels:
- Viewer: Read only
- Commenter: Read + comment
- Editor: Read + write + comment
- Full Access: All + invite + admin
```

—————————

**Permission Matrix:**

```
Page                     | Founder | Senior | Mid | Junior |
Operations Manual        |   FA    |   E    |  E  |   E    |
Team Hub                 |   FA    |   E    |  C  |   V    |
Clients (general)        |   FA    |   E    |  E  |   V    |
Confidential             |   FA    |   -    |  -  |   -    |
Finance                  |   FA    |   V    |  -  |   -    |
Marketing                |   FA    |   E    |  E  |   E    |

FA = Full Access
E = Editor
C = Commenter
V = Viewer
- = No access
```

—————————

**Real-Time Collaboration:**

```
Features:
- Multiple users edit same page
- See cursors of others
- Auto-save
- Version history (premium)

Best for:
- Shared docs (meeting notes)
- Project plans
- Brainstorming sessions
- Templates

Effect:
- ไม่มี version conflicts
- Collaboration smooth
```

—————————

**Comments + Mentions:**

```
Comments:
- Click highlight on text
- Comment specific
- @ mention user

Mentions:
- Notify specific person
- Tag in tasks
- Assign work

Effect:
- Targeted communication
- ไม่ chase via Slack
- Context preserved
```

—————————

**Maverick Team Practices:**

```
Daily:
- Async standup (in shared note)
- Tag each other in tasks
- Comment on changes

Weekly:
- Shared meeting notes (live edit)
- Update OKR tracker
- Review project boards

Monthly:
- Team retro (shared template)
- Goal check-ins
- Feedback rounds

Effect: Async-first culture
```

---

### COLLABORATION TIPS

**Tip 1: Standardize Status Updates**

```
Instead of Slack messages:
- Write in shared "Standup" page
- Each person section
- Update daily

Effect:
- Less interruption
- Reference later
- ไม่ lose info
```

—————————

**Tip 2: Project Boards**

```
Asana-style in Notion:
- Database with status
- Board view
- Each task = card
- Assigned owner
- Due date

Effect:
- Visual project management
- Replaces external tools
```

—————————

**Tip 3: Meeting Notes Live**

```
During meeting:
- Open shared notes page
- Multiple typing simultaneously
- Action items captured live
- Mentions for owners

Effect:
- Captured in moment
- Distributed automatically
- Trackable
```

---

### PERMISSIONS PRINCIPLES

**Principle 1: Need-to-know**

✅ Default deny
✅ Add as needed
- Default open = security risk

—————————

**Principle 2: Senior > Junior**

✅ Senior more access
- Trust + responsibility match

—————————

**Principle 3: Comments > Edits**

✅ Most viewers comment, ไม่ edit
- Reduce accidents

—————————

**Principle 4: Audit annually**

✅ Review who has access
- Stale permissions = risk

—————————

**Principle 5: Version history**

✅ Track changes
- Recover if broken

---

### COMMON COLLABORATION MISTAKES

**❌ Everyone admin:**
- Accidents
- Confusion

**❌ Founder-only edits:**
- Bottleneck
- ไม่ scale

**❌ ไม่ standardize:**
- Each person different format
- Chaos

**❌ Skip mentions:**
- Tag people
- Or work goes unseen

**❌ ไม่ archive:**
- Old pages clutter
- Confuse current state

## Output Format

```
## Notion Team Collaboration — [team]

### Workspace Structure
- Company / Operations / Team / Clients / Sales / Finance / Confidential

### Permission Levels (4)
1. Viewer (read only)
2. Commenter (read + comment)
3. Editor (read + write)
4. Full Access (admin)

### Real-Time Collaboration
- Multi-user edit
- See cursors
- Auto-save
- Version history

### Comments + Mentions
- @ mention specific people
- Tag in tasks
- Context preserved

### Collaboration Tips (3)
1. Standardize standup
2. Project boards (Asana-style)
3. Live meeting notes

### Principles (5)
1. Need-to-know
2. Senior > Junior access
3. Comments > Edits
4. Audit annually
5. Version history

### Common Mistakes
❌ Everyone admin ❌ Founder-only edits ❌ ไม่ standardize ❌ Skip mentions ❌ ไม่ archive
```

## Constraints

- Permission matrix defined
- Default deny then add
- Standardize formats
- Use mentions actively
- Audit annually

## Anti-patterns

- ❌ Everyone admin
- ❌ Founder-only edits
- ❌ Inconsistent formats
- ❌ Skip mentions
- ❌ Permissions stale

## Related Skills

- **notion-databases** — databases
- **notion-knowledge-base** — KB

## Memory

- `user.team_setup` — setup
