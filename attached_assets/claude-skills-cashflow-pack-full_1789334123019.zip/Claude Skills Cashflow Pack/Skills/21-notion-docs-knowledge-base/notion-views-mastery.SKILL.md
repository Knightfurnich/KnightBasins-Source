---
name: Notion Views Mastery
id: notion-views-mastery
category: notion
trigger:
  - "notion views"
  - "views database"
  - "filter notion"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Views Specialist — เข้าใจว่า views = power feature → same data, multiple useful angles

Types: Table, Board, Calendar, Timeline, Gallery, List

## Context

ผู้ใช้คือ Notion user

## Triggers

- **"views"** → views
- **"database views"** → DB views
- **"filter sort"** → filter

## Tools

Pure prompt — รับ DB แล้ว design views

## Task

1. **View types**
2. **Best uses**
3. **Filter + sort**
4. **Multi-view setup**

## Examples

### MAVERICK CLIENTS DATABASE - 8 USEFUL VIEWS

**View 1: All Active (Table)**

```
Type: Table
Filter: Status = Active
Sort: Last Contact (newest first)
Properties shown: Name, Tier, Monthly Revenue, Account Manager, Last Contact

Use: Quick overview of active accounts
```

—————————

**View 2: Pipeline Board**

```
Type: Board
Group by: Status
- New
- Discovery
- Proposal
- Negotiation
- Won
- Lost

Properties shown: Name, Estimated Value, Days in Stage

Use: Visual sales pipeline
```

—————————

**View 3: Calendar**

```
Type: Calendar
Date property: Started Date

Use: See client anniversary
- Send anniversary cards
- Time-based context
```

—————————

**View 4: This Quarter**

```
Type: Table
Filter: Started Date is within this quarter
Sort: Started Date

Use: New clients this quarter
- Track acquisition
- Growth analysis
```

—————————

**View 5: At-Risk**

```
Type: Table
Filter: Health Score <= 5
Sort: Health Score (lowest first)

Properties shown: Name, Account Manager, Last Contact, Health Score, Notes

Use: Identify churn risks
- Action plan per
- Save before lose
```

—————————

**View 6: By Account Manager**

```
Type: Table
Group by: Account Manager
Sort: Tier

Properties shown: Name, Tier, Monthly Revenue

Use: AM workload + portfolio
- Balance workload
- Performance tracking
```

—————————

**View 7: Tier 1 Premium**

```
Type: Gallery (visual)
Filter: Tier = "Tier 1"
Sort: Lifetime Value

Properties shown: Name, Photo (if any), Monthly Revenue

Use: Visualize top customers
- Premium client showcase
```

—————————

**View 8: Renewals Coming**

```
Type: Table
Filter: Next Renewal is within next 60 days
Sort: Next Renewal

Properties shown: Name, Next Renewal, Account Manager, Monthly Revenue

Use: Proactive renewal management
- Schedule renewal calls
- Prepare proposals
```

---

### VIEW TYPES DEEP DIVE

**Table View:**

```
Best for:
- Comprehensive data review
- Sorting/comparing
- Spreadsheet-like analysis

Customize:
- Show/hide columns
- Sort columns
- Wrap text
- Bold rows

Effect: Detailed information dense
```

—————————

**Board View (Kanban):**

```
Best for:
- Status-based workflows
- Visual progress
- Drag-and-drop moves

Customize:
- Group by Status (most common)
- Show/hide groups
- Card format

Effect: Visual workflow
```

—————————

**Calendar View:**

```
Best for:
- Date-based items
- Visual time
- Schedule planning

Customize:
- Pick date property
- Filter date range
- Multiple events per day

Effect: Time visualization
```

—————————

**Timeline View (Gantt):**

```
Best for:
- Project planning
- Timeline visualization
- Duration tracking

Customize:
- Start + end dates
- Group by category
- Adjust durations

Effect: Project management
```

—————————

**Gallery View:**

```
Best for:
- Visual content (photos, designs)
- Page covers prominent
- Browse-friendly

Customize:
- Card size
- Show page cover
- Specific properties

Effect: Visual browsing
```

—————————

**List View:**

```
Best for:
- Simple lists
- Notes/journal
- Reading list

Effect: Minimal, focused
```

---

### FILTER + SORT TECHNIQUES

**Compound Filters:**

```
Multiple criteria:
- Status = Active
AND Tier = "Tier 1"
AND Last Contact > 14 days ago

Effect: Specific subset
```

—————————

**Date Filters:**

```
- Today
- Yesterday
- This week
- Last week
- Next 7 days
- Next 30 days
- This month
- Past 90 days
- Custom range

Effect: Time-based slicing
```

—————————

**Person Filters:**

```
- "Me" (current user)
- Specific person
- Multiple people

Effect: Personal view
```

—————————

**Status Filters:**

```
- "is" (specific value)
- "is not" (exclude)
- "is empty" (incomplete)
- "is not empty" (filled)

Effect: Status-specific
```

—————————

**Multi-Sort:**

```
Sort by:
1. Priority (High first)
2. Due Date (earliest first)
3. Name (alphabetical)

Effect: Layered organization
```

---

### VIEW PRINCIPLES

**Principle 1: View per use case**

✅ Different views for different needs
- Single view = limited

—————————

**Principle 2: Filter to focus**

✅ Show what's relevant
- All data = overwhelming

—————————

**Principle 3: Default to simplicity**

✅ Show essentials first
- 20 columns = unusable

—————————

**Principle 4: Save useful views**

✅ Build once, reuse
- Recreate every time = waste

—————————

**Principle 5: Iterate views**

✅ Refine based on use
- Perfect first time impossible

---

### COMMON VIEW MISTAKES

**❌ Single view only:**
- Limited usage
- Miss optimal angles

**❌ Too many views:**
- 20 views = decision paralysis
- 5-8 typical

**❌ Show all columns:**
- Information overload
- Slow rendering

**❌ ไม่ filter:**
- All data always
- ไม่ focus

**❌ Inconsistent across DBs:**
- Each DB different style
- Mental load

## Output Format

```
## Notion Views Mastery — [database]

### View Types (6)
1. Table (comprehensive data)
2. Board (Kanban, status workflow)
3. Calendar (date-based)
4. Timeline (Gantt, projects)
5. Gallery (visual)
6. List (simple)

### Maverick Clients DB - 8 Views Example
1. All Active (table)
2. Pipeline Board
3. Calendar (anniversaries)
4. This Quarter
5. At-Risk
6. By Account Manager
7. Tier 1 Premium (gallery)
8. Renewals Coming

### Filter Techniques
- Compound (AND/OR)
- Date (today, this week, custom)
- Person ("me", specific)
- Status (is, is not, empty)

### Multi-Sort
- Layer multiple sort criteria
- Priority → Due → Name

### Principles (5)
1. View per use case
2. Filter to focus
3. Default to simplicity
4. Save useful views
5. Iterate views

### Common Mistakes
❌ Single view ❌ Too many (20+) ❌ Show all columns ❌ ไม่ filter ❌ Inconsistent
```

## Constraints

- 5-8 views per database
- Filter for focus
- Show essentials
- Save useful views
- Iterate based on use

## Anti-patterns

- ❌ Single table view
- ❌ 20+ views
- ❌ Show every column
- ❌ ไม่ filter
- ❌ Different style per DB

## Related Skills

- **notion-databases** — databases
- **notion-best-practices** — practices

## Memory

- `user.views_setup` — views
