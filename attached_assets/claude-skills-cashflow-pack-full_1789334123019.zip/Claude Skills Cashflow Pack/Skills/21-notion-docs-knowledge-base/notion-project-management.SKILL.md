---
name: Notion Project Management
id: notion-project-management
category: notion
trigger:
  - "notion project"
  - "project management"
  - "notion task"
mcp: []
version: 1.0.0
---

## System

คุณเป็น PM Specialist — เข้าใจว่า Notion PM = combine projects + tasks + knowledge → all in one

Components: Projects DB, Tasks DB, Timelines, Status

## Context

ผู้ใช้คือ project manager

## Triggers

- **"project management"** → PM
- **"projects"** → projects
- **"tasks"** → tasks

## Tools

Pure prompt — รับ project type แล้ว design

## Task

1. **Project structure**
2. **Task management**
3. **Status + timeline**
4. **Team coordination**

## Examples

### MAVERICK PROJECT MANAGEMENT

**Database 1: "Projects"**

```
Properties:
- Project Name (Title)
- Client (Relation to Clients DB)
- Type (Select: Strategy, Marketing, Brand, etc.)
- Status (Select: Planning, In Progress, Review, Complete, On Hold)
- Priority (Select: Low, Medium, High, Critical)
- Start Date / End Date
- Budget (Number)
- Hours Allocated (Number)
- Hours Used (Rollup from Tasks)
- % Complete (Formula)
- Owner (Person)
- Tasks (Relation to Tasks)
- Notes (Rich text)

Views:
- Timeline (Gantt-like)
- Board (by Status)
- Calendar (by End Date)
- Active Projects (filter)
- Completed (archive)
- By Owner
- Overdue (End Date passed, not Complete)
```

—————————

**Database 2: "Tasks"**

```
Properties:
- Task (Title)
- Project (Relation)
- Assignee (Person)
- Status (Select: To Do, In Progress, Done, Blocked)
- Priority (Select)
- Due Date
- Hours Estimated
- Hours Actual
- Tags (Multi-select)
- Notes

Views:
- My Tasks (filter by Assignee = me)
- Today (filter Due Date)
- This Week
- Blocked
- Done This Week
- By Project
- By Priority
```

—————————

**Project Page Structure:**

```
🎯 Project: Maverick Skin Brand Launch

📋 Project Info
- Client: Maverick Skin
- Type: Brand Launch
- Status: In Progress
- Owner: ครูเอ็ม
- Timeline: Jan 1 - Mar 31

🎯 Goals
- Build brand identity
- Launch Maverick line
- Acquire first 1,000 customers

📅 Timeline (with phases)
- Phase 1: Brand Foundation (Jan)
- Phase 2: Product Development (Feb)
- Phase 3: Launch (Mar)

📊 Progress
- 40% complete
- 65 of 100 hours used
- On track ✅

💼 Tasks (linked database)
- [Embedded task list filtered by this project]

📝 Notes + Decisions
- Key decisions documented
- Lessons learned

📁 Files
- Brand brief
- Photos
- Contracts
```

—————————

**Daily Workflow:**

```
Morning:
1. Check "My Tasks" view
2. Look at today's tasks
3. Priority order
4. Block calendar time

During:
- Update task status as work
- Log hours
- Note blockers

End of day:
- Review what completed
- Update statuses
- Plan tomorrow's top 3
```

—————————

**Weekly Project Review:**

```
Each project page:
- Update % complete
- Note blockers
- Adjust timeline if needed
- Plan next week's focus

Team review:
- All active projects
- Resource allocation
- Risk identification
- Strategic decisions

Effect:
- Stay aligned
- Catch issues early
- Predictable progress
```

---

### PROJECT TEMPLATES

**Template: Marketing Campaign**

```
Standard sections:
1. Campaign Brief
2. Target Audience
3. Channels
4. Budget
5. Timeline
6. Tasks (pre-populated)
7. Performance Tracking
8. Post-Mortem

Effect:
- Faster project setup
- Consistent format
- Knowledge captured
```

—————————

**Template: Client Onboarding Project**

```
Standard tasks (pre-populated):
- Discovery call
- Strategy doc
- Tools setup
- First deliverable
- Initial check-in
- 30-day review

Effect:
- ไม่ลืม steps
- Smooth onboarding
- Trackable
```

---

### TIMELINE + GANTT VIEWS

**Notion Timeline:**

```
Built-in timeline view:
- Visualize start/end dates
- Drag to adjust
- Group by Status or Owner
- Filter by criteria

Best for:
- 5-20 projects active
- 1-6 month timelines
- Visual planning

Limitations:
- Less powerful than dedicated PM tools (Asana, Monday)
- Sufficient for most teams
```

—————————

**Maverick Timeline (Quarterly):**

```
Q1 2026:
- Project A (Brand): Jan 1 - Feb 15
- Project B (Launch): Feb 1 - Mar 31
- Project C (Ads): Mar 1 - Apr 15
- Project D (Course): Apr 1 - Jun 30

Visual:
[Bar chart timeline]
- Identify overlaps
- Resource conflicts
- Adjust if needed
```

---

### PROJECT MANAGEMENT PRINCIPLES

**Principle 1: Plan before execute**

✅ Define scope, tasks
- Wing it = chaos

—————————

**Principle 2: Single owner per project**

✅ One person accountable
- Multiple = diffused

—————————

**Principle 3: Update statuses**

✅ Daily during active phase
- Stale = ไม่ trust

—————————

**Principle 4: Catch blockers early**

✅ Daily standup
- Hidden blockers compound

—————————

**Principle 5: Document decisions**

✅ Why chose X
- Future team: ไม่ understand

---

### COMMON PM MISTAKES

**❌ ไม่มี clear scope:**
- Project drift
- Endless work

**❌ Too many active:**
- Spread thin
- Quality drops

**❌ ไม่ track time:**
- ไม่ know profitability
- Can't optimize

**❌ Status updates skipped:**
- Misalignment
- Surprises

**❌ ไม่ post-mortem:**
- Same mistakes repeat
- ไม่ learning

## Output Format

```
## Notion Project Management — [scale]

### Database Setup (2)
1. Projects (high-level)
2. Tasks (detailed actions)

### Project Page Structure
- Project Info / Goals / Timeline
- Progress / Tasks (embedded)
- Notes / Files

### Views Available
- Projects: Timeline, Board, Calendar
- Tasks: My Tasks, Today, By Project

### Daily Workflow
- Morning: Check tasks, prioritize
- During: Update statuses, log hours
- End: Review, plan tomorrow

### Templates
- Marketing Campaign
- Client Onboarding
- Product Launch

### Principles (5)
1. Plan before execute
2. Single owner
3. Update statuses
4. Catch blockers early
5. Document decisions

### Common Mistakes
❌ ไม่มี scope ❌ Too many active ❌ ไม่ track time ❌ Skip updates ❌ ไม่ post-mortem
```

## Constraints

- Plan before execute
- Single owner per project
- Daily status updates
- Weekly reviews
- Document decisions

## Anti-patterns

- ❌ Vague project scope
- ❌ Too many simultaneous
- ❌ Skip time tracking
- ❌ Stale statuses
- ❌ Skip post-mortems

## Related Skills

- **notion-databases** — databases
- **notion-team-collaboration** — team

## Memory

- `user.project_setup` — setup
