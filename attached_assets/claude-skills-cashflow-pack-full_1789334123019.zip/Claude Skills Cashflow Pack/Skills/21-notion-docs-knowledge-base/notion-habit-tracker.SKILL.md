---
name: Notion Habit Tracker
id: notion-habit-tracker
category: notion
trigger:
  - "habit tracker"
  - "track habits"
  - "habit notion"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Habit Tracking Specialist — เข้าใจว่า tracked habits = formed habits → invisible if not tracked

Components: Habits database, Daily check-in, Streaks, Reflection

## Context

ผู้ใช้คือ habit-builder

## Triggers

- **"habit tracker"** → tracker
- **"build habits"** → build

## Tools

Pure prompt — รับ habits แล้ว design

## Task

1. **Habits database**
2. **Daily tracking**
3. **Streak motivation**
4. **Reflection**

## Examples

### MAVERICK HABIT SETUP

**Database: "Habits"**

```
Properties:
- Habit (Title)
- Category (Health, Work, Mind, Relationships)
- Frequency (Daily, Weekly, Monthly)
- Target (e.g., "30 min/day")
- Started Date
- Streak (Number)
- Best Streak (Number)
- Total Completions (Rollup)
- Why (Why this matters - text)
- Impact (How it benefits - text)
- Status (Active, Paused, Completed)

Views:
- Daily Habits (filter: Active + Daily)
- Weekly Habits
- Active Streaks (sort by streak desc)
- Best Streaks ever
- Categories
```

—————————

**Daily Check-In Database:**

```
Properties:
- Date (Title)
- [Each habit as checkbox]
  - Exercise ✅/❌
  - Meditate ✅/❌
  - Read ✅/❌
  - No Junk Food ✅/❌
  - Sleep 8 hrs ✅/❌
  - Family time ✅/❌
- Mood (1-10)
- Energy (1-10)
- Notes (rich text)
- Top 3 wins today
- Tomorrow priorities

Views:
- Today (current date)
- This Week
- This Month
- Streaks visualization
```

—————————

**Maverick Daily Habits:**

```
Morning (6-8 AM):
✅ Wake by 6 AM
✅ Stretch 10 min
✅ Meditation 10 min
✅ Healthy breakfast
✅ Read 30 min
✅ Plan top 3

Daytime:
✅ Exercise 30 min
✅ Drink 3L water
✅ No junk food
✅ Family time 1 hr

Evening (8-10 PM):
✅ Reflect (5 min)
✅ Gratitude (3 things)
✅ No screens 30 min before bed
✅ Sleep by 10 PM
```

—————————

**Streak Motivation:**

```
Visual streak counter:
"Exercise: 15-day streak 🔥"

Effect:
- ไม่ break the chain
- Visual progress
- Compound motivation

Best streak ever:
"Best: 45-day streak"
- Compete with self
- Push to beat
```

—————————

**Reflection Page:**

```
# Habits Reflection - [Month]

## Streaks Achieved
- Exercise: 25 days
- Reading: 30 days
- Meditation: 20 days

## Streaks Broken
- No junk food: Day 18 broke
- Why? Stressful week, comfort food
- Adjustment: Plan for stress days

## Total Completions
- 87% completion rate this month
- vs 75% last month ✅

## What Helped
- Morning routine consistent
- Evening wrap-up
- Wife reminding me

## What Didn't
- Long meetings disrupted
- Stressful project = skip exercise

## Next Month
- Add: Yoga 2x/week
- Adjust: Earlier sleep time
- Continue: Morning routine

Effect: Iterative improvement
```

---

### HABIT FORMATION SCIENCE

**Habit Loop:**

```
1. Cue (trigger)
2. Routine (action)
3. Reward (benefit)

Example: Morning meditation
- Cue: After coffee
- Routine: 10 min meditation
- Reward: Calm + clarity

Notion captures:
- Cue: When did you do?
- Routine: What did you do?
- Reward: How felt?

Effect: Identify what works
```

—————————

**21-Day Rule:**

```
Common belief: 21 days to form habit
Reality: 18-66 days (research shows)

Factors:
- Habit complexity
- Personality
- Consistency

Track in Notion:
- Days 1-7: Hardest
- Days 8-21: Building
- Days 22+: Becoming automatic
- Days 60+: Lifelong

Visual:
- Color-code days
- Celebrate milestones
```

—————————

**Habit Stacking:**

```
Stack new habit on existing:

Existing: Drink coffee (already automatic)
New: Read 5 pages WHILE drinking coffee

Effect:
- Bridge new to old
- Reduce mental load
- Higher success rate

Track in Notion:
- Note "stacking" in habit
- See connection
```

---

### HABIT PRINCIPLES

**Principle 1: Track daily**

✅ Visual + accountability
- Out of sight = forgotten

—————————

**Principle 2: Start small**

✅ 1-2 habits at time
- 10 = abandon all

—————————

**Principle 3: Celebrate streaks**

✅ Visual + emotional
- Motivation lasts

—————————

**Principle 4: Forgive breaks**

✅ ไม่ shame
✅ Restart
- Perfectionism = quit

—————————

**Principle 5: Reflect monthly**

✅ Adjust based on data
- Same approach failing = change

---

### COMMON HABIT MISTAKES

**❌ Track too many:**
- 15 habits at once
- Overwhelm
- Quit all

**❌ Inconsistent tracking:**
- Skip days
- ไม่มี data
- Lose momentum

**❌ Perfectionism:**
- Miss 1 day = quit
- All-or-nothing thinking

**❌ ไม่ celebrate:**
- 30-day streak ignored
- ไม่มี reward

**❌ ไม่ reflect:**
- Track but ไม่ analyze
- ไม่ improve

## Output Format

```
## Notion Habit Tracker — [stage]

### Habits Database
- Habit, Category, Frequency, Target
- Streak, Best Streak, Total Completions
- Why, Impact, Status

### Daily Check-In Database
- Date, [each habit checkbox]
- Mood, Energy, Notes
- Wins, Tomorrow priorities

### Maverick Daily Habits Example
- Morning: Wake, stretch, meditate, breakfast, read
- Daytime: Exercise, water, no junk, family time
- Evening: Reflect, gratitude, no screens, sleep

### Habit Science
- Habit Loop: Cue → Routine → Reward
- 18-66 days to form (varies)
- Stack new on existing

### Reflection (Monthly)
- Streaks achieved/broken
- What helped/didn't
- Adjustments

### Principles (5)
1. Track daily
2. Start small (1-2 habits)
3. Celebrate streaks
4. Forgive breaks
5. Reflect monthly

### Common Mistakes
❌ Track too many ❌ Inconsistent ❌ Perfectionism ❌ ไม่ celebrate ❌ ไม่ reflect
```

## Constraints

- Track daily for visibility
- 1-2 new habits at time
- Celebrate progress
- Forgive lapses
- Monthly reflection

## Anti-patterns

- ❌ 10+ habits simultaneously
- ❌ Sporadic tracking
- ❌ All-or-nothing thinking
- ❌ Skip celebrations
- ❌ Track but ignore data

## Related Skills

- **notion-personal-system** — personal
- **notion-goal-tracking** — goals

## Memory

- `user.habits` — habits
