---
name: Notion Formulas
id: notion-formulas
category: notion
trigger:
  - "notion formula"
  - "notion calculations"
  - "auto calculate notion"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Formula Specialist — เข้าใจว่า Notion formulas = power up databases → auto-calculations save manual work

Functions: Math, Date, Logic, Text, Aggregation

## Context

ผู้ใช้คือ Notion advanced user

## Triggers

- **"formula"** → formula
- **"calculate"** → calculate
- **"automate"** → automate

## Tools

Pure prompt — รับ calculation need แล้ว build

## Task

1. **Common formulas**
2. **Date functions**
3. **Logic + conditionals**
4. **Aggregations**

## Examples

### MAVERICK USEFUL FORMULAS

**Formula 1: Days Until Due**

```
Use case: Track tasks with deadlines

Formula:
dateBetween(prop("Due Date"), now(), "days")

Result:
- Positive = future
- 0 = today
- Negative = overdue

Display: "3 days" or "OVERDUE 5"

Visual: Color code based on:
- Past 0 = Red
- 0-3 days = Yellow
- 4+ days = Green
```

—————————

**Formula 2: Project Status Auto**

```
Use case: Auto-set status based on dates

Formula:
if(prop("Status") == "Complete", "✅ Done",
if(prop("End Date") < now(), "⚠️ Overdue",
if(prop("Start Date") > now(), "📅 Future",
"🔄 In Progress")))

Result: Auto-categorized status
```

—————————

**Formula 3: Profit Calculation**

```
Use case: Project profitability

Formula:
prop("Revenue") - prop("Cost")

Or:
(prop("Revenue") - prop("Cost")) / prop("Revenue") × 100
(returns profit margin %)

Display: "฿45,000 profit (38%)"
```

—————————

**Formula 4: Lifetime Value (LTV)**

```
Use case: Customer LTV calculation

Formula:
prop("Monthly Revenue") × prop("Months Active")

Or with retention:
prop("Monthly Revenue") × (1 / prop("Churn Rate"))

Result: ฿150K LTV per customer
```

—————————

**Formula 5: Project Health Score**

```
Use case: Overall project health

Formula:
if(prop("% Complete") > 75% and prop("On Time"), "✅ Healthy",
if(prop("% Complete") > 50% and prop("Days Until Due") > 0, "⚠️ At Risk",
"🔴 Critical"))

Result: Quick health indicator
```

—————————

**Formula 6: Tier Classification**

```
Use case: Auto-classify clients by revenue

Formula:
if(prop("Monthly Revenue") >= 100000, "Tier 1",
if(prop("Monthly Revenue") >= 50000, "Tier 2",
"Tier 3"))

Result: Auto-tiered without manual update
```

—————————

**Formula 7: Days Active**

```
Use case: How long client has been with you

Formula:
dateBetween(now(), prop("Started Date"), "days")

Result: "365 days" (1 year)
```

—————————

**Formula 8: Hours Per Week Average**

```
Use case: Workload tracking

Formula:
prop("Hours This Month") / 4

Result: Average hours per week
```

—————————

**Formula 9: Days Until Renewal**

```
Use case: Client renewal alerts

Formula:
dateBetween(prop("Renewal Date"), now(), "days")

Combined with notification:
if(prop("Days Until Renewal") <= 30, "⚠️ Renew Soon!",
"")
```

—————————

**Formula 10: Total Tasks Done**

```
Use case: Project completion

Formula in Project DB:
length(filter(prop("Tasks"),
current.prop("Status") == "Done"))

Result: Count of completed tasks
```

---

### DATE FORMULAS

```
- now() - current time
- today() - today only (no time)
- year(date) - extract year
- month(date) - extract month
- day(date) - extract day
- dateAdd(date, num, unit) - add time
- dateSubtract(date, num, unit) - subtract
- dateBetween(date1, date2, unit) - difference

Units:
- "years", "months", "weeks", "days", "hours", "minutes"
```

—————————

**Examples:**

```
- "Quarter": "Q" + ceil(month(prop("Date"))/3)
- "Days Old": dateBetween(now(), prop("Created"), "days")
- "Renewal in Days": dateBetween(prop("Renewal"), now(), "days")
```

---

### LOGIC FORMULAS

```
- if(condition, true_value, false_value)
- and(cond1, cond2)
- or(cond1, cond2)
- not(condition)

Comparison:
- == (equal)
- != (not equal)
- < (less than)
- > (greater than)
- <= (less or equal)
- >= (greater or equal)
```

—————————

**Examples:**

```
- if(prop("Status") == "Done", "✅", "⏳")
- if(and(prop("Priority") == "High", prop("Days Old") > 7), "🚨 URGENT", "")
- if(or(prop("Status") == "Complete", prop("Status") == "Cancelled"), "Closed", "Open")
```

---

### TEXT FORMULAS

```
- concat(text1, text2) - combine
- length(text) - character count
- upper(text) - UPPERCASE
- lower(text) - lowercase
- contains(text, search) - search
- replace(text, find, replace) - substitute
- format(value) - convert to text
```

—————————

**Examples:**

```
- "Project: " + prop("Name") + " | " + prop("Status")
- if(contains(prop("Tags"), "Urgent"), "🚨", "")
```

---

### AGGREGATION (with Relations)

```
- length(filter(...)) - count items
- sum(prop("Numeric")) - via rollup
- average(prop("Numeric")) - via rollup
- max() / min() - extremes
```

—————————

**Examples (in Client DB pulling from Tasks):**

```
- "Total Tasks": length(prop("Tasks"))
- "Done Tasks": length(filter(prop("Tasks"),
   current.prop("Status") == "Done"))
- "% Complete": "Done Tasks" / "Total Tasks" × 100
```

---

### FORMULA PRINCIPLES

**Principle 1: Start simple**

✅ Build complex formulas step-by-step
- Mistakes hard to debug

—————————

**Principle 2: Test with data**

✅ Few sample entries
✅ Verify formula output
- Logic errors common

—————————

**Principle 3: Document complex**

✅ Comment what formula does
- Future you ไม่ remember

—————————

**Principle 4: Use rollups for related**

✅ Aggregations easier
- Direct formula complex

—————————

**Principle 5: Keep readable**

✅ Multiple lines OK
- Single line confusing

---

### COMMON FORMULA MISTAKES

**❌ Wrong types:**
- Multiply text + number = error

**❌ Missing parentheses:**
- Logic groups wrong

**❌ Date format issues:**
- now() vs today()

**❌ ไม่ test:**
- Formula errors silent

**❌ Over-complicate:**
- 50-character formulas
- Hard to debug

## Output Format

```
## Notion Formulas — [calculation]

### 10 Useful Formulas
1. Days until due
2. Project status auto
3. Profit calculation
4. LTV calculation
5. Health score
6. Tier classification
7. Days active
8. Hours per week avg
9. Days until renewal
10. Total tasks done

### Function Categories
- Date: now(), dateBetween(), dateAdd()
- Logic: if(), and(), or()
- Text: concat(), length(), contains()
- Math: standard operators

### Aggregation (Relations)
- length(filter(...))
- via rollups

### Principles (5)
1. Start simple
2. Test with data
3. Document complex
4. Use rollups for related
5. Keep readable

### Common Mistakes
❌ Wrong types ❌ Missing parens ❌ Date format ❌ ไม่ test ❌ Over-complicate
```

## Constraints

- Start simple, build up
- Test with sample data
- Document complex logic
- Use rollups for relations
- Keep formulas readable

## Anti-patterns

- ❌ Type mismatches
- ❌ Missing parentheses
- ❌ Untested formulas
- ❌ Single-line complex
- ❌ ไม่ documented

## Related Skills

- **notion-databases** — databases
- **notion-getting-started** — start

## Memory

- `user.formulas` — formulas
