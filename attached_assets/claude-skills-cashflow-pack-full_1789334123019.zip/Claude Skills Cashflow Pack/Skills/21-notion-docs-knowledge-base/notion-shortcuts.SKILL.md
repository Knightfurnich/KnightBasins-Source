---
name: Notion Shortcuts
id: notion-shortcuts
category: notion
trigger:
  - "notion shortcuts"
  - "notion productivity"
  - "notion fast"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Notion Power User — เข้าใจว่า keyboard shortcuts = 5x faster → mouse-only = slow

## Context

ผู้ใช้คือ Notion user wanting speed

## Triggers

- **"shortcuts"** → shortcuts
- **"keyboard"** → keyboard
- **"fast notion"** → fast

## Tools

Pure prompt — provide shortcuts

## Task

1. **Essential shortcuts**
2. **Advanced shortcuts**
3. **Slash commands**
4. **Speed tips**

## Examples

### ESSENTIAL SHORTCUTS

**Navigation:**

```
Cmd/Ctrl + N - New page
Cmd/Ctrl + P - Quick search
Cmd/Ctrl + [ - Back
Cmd/Ctrl + ] - Forward
Cmd/Ctrl + \ - Show/hide sidebar
Cmd/Ctrl + Shift + L - Switch theme

Effect: Navigate fast without mouse
```

—————————

**Editing:**

```
Cmd/Ctrl + B - Bold
Cmd/Ctrl + I - Italic
Cmd/Ctrl + U - Underline
Cmd/Ctrl + Shift + S - Strikethrough
Cmd/Ctrl + E - Inline code
Cmd/Ctrl + K - Add link
Cmd/Ctrl + / - Comments

Effect: Format quickly
```

—————————

**Block Manipulation:**

```
Cmd/Ctrl + Shift + 1 - Heading 1
Cmd/Ctrl + Shift + 2 - Heading 2
Cmd/Ctrl + Shift + 3 - Heading 3
Cmd/Ctrl + Shift + 7 - Bullet list
Cmd/Ctrl + Shift + 8 - Numbered list
Cmd/Ctrl + Shift + 4 - Toggle
Cmd/Ctrl + Shift + 9 - To-do list

Effect: Structure content fast
```

—————————

**Mention + Date:**

```
@ - Person mention
@today - Today's date
@tomorrow - Tomorrow
@now - Current time
:smile: - Emoji picker

Effect: Quick info insertion
```

—————————

**Selection + Movement:**

```
Cmd/Ctrl + A - Select all
Cmd/Ctrl + C - Copy
Cmd/Ctrl + V - Paste
Cmd/Ctrl + Z - Undo
Cmd/Ctrl + Shift + Z - Redo

Drag block:
Click + drag handle (left of block)

Move block:
Cmd/Ctrl + Shift + Arrow

Effect: Manage content fast
```

---

### SLASH COMMANDS

**Type "/" to open menu:**

```
Most useful:
- /h1, /h2, /h3 - Headings
- /bullet, /num - Lists
- /todo - Checklist
- /toggle - Collapsible
- /quote - Quote block
- /code - Code block
- /divider - Horizontal line
- /image - Add image
- /file - File upload
- /embed - Embed external
- /video - Video embed
- /table - Inline table
- /callout - Highlight box

Database commands:
- /database - Inline database
- /linked database - Embed existing
- /create-page - New page

AI commands (paid):
- /ai - AI writing assistant

Effect: Add anything via /
```

—————————

**Quick Tips:**

```
- "/" + first letter = filtered menu
  - "/h1" → directly to heading 1
  - "/q" → quote block

- Can chain shortcuts:
  - Type "/" → "code" → Enter
  
- Nest blocks:
  - Tab inside list = sub-bullet
  - Shift+Tab = back out
```

---

### NAVIGATION TIPS

**Quick Search (Cmd+P):**

```
Find anything fast:
- Type page name
- Filter by database
- Recent pages first
- Most visited shown

Effect: Find in 1-2 seconds
```

—————————

**Page History:**

```
Cmd/Ctrl + [ - Back
Cmd/Ctrl + ] - Forward
- Like browser navigation

Effect: Fast multi-page work
```

—————————

**Sidebar:**

```
- Cmd/Ctrl + \ to toggle
- Drag to resize
- Star pages for quick access

Effect: Familiar tree navigation
```

---

### POWER USER TIPS

**Tip 1: Synced Blocks**

```
Type: /sync
- Same content in multiple pages
- Edit once, updates everywhere
- For content shown multiple places

Effect: ไม่ duplicate
```

—————————

**Tip 2: Templates with Hotkeys**

```
- Page template + custom command
- Trigger via menu or shortcut

Effect: Reuse common structures
```

—————————

**Tip 3: Inline Code**

```
` (backtick) at start = inline code
```code``` (3 backticks) = code block

Effect: Code formatted fast
```

—————————

**Tip 4: Linked Mentions**

```
@page - Mention page (link)
@person - Mention person
@date - Date picker

Effect: Cross-reference fast
```

—————————

**Tip 5: Quick Database Creation**

```
Type: /linked
- Show existing database here
- Use any view of it

Effect: Same data reused
```

—————————

**Tip 6: Auto-formatting**

```
Type these and they auto-format:
- "1." then space → numbered list
- "*" then space → bullet
- "[]" then space → checkbox
- ">" then space → quote
- "/h1 " → heading

Effect: Markdown-like fast typing
```

—————————

**Tip 7: Drag to Multi-Select**

```
Click empty area + drag
- Multi-select blocks
- Move/copy together

Effect: Bulk operations
```

---

### COMMON PATTERNS

**Pattern 1: Note Capture**

```
Cmd+P → "daily note" → Enter
@today on top
Type ideas
Use h2 for sections

Time: 10 seconds total
```

—————————

**Pattern 2: New Task**

```
Open Tasks DB
"+" or Cmd+N
Type task name
Tab to next field
Set Status, Due Date, Priority
Enter to save

Time: 30 seconds
```

—————————

**Pattern 3: Add to Existing Page**

```
Open page
Cmd+End (jump to bottom)
Type new content
Auto-save on type

Time: Quick
```

—————————

**Pattern 4: Search + Edit**

```
Cmd+P → search title
Open page
Edit
Save automatically

Time: Few seconds
```

---

### MOBILE SHORTCUTS (Limited)

```
Mobile keyboard shortcuts:
- Hold space + drag = cursor movement
- Triple tap = select all
- Tap and hold = options

Best for mobile:
- Voice-to-text
- Quick capture
- Read/reference
- Simple edits
```

---

### SHORTCUT PRINCIPLES

**Principle 1: Master core 10**

✅ Cmd+P, Cmd+N, Cmd+B, etc.
- 80% productivity gain

—————————

**Principle 2: Use slash commands**

✅ Type "/" for everything
- Faster than menu

—————————

**Principle 3: Auto-formatting**

✅ Markdown-like
- Type as you think

—————————

**Principle 4: Avoid mouse**

✅ Keyboard-first when possible
- Speed = compound

—————————

**Principle 5: Practice regularly**

✅ Use shortcuts daily
- Becomes automatic

---

### TIME SAVED

**Without Shortcuts:**

```
- Every action = 3-5 mouse moves
- 5 hrs/day × 5 mouse moves/min × 60 min = 7,500 mouse moves
- Slow + tiring
```

—————————

**With Shortcuts:**

```
- Most actions = 1-2 keystrokes
- 30-50% time saved
- Less mental fatigue
- More fluid work

Compound:
- 30% × 8 hrs/day = 2.4 hrs/day saved
- 12 hrs/week
- 600 hrs/year

Effect: Major productivity
```

---

### COMMON MISTAKES

**❌ Mouse-only:**
- Slow
- Tiring
- ไม่ scaling

**❌ Don't learn /:**
- Miss most powerful feature
- Stuck in menus

**❌ ไม่มี practice:**
- Know shortcuts, ไม่ใช้
- ไม่ embed

**❌ Skip mobile:**
- Different mobile shortcuts
- Underutilize phone

## Output Format

```
## Notion Shortcuts — [level]

### Essential Shortcuts (Cmd/Ctrl)
- N: New page
- P: Quick search
- B/I/U: Format text
- K: Add link
- Z: Undo
- Shift+1/2/3: Headings

### Slash Commands
- /h1, /h2, /h3 - Headings
- /bullet, /num, /todo - Lists
- /toggle, /quote, /code
- /database, /linked-database
- /image, /file, /embed
- /ai (paid)

### Power User Tips
1. Synced blocks
2. Templates with hotkeys
3. Inline code (backticks)
4. Linked mentions (@)
5. Auto-formatting (1. → list)
6. Multi-select drag

### Time Saved
- 30-50% productivity gain
- 600+ hours/year saved
- Major impact

### Principles (5)
1. Master core 10
2. Use slash commands
3. Auto-formatting
4. Keyboard-first
5. Practice regularly

### Common Mistakes
❌ Mouse-only ❌ Skip "/" ❌ ไม่ practice ❌ Skip mobile
```

## Constraints

- Master core 10 shortcuts
- Use "/" commands
- Auto-formatting active
- Keyboard-first
- Practice daily

## Anti-patterns

- ❌ Mouse-only
- ❌ Menu navigation always
- ❌ Skip slash commands
- ❌ ไม่ practice
- ❌ Forget shortcuts exist

## Related Skills

- **notion-best-practices** — practices
- **notion-getting-started** — start

## Memory

- `user.shortcuts_mastered` — mastered
