---
name: Notion Tips And Tricks
id: notion-tips-and-tricks
category: notion
trigger:
  - "notion tips"
  - "notion tricks"
  - "notion hacks"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Notion Power Tips Curator — เข้าใจว่า hidden features = 10x productivity → most users ไม่ know

## Context

ผู้ใช้คือ Notion user wanting to level up

## Triggers

- **"tips"** → tips
- **"tricks"** → tricks
- **"hacks"** → hacks

## Tools

Pure prompt — provide tips

## Task

1. **Hidden features**
2. **Power tips**
3. **Workflow hacks**
4. **Common surprises**

## Examples

### POWER TIPS

**Tip 1: Quick Page Creation**

```
Sidebar → click + on workspace
Or: Cmd/Ctrl + N anywhere
Or: Type page name in inline mention

Effect: Page in seconds
```

—————————

**Tip 2: Drag Anything**

```
Block handle (left side):
- Drag to move
- Drag to side = column
- Drag out = new page

Effect: Restructure visually
```

—————————

**Tip 3: Multi-Select**

```
- Cmd/Ctrl+click multiple blocks
- Shift+click range
- Drag to select multiple

Then:
- Move all together
- Delete all
- Convert all (e.g., to bullets)

Effect: Bulk operations
```

—————————

**Tip 4: Backlinks**

```
At bottom of any page:
- "Backlinks" section
- Shows where this page is linked
- Click to navigate

Effect:
- See who references
- Discover connections
- Like Wikipedia internal
```

—————————

**Tip 5: Markdown Auto-Convert**

```
Type these and they auto-format:
- # → H1
- ## → H2
- * → bullet
- 1. → numbered
- [] → checkbox
- > → quote
- --- → divider
- ` → code
- ** → bold
- _ → italic

Effect: Type as markdown, get formatted
```

—————————

**Tip 6: Page in Page**

```
Inside any page, type "/page"
Or: Drag from sidebar inline
- Page link appears
- Or: Embed sub-page

Effect: Hierarchical knowledge
```

—————————

**Tip 7: Comment Threads**

```
- Highlight text
- Add comment
- Tag people (@)
- Resolve when done

Effect:
- Discussion in context
- Track decisions
- Assignable
```

—————————

**Tip 8: Page History**

```
Click "..." menu → Page history
- See all changes
- Restore old version
- Check who edited

Effect:
- Recovery from mistakes
- Audit trail
- Version control
```

—————————

**Tip 9: Star Pages**

```
Right-click page → "Add to favorites"
Or: ⭐ icon

Pinned in sidebar:
- Quick access
- Always visible

Effect: 1-click to important pages
```

—————————

**Tip 10: Custom URL**

```
"..." menu → Page settings → Custom URL

For shared pages:
- Cleaner links
- Easier to remember
- Better for sharing

Effect: Professional URLs
```

—————————

**Tip 11: Lock Pages**

```
"..." menu → Lock page

- Prevents accidental edits
- Useful for templates
- Useful for reference docs

Effect: Stable foundations
```

—————————

**Tip 12: Database Shortcuts**

```
In database:
- Shift+Enter: New row inline
- Shift+Cmd/Ctrl+P: Open as page
- Cmd/Ctrl+/: Filter
- F or Cmd/Ctrl+F: Filter shortcut

Effect: Database power
```

—————————

**Tip 13: Embed Anywhere**

```
Paste URL of:
- YouTube → video embed
- Twitter → tweet
- Spotify → audio
- Figma → design preview
- GitHub → code/issue
- Loom → video

Effect: Rich content from anywhere
```

—————————

**Tip 14: Sub-Items in DB**

```
Database with sub-items:
- Settings → Sub-items
- Tasks can have sub-tasks
- Project hierarchies

Effect: Hierarchical databases
```

—————————

**Tip 15: Templates Inside Page**

```
Inside any page:
- Drop a template
- Generates predefined content
- Click to instantiate

Effect: Reusable structures inline
```

---

### WORKFLOW HACKS

**Hack 1: Daily Note Auto**

```
Setup:
- Daily notes database
- Template with today's date in title
- Daily auto-create (via Notion automation paid)

Effect:
- Daily note ready every day
- ไม่ manual create
- Habit forming
```

—————————

**Hack 2: Weekly Review Magic**

```
Template: Weekly review

Pre-populate:
- This week's date range
- Linked filters for "this week" data
- Reflection prompts

Use:
- Friday afternoon ritual
- Reflect, plan, set goals
- Compound improvement

Effect: Built-in routine
```

—————————

**Hack 3: Project Templates Power**

```
Project template includes:
- Standard sections
- Pre-populated tasks
- Linked databases (filtered)

Click "+ New Project" in DB:
- Boom, ready to go
- Just fill specifics

Effect: 80% of project setup automatic
```

—————————

**Hack 4: Linked Filters**

```
On home dashboard:
- Tasks DB filter: Due today
- Tasks DB filter: This week
- Projects DB filter: Active

Different views, same data
- See exactly what need
- Multiple angles

Effect: Personalized dashboard
```

—————————

**Hack 5: Synced Blocks for Headers**

```
Synced block:
- Brand header (logo + nav)
- Same on every page
- Edit once, updates everywhere

Effect: Consistency without effort
```

—————————

**Hack 6: Mention Calendar**

```
@today, @yesterday, @tomorrow
@next Friday
@in 7 days

In tasks/notes:
- Quick date insertion
- Auto-update relative dates
- Organized

Effect: Speed entry
```

—————————

**Hack 7: Filter Tags Smart**

```
Tag: "Active" + Status: "In Progress"
Filter shows: True urgent items

Tag: "Stuck"
Filter: Items needing attention

Tag: "@Brand_A"
Filter: Brand-specific items

Effect: Smart organization
```

—————————

**Hack 8: AI Bulk Operations**

```
Database AI:
- Auto-categorize all entries
- Auto-summarize all docs
- Auto-translate batch

Effect: Hours saved
```

—————————

**Hack 9: Embedded Email**

```
Forward email → Notion-specific address (paid)
Or: Notion API integration

Email content auto-saves:
- Customer feedback
- Important threads
- Reference material

Effect: Email + Notion connected
```

—————————

**Hack 10: Voice Capture**

```
Mobile:
- Notion voice button
- Or phone dictation
- Or voice memo → process later

Effect:
- Capture while walking
- ไม่ stop to type
- Natural thinking
```

---

### COMMON SURPRISES

**Surprise 1: Free Plan Generous**

```
Free plan now (2026):
- Unlimited blocks (was limited)
- Up to 10 guests
- Recent file uploads OK
- Most features available

Effect:
- ไม่ rush to upgrade
- Test extensively first
- Free works for many
```

—————————

**Surprise 2: Mobile Better Than Expected**

```
Mobile features:
- Most work great
- Real-time sync
- Voice capture
- Quick widgets

Effect:
- Use mobile more
- ไม่ relegate to "desktop only"
```

—————————

**Surprise 3: Templates Galore**

```
Notion's template gallery:
- 100+ pre-built
- For every use case
- Free to use
- Learn from others' designs

Effect:
- Don't reinvent
- Inspiration source
- Quick start
```

—————————

**Surprise 4: Web Clipper**

```
Browser extension:
- Save articles to Notion
- Save with tags
- Clip + categorize

Effect:
- Build research library
- Save reading list
- Reference later
```

—————————

**Surprise 5: Notion Calendar**

```
Standalone Notion Calendar app:
- Connected to Notion DBs
- Date-based items shown
- Free + powerful

Effect:
- Calendar + Notion seamless
- Better than Google Calendar for some
- Worth trying
```

---

### EVERYDAY SHORTCUTS

**Quick Nav:**

```
Cmd/Ctrl + P - Search anything
Cmd/Ctrl + N - New page
Cmd/Ctrl + [ - Back
Cmd/Ctrl + ] - Forward
```

—————————

**Quick Format:**

```
Cmd/Ctrl + B - Bold
Cmd/Ctrl + I - Italic
Cmd/Ctrl + Shift + S - Strikethrough
Cmd/Ctrl + E - Inline code
```

—————————

**Quick Capture:**

```
@ - Mention person/page
[[ - Link to page
( - Inline mention
- Slash commands /
```

---

### CONTINUOUS LEARNING

**Stay Updated:**

```
- Notion blog (new features)
- YouTube tutorials
- Reddit r/Notion
- Notion VIP community
- Templates galleries

Effect:
- Keep learning
- Discover new features
- Optimize workflow
```

## Output Format

```
## Notion Tips And Tricks — [level]

### 15 Power Tips
1. Quick page creation (Cmd+N)
2. Drag anything (block handles)
3. Multi-select (bulk ops)
4. Backlinks (auto-shown)
5. Markdown auto-convert
6. Page in page (hierarchies)
7. Comment threads (@)
8. Page history (versions)
9. Star pages (favorites)
10. Custom URL (clean links)
11. Lock pages (stable)
12. Database shortcuts
13. Embed anywhere (paste URL)
14. Sub-items in DB
15. Templates inline

### 10 Workflow Hacks
1. Daily note auto
2. Weekly review magic
3. Project templates power
4. Linked filters
5. Synced blocks for headers
6. Mention calendar (@today)
7. Filter tags smart
8. AI bulk operations
9. Embedded email
10. Voice capture

### Common Surprises (5)
1. Free plan generous
2. Mobile better than expected
3. Templates galore
4. Web clipper
5. Notion Calendar app

### Everyday Shortcuts
- Cmd+P (search), Cmd+N (new)
- Cmd+B (bold), Cmd+I (italic)
- @ (mention), [[ (link)
```

## Constraints

- Master 15+ power tips
- Use slash commands
- Try mobile features
- Stay updated on new features
- Iterate workflow

## Anti-patterns

- ❌ Stick with basics only
- ❌ Skip mobile
- ❌ Don't try new features
- ❌ Reinvent vs use templates
- ❌ Stay stagnant

## Related Skills

- **notion-shortcuts** — shortcuts
- **notion-best-practices** — practices

## Memory

- `user.tips_used` — tips
