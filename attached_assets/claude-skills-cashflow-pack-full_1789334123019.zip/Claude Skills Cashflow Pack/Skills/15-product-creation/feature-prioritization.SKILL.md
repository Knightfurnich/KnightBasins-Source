---
name: Feature Prioritization
id: feature-prioritization
category: product
trigger:
  - "feature prioritization"
  - "prioritize features"
  - "product priorities"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Product Manager — เข้าใจว่า prioritization = limited resources + infinite features → must choose what matters most

Frameworks: RICE, MoSCoW, Kano Model, Value vs Effort, ICE

## Context

ผู้ใช้คือ founder + product team

## Triggers

- **"prioritize features"** → prioritize
- **"product priorities"** → priorities
- **"feature decision"** → decision

## Tools

Pure prompt — รับ feature list + constraints แล้ว prioritize

## Task

1. **Choose framework**
2. **Score features**
3. **Decision matrix**
4. **Communicate priorities**

## Examples

### RICE FRAMEWORK

**RICE Score = (Reach × Impact × Confidence) / Effort**

**Reach:** Customers affected per quarter
**Impact:** How big change?
**Confidence:** How sure of estimates?
**Effort:** Person-weeks

---

**Maverick example — Q3 features:**

| Feature | Reach | Impact | Confidence | Effort | Score |
|---------|-------|--------|------------|--------|-------|
| Sunscreen launch | 1,000 | 3 | 0.7 | 16 | 131 |
| Subscription customization | 500 | 2 | 0.9 | 8 | 113 |
| Mobile app (basic) | 300 | 1.5 | 0.6 | 20 | 14 |
| Eye cream launch | 700 | 2 | 0.8 | 12 | 93 |
| Loyalty program v2 | 800 | 1 | 0.8 | 6 | 107 |

**Priority order:**
1. Sunscreen (131)
2. Subscription customize (113)
3. Loyalty v2 (107)
4. Eye cream (93)
5. Mobile app (14) — Defer

---

### MOSCOW METHOD

**M - Must Have:**
- Critical for launch
- ไม่มี = product doesn't work

**S - Should Have:**
- Important but not critical
- Add if time permits

**C - Could Have:**
- Nice to have
- Add if surplus capacity

**W - Won't Have (this time):**
- Out of scope
- Future roadmap

---

**Maverick Sunscreen launch features:**

**Must Have:**
- SPF 50 PA++++ formula
- Lightweight gel
- 50ml bottle
- Basic packaging
- Quality testing complete
- Regulatory approval

**Should Have:**
- Multiple sizes (30ml, 100ml)
- Reef-safe formula
- Tinted version
- Travel-size

**Could Have:**
- Refill option
- Premium gift packaging
- Limited edition designs

**Won't Have:**
- Multiple variants (gel, cream, spray)
- Custom personalization
- Eco-friendly bottle
- International formulations

---

### KANO MODEL

**Categorize features by customer reaction:**

**🔴 Basic (Must-have):**
- Customer expects
- Absence = dissatisfaction
- Presence = neutral

**🟡 Performance (Linear):**
- More is better
- Quality matters
- Differentiator

**🟢 Excitement (Delighter):**
- Surprises customer
- Strong positive reaction
- Unique advantage

---

**Maverick Sunscreen Kano analysis:**

**Basic features:**
- Sun protection (expected)
- Safety (expected)
- Reasonable price

**Performance features:**
- Higher SPF (better)
- Lighter feel (better)
- No white cast (better)

**Excitement features:**
- Reef-safe formula
- Customer signature scent
- Compact mirror cap

---

### VALUE vs EFFORT MATRIX

```
                High Value
                    ▲
                    │
  Quick Wins        │   Major Projects
  ✅ Do First       │   📋 Plan Carefully
                    │
   ─────────────────┼──────────────►
   Low Effort       │   High Effort
                    │
  Fill-Ins          │   Money Pit
  ⏰ When Bored     │   ❌ Avoid
                    │
                    ▼
                 Low Value
```

**Quick Wins (top-left):**
- Loyalty program v2 (low effort, decent impact)
- Subscription customize (medium effort, high impact)

**Major Projects:**
- Sunscreen launch (high effort, high value)
- Mobile app (high effort, uncertain value)

**Fill-Ins:**
- Minor UI tweaks
- Small content updates

**Money Pit:**
- Custom features for 1 customer
- Over-engineered solutions

---

### PRIORITIZATION CRITERIA

**Beyond frameworks, consider:**

✅ **Customer impact**
- Solving real pain?
- High demand?
- Top complaints?

✅ **Strategic alignment**
- Matches vision?
- Builds moat?
- Competitive advantage?

✅ **Financial impact**
- Revenue potential?
- Margin contribution?
- Cost savings?

✅ **Technical feasibility**
- Can we build?
- How quickly?
- Risks?

✅ **Resource availability**
- Team capacity?
- Budget?
- Skills needed?

✅ **Time sensitivity**
- Market window?
- Competitor moves?
- Seasonal opportunity?

---

### DECISION MEETINGS

**Quarterly prioritization meeting:**

**Attendees:**
- Founder
- Product lead
- Marketing lead
- Operations lead

**Process:**

**Step 1: Review backlog (30 min)**
- All ideas + features

**Step 2: Score each (60 min)**
- RICE or chosen framework
- Discussion on disagreements

**Step 3: Decide (30 min)**
- Top 5 for quarter
- Resources allocated
- Owners assigned

**Step 4: Communicate (ongoing)**
- Team meeting
- Updates to roadmap
- Customer-facing announcements

---

### COMMUNICATING PRIORITIES

**Internal:**

```
Q3 2026 Top 5 Priorities:

1. Maverick Sunscreen Launch (Sep)
   Owner: Product Lead
   Score: 131 (highest)
   
2. Subscription Customization
   Owner: Engineering
   Score: 113
   
3. Loyalty Program v2
   Owner: Marketing
   Score: 107
   
4. Eye Cream R&D
   Owner: Product
   Score: 93 (build for Q4)
   
5. Customer Onboarding Optimization
   Owner: CS Lead
   Score: 85

DEFERRED:
- Mobile app (low score)
- International expansion (future)
```

---

**External (customers):**

```
What's Coming to Maverick Q3:

🌞 New Sunscreen for Thai climate (September)
🔧 Improved subscription experience
🎁 Better loyalty rewards (Maverick Crew)

Working on for Q4:
- New Eye Cream
- Enhanced personalization

Stay tuned!
— ครูเอ็ม
```

---

### SAYING NO

**Often hardest part of prioritization**

**Templates:**

**To customers requesting features:**
"ขอบคุณ feedback ครับ
[Feature] อยู่ใน backlog ของเรา
ตอนนี้กำลังให้ความสำคัญ [other priorities]
จะกลับมาดูในอนาคต"

**To team members:**
"This is great idea
Currently focused on [top priorities]
Let's add to backlog for next quarter review"

**To investors:**
"Considered, prioritized lower because:
- [Reason 1]
- [Reason 2]
Open to revisit in Q4"

---

### COMMON PRIORITIZATION MISTAKES

**❌ Saying yes to everything:**
- Spread thin
- Nothing finishes well

**❌ Loudest voice wins:**
- Founder pet projects
- Squeaky wheel

**❌ ไม่มี framework:**
- Subjective decisions
- Hard to defend

**❌ ไม่ communicate:**
- Team confused
- Customers wondering

**❌ Re-prioritize too often:**
- Whiplash
- Nothing finishes

## Output Format

```
## Feature Prioritization — [project]

### Frameworks (4+)
1. RICE
2. MoSCoW
3. Kano Model
4. Value vs Effort

### Scoring Methods
- RICE formula
- MoSCoW categorization
- Kano analysis
- Value-Effort matrix

### Prioritization Criteria
- Customer / Strategic / Financial / Feasibility / Resources / Time

### Decision Meeting Process
- Quarterly format

### Communicating Priorities
- Internal vs External

### Saying No Templates
- Customers / Team / Investors

### Common Mistakes
❌ Yes to everything ❌ Loudest voice ❌ No framework ❌ No communication ❌ Constant change
```

## Constraints

- Use framework consistently
- Quarterly review cadence
- Top 5 priorities (not 20)
- Communicate clearly
- Track outcomes

## Anti-patterns

- ❌ Subjective gut decisions
- ❌ Founder pet projects
- ❌ Yes to all customers
- ❌ Constant re-prioritization
- ❌ ไม่มี communication

## Related Skills

- **product-roadmap** — roadmap
- **product-idea-generation** — ideas
- **annual-business-plan** — annual

## Memory

- `user.feature_priorities` — priorities
- `user.scoring_history` — scores
- `user.deferred_features` — backlog
