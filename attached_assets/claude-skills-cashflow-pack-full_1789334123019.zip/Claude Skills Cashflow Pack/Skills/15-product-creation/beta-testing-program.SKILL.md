---
name: Beta Testing Program
id: beta-testing-program
category: product
trigger:
  - "beta testing program"
  - "beta tester"
  - "product beta"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Beta Program Specialist — เข้าใจว่า beta = pre-launch validation with real users → catch issues + refine product

Beta benefits: Real-world feedback, Bug discovery, Marketing buzz, Loyal customer base

## Context

ผู้ใช้คือ founder + product team

## Triggers

- **"beta tester"** → tester
- **"product beta"** → beta
- **"early access program"** → early access

## Tools

Pure prompt — รับ product แล้ว design beta program

## Task

1. **Recruit beta testers**
2. **Set expectations**
3. **Collect feedback**
4. **Iterate**
5. **Convert to brand advocates**

## Examples

### MAVERICK BETA PROGRAM

**Product:** Maverick Sunscreen (pre-launch)

```
═══════════════════════════════════════
  MAVERICK SUNSCREEN BETA PROGRAM
═══════════════════════════════════════

🎯 GOAL:
- Test product with 100 real Thai men
- Collect feedback before launch
- Identify issues
- Build advocate base

📅 TIMELINE: 8 weeks total

Week 1: Recruit + ship
Week 2-7: Use product
Week 8: Final feedback

🎁 INCENTIVE FOR BETA:
- Free product (5ml mini)
- 50% off launch price (when ready)
- "Maverick Insider" badge
- Featured in launch content

📊 EXPECTATIONS:
- Use product daily (4-8 weeks)
- Submit feedback weekly (10 min)
- Photos before/after (optional)
- Final survey (15 min)

═══════════════════════════════════════
```

---

### RECRUITMENT

**Where to find beta testers:**

✅ **Existing customer base**
- Maverick crew members
- Frequent buyers
- Engaged audience

✅ **Email list**
- Subscribers (warm)
- Specifically opted-in

✅ **LINE OA**
- Direct outreach
- Higher response rate

✅ **Social media**
- Public call for beta testers
- Application form

✅ **Influencers**
- Mid-tier (not mega)
- Authentic users

---

**Recruitment message:**

```
🚀 MAVERICK INSIDER PROGRAM 🚀

ขอ 100 ผู้ชายไทยมาทดลอง Sunscreen ใหม่

✨ Beta Tester Benefits:
- Free product (มูลค่า ฿390)
- 50% off launch (price ฿195 vs ฿390)
- "Maverick Insider" status
- Influence final product

📋 Expectations:
- Use 4-8 weeks
- Provide weekly feedback (10 min)
- Optional: Before/After photos

⏰ Apply: Closes [date]
🎯 Selection: 100 chosen by [date]
🚀 Ship: [date]

Apply: [Link or DM]
```

---

### SELECTION CRITERIA

**Mix of:**

- **Skin types:** Oily, dry, combination, sensitive
- **Ages:** 25-55 representative range
- **Locations:** Bangkok, provinces, abroad
- **Lifestyle:** Office, outdoor, athlete
- **Maverick history:** New vs existing customers

**Avoid:**
- Single demographic
- All friends/family
- All super-fans (biased positive)

---

### BETA TESTER ONBOARDING

**Welcome kit:**

✅ Personal welcome video from founder
✅ Beta tester guide (PDF)
✅ Product (full size or sample)
✅ Insider Slack/LINE OA group invite
✅ Feedback form links

**Setup expectations:**

```
สวัสดีครับ คุณ [Name]

ยินดีต้อนรับสู่ Maverick Insider Program! 🎉

✨ คุณคือ 1 ใน 100 คนแรกที่ลอง Maverick Sunscreen
ขอบคุณที่เข้าร่วม

📋 What's expected:
1. Use sunscreen daily (4-8 weeks)
2. Weekly check-in (10 min survey)
3. Final detailed feedback (Week 8)

📦 What you'll get:
- Free product
- 50% off launch
- Maverick Insider badge
- Direct access to me

📱 Join our LINE OA Insider group:
[Link]

Excited to hear what you think!
— ครูเอ็ม
```

---

### WEEKLY CHECK-INS

**Week 1: First impressions**
- Texture / smell / feel?
- Easy to apply?
- Fits routine?

**Week 2: Initial results**
- Skin reaction (any issues)?
- Performance vs expectations?

**Week 4: Mid-point**
- Compare to previous sunscreen
- Likes / dislikes
- Adjustments suggested

**Week 6: Approaching end**
- Would you buy at launch?
- Recommend to friend?
- Top issues / concerns

**Week 8: Final detailed**
- Complete survey
- Before/after photos
- Long-form thoughts

---

### FEEDBACK COLLECTION

**Multiple methods:**

**Quick polls (LINE OA):**
- 1-3 questions
- Easy to answer
- Daily/weekly

**Detailed surveys:**
- 10-15 questions
- Mid + end of beta
- Statistical data

**1-on-1 interviews:**
- 5-10 testers (deep dive)
- 30-60 min calls
- Qualitative insights

**Group discussions:**
- LINE OA group chat
- Foster discussion
- Discover patterns

**Direct DMs:**
- Personal observations
- Spontaneous feedback
- High engagement

---

### ITERATION FROM BETA

**Use feedback to:**

✅ **Refine product**
- Adjust formula based on reactions
- Improve packaging issues
- Address common complaints

✅ **Refine marketing**
- Best phrases customers use
- Pain points emphasized
- Benefits highlighted

✅ **Refine pricing**
- Validate price points
- Identify acceptable range
- Bundle interest

✅ **Refine launch**
- Reduce surprises
- Pre-tested processes
- Confident scaling

---

### CONVERT TO ADVOCATES

**At end of beta:**

✅ **Thank profusely**
- Personal note from founder
- Acknowledge contribution

✅ **Reward generously**
- 50% off promised
- Bonus surprise (extra gift)
- Lifetime perks

✅ **Make them feel special**
- "Maverick Insider" badge
- Featured in launch content
- Founder personal connection

✅ **Activate as advocates**
- Featured testimonials
- Refer friends
- Brand ambassadors
- Long-term partnership

---

### BETA PROGRAM METRICS

**Track:**

- Application rate (people apply / target)
- Selection diversity (skin type, demographic)
- Retention rate (% complete program)
- Feedback quality (helpful vs not)
- Conversion rate (beta → paid customer)
- Advocacy rate (% become evangelists)

**Targets:**
- Application: 200-500 (for 100 spots)
- Retention: 80%+
- Conversion: 90%+ (beta → paid)
- Advocacy: 30%+

---

### COMMON BETA MISTAKES

**❌ ไม่มี clear expectations:**
- Testers ไม่รู้ what to do
- Low feedback quality

**❌ Wrong tester mix:**
- All super-fans
- Biased feedback

**❌ ไม่ act on feedback:**
- Collect, don't iterate
- Wasted opportunity

**❌ Free product, no commitment:**
- Casual testers
- Low quality feedback

**❌ Skip post-beta engagement:**
- Lose connection
- Miss advocate building

## Output Format

```
## Beta Testing Program — [product]

### Goal Setting
- Target tester count
- Timeline
- Specific outcomes

### Recruitment Sources
- Existing customers / Email / LINE OA / Social / Influencers

### Selection Criteria
- Skin types / Ages / Locations / Lifestyle / History

### Beta Tester Onboarding
- Welcome kit
- Expectations clear

### Weekly Check-Ins
- Week 1, 2, 4, 6, 8 questions

### Feedback Collection Methods
- Polls / Surveys / Interviews / Group / DMs

### Iteration Plan
- Refine product / Marketing / Pricing / Launch

### Convert to Advocates
- Thank / Reward / Special / Activate

### Metrics
- Application / Retention / Conversion / Advocacy

### Common Mistakes
❌ No expectations ❌ Wrong mix ❌ Don't iterate ❌ No commitment ❌ Skip post-beta
```

## Constraints

- 50-150 testers ideal
- Diverse selection
- Clear expectations
- Multiple feedback methods
- Convert to advocates

## Anti-patterns

- ❌ Vague program
- ❌ All super-fans
- ❌ Don't act on feedback
- ❌ Free without commitment
- ❌ Forget testers post-beta

## Related Skills

- **product-validation** — validation
- **mvp-development** — MVP
- **customer-feedback-collection** — feedback

## Memory

- `user.beta_programs` — programs
- `user.beta_testers` — testers
- `user.beta_insights` — insights
