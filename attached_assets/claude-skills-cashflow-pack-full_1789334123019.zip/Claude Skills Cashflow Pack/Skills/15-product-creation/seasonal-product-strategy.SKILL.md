---
name: Seasonal Product Strategy
id: seasonal-product-strategy
category: product
trigger:
  - "seasonal product strategy"
  - "limited edition seasonal"
  - "holiday product"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Seasonal Strategy Specialist — เข้าใจว่า seasonal products = capitalize on cultural moments + create urgency + drive trial

Seasonal types: Holiday-specific, Weather-based, Cultural events, Anniversary

## Context

ผู้ใช้คือ founder + product team

## Triggers

- **"holiday product"** → holiday
- **"seasonal launch"** → seasonal
- **"limited edition"** → limited

## Tools

Pure prompt — รับ business + season แล้ว design strategy

## Task

1. **Identify seasonal opportunities**
2. **Product variations**
3. **Marketing campaigns**
4. **Inventory planning**

## Examples

### MAVERICK SEASONAL CALENDAR

```
═══════════════════════════════════════
  MAVERICK SEASONAL STRATEGY 2026
═══════════════════════════════════════

JANUARY — New Year
- Theme: "New Year, New Skin"
- Product: Maverick "Reset" set
- Bundle: Year of Maverick (12-month subscription)
- Marketing: Resolution-themed
- Discount: 27% off (year theme)

FEBRUARY — Valentine's
- Theme: "Self-Love Edition"
- Product: Maverick Reset (regular)
- Promotion: Buy 1 Give 1 (gift partner)
- Marketing: Self-care messaging
- Limited edition: Heart-themed packaging

APRIL — Songkran
- Theme: "Reset for Thai New Year"
- Product: Special "Songkran Edition" packaging
- Bundle: Travel kit (good for travel)
- Marketing: Cultural celebration
- Discount: 15%

MAY — Mother's Day
- Theme: "Gift the Man Who Cares for Mom"
- Promotion: Free gift wrap
- Marketing: Family/care messaging
- No major product change

AUGUST — Mother's Day Thai
- Theme: "Pamper Husband (for Mom)"
- Promotion: Gift sets
- Marketing: Spouse-buyer focus
- Yellow color (Thai Mother's Day)

NOVEMBER — Loy Krathong
- Theme: "Float Away Worries"
- Product: Calming variants?
- Marketing: Mindful + traditional
- Limited edition packaging

DECEMBER — Holiday Season
- Theme: "Maverick Gift Sets"
- Products: Premium gift boxes
- Bundle: All variations
- Marketing: Gift-giving push
- Special: "12 Days of Maverick"

═══════════════════════════════════════
```

---

### SEASONAL PRODUCT OPTIONS

**Option 1: Same product, different packaging**

✅ Limited edition box design
✅ Special label (Songkran water-themed, etc.)
✅ Cultural elements
✅ Limited-time only

**Pros:**
- Lower investment
- Create urgency
- Brand-aligned

**Cons:**
- Less differentiation
- Customer might not notice

---

**Option 2: Same product, special bundle**

✅ Bundle products together
✅ Themed gift box
✅ Add bonus items
✅ Limited-edition feel

**Pros:**
- Higher AOV
- Cross-sell opportunity
- Gift-giving angle

---

**Option 3: Limited Edition Variant**

✅ Slightly different formula (scent, color)
✅ Themed product
✅ Time-limited availability

**Examples:**
- Songkran: Cooling sensation Reset
- Holiday: Warm spice scented Reset
- Anniversary: Premium gold-flake serum

**Pros:**
- True limited edition feel
- Collector value
- Hype generation

**Cons:**
- More complex manufacturing
- Inventory risk if doesn't sell
- Higher cost

---

**Option 4: Brand New Seasonal Product**

✅ Completely new product for season
✅ Then permanent if successful

**Examples:**
- Songkran: Cooling Mist
- Winter: Heavy Moisturizer
- Summer: Anti-Pollution serum

**Pros:**
- Genuine product differentiation
- Long-term portfolio addition

**Cons:**
- Big investment
- Long lead time
- Risk if niche

---

### SEASONAL MARKETING CAMPAIGNS

**Pre-season (4 weeks before):**

✅ Tease announcement
✅ Email list "first to know"
✅ Social media buzz building
✅ Influencer seeding

**During season:**

✅ Daily content
✅ Customer testimonials
✅ Stock countdown
✅ Limited time emphasis

**Post-season:**

✅ Last chance push
✅ Thank you to buyers
✅ Hint at next seasonal

---

### SEASONAL MARKETING — Songkran Example

**4 Weeks Before (Late March):**

```
Maverick LINE OA / Email:

🌊 Songkran is coming!

ขอแจ้งล่วงหน้า — เรากำลังเตรียม:

🎁 Maverick Songkran Edition
- Special "water-themed" packaging
- Cooling Reset variant (NEW)
- Songkran Survival Kit bundle

📅 เริ่ม: April 1
🔚 จบ: April 30
📦 Limited stock

[Sign up for Early Access]
```

---

**Songkran Week:**

```
🌊 SONGKRAN SALE 🌊

Maverick Songkran Edition
- Cooling Reset Serum
- Travel-safe kit
- 15% off everything

Code: SONGKRAN15

Ends: April 30

[Shop Now]
```

---

### INVENTORY FOR SEASONAL

**Seasonal Inventory Planning:**

**Conservative approach:**
- Order based on previous year × 1.2
- Don't over-commit
- Quick reorder if selling fast

**Aggressive approach:**
- Bigger initial order
- Better per-unit cost
- Risk if doesn't sell

**Maverick approach:**
- Year 1: Conservative (test season)
- Year 2: Based on Year 1 data
- Year 3+: Confident pre-orders

---

### POST-SEASON HANDLING

**For unsold seasonal stock:**

**Option 1: Sell at discount**
- Markdown 30-50%
- Move quickly
- Cash recovery

**Option 2: Repackage as standard**
- Remove "limited edition" packaging
- Sell as regular
- Lower margin but moves

**Option 3: Charity / Gift**
- Donate to good cause
- Brand goodwill
- Tax benefit

**Avoid:**
❌ Holding indefinitely
❌ Expiration risk
❌ Storage costs

---

### SEASONAL METRICS

**Track per seasonal launch:**

✅ Sell-through rate (% sold)
✅ Margin (vs regular product)
✅ Customer feedback
✅ New customer acquisition
✅ Repeat customer engagement
✅ Marketing ROI

**Compare year-over-year for trends**

---

### COMMON SEASONAL MISTAKES

**❌ Late timing:**
- Launch Day-1
- Customers already bought elsewhere

**❌ Generic seasonal:**
- "Holiday box" with no theme
- ไม่ different from regular

**❌ Over-commit inventory:**
- Buy 5,000 limited
- Sell 2,000
- Stuck with 3,000

**❌ ไม่ marketing push:**
- Quietly launch
- ไม่มี awareness

**❌ Cultural insensitivity:**
- Wrong colors for holiday
- Inappropriate themes

## Output Format

```
## Seasonal Product Strategy — [season]

### Annual Calendar
- Per holiday/season planning

### Seasonal Product Options (4)
1. Same product, different packaging
2. Same product, special bundle
3. Limited edition variant
4. Brand new seasonal product

### Marketing Campaign Phases
- Pre-season / During / Post-season

### Inventory Planning
- Conservative vs Aggressive
- Per business stage

### Post-Season Handling
- Discount / Repackage / Donate

### Metrics to Track
- Sell-through / Margin / Feedback / Acquisition / Repeat / ROI

### Common Mistakes
❌ Late timing ❌ Generic ❌ Over-commit ❌ No marketing ❌ Cultural insensitivity
```

## Constraints

- Cultural awareness
- Plan 6+ months ahead
- Test small first
- Multi-channel marketing
- Track ROI

## Anti-patterns

- ❌ Day-of seasonal launch
- ❌ Generic seasonal effort
- ❌ Excess inventory commitment
- ❌ ไม่มี marketing push
- ❌ Cultural blunder

## Related Skills

- **seasonal-graphic-prompt** — graphics
- **flash-sale-funnel** — flash sale
- **inventory-planning** — inventory

## Memory

- `user.seasonal_calendar` — calendar
- `user.seasonal_performance` — performance
- `user.seasonal_strategies` — strategies
