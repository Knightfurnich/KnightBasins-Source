---
name: Wholesale Strategy
id: wholesale-strategy
category: product
trigger:
  - "wholesale strategy"
  - "B2B sales"
  - "reseller program"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Wholesale Strategist — เข้าใจว่า wholesale = volume + extended reach + new revenue → but lower margins + brand control

When to wholesale: Established brand, manufacturing scale, expansion ready

## Context

ผู้ใช้คือ founder ที่ scaling

## Triggers

- **"B2B sales"** → B2B
- **"reseller program"** → reseller
- **"wholesale pricing"** → wholesale

## Tools

Pure prompt — รับ business แล้ว design wholesale

## Task

1. **Wholesale models**
2. **Pricing tiers**
3. **Partner selection**
4. **Channel management**

## Examples

### WHOLESALE MODELS

**Model 1: Direct Resellers**
- Independent shops buy from you
- They sell at retail
- Many small partners

**Model 2: Distributors**
- Bulk buy + warehouse
- Resell to many shops
- Higher volume, lower direct relationships

**Model 3: White Label**
- They rebrand product
- Different label
- Higher MOQ

**Model 4: Marketplaces (Shopee/Lazada)**
- Platform sells your product
- Wholesale-like pricing
- Volume discounts

**Maverick approach:**
- Year 2: Direct resellers + Pantip community
- Year 3: Add distributors (Singapore, Malaysia)
- Eventually: Marketplace presence

---

### WHOLESALE PRICING TIERS

```
═══════════════════════════════════════
  Maverick Wholesale Tiers
═══════════════════════════════════════

Retail (single customer):
- Reset 30ml: ฿590

Wholesale Tier 1 (50-99 units):
- Discount: 17%
- Per unit: ฿490
- For: Small shops, beauty salons

Wholesale Tier 2 (100-249 units):
- Discount: 24%
- Per unit: ฿450
- For: Mid-size retailers

Wholesale Tier 3 (250-499 units):
- Discount: 29%
- Per unit: ฿420
- For: Larger retailers

Wholesale Tier 4 (500-999 units):
- Discount: 34%
- Per unit: ฿390
- For: Major retailers

Wholesale Tier 5 (1,000+ units):
- Negotiable
- Custom pricing
- For: Distributors, major chains

═══════════════════════════════════════
```

---

### WHOLESALE TERMS

**Standard Maverick Wholesale Terms:**

**Payment:**
- New partners: Net 30 (after 3 successful orders, full upfront before)
- Established: Net 30 standard
- Strategic: Net 60 or longer

**MOQ:**
- Tier 1: 50 units
- Tier 2-3: 100 units
- Tier 4: 500 units
- Tier 5: 1,000 units

**Lead Time:**
- 7-14 days from PO

**Returns:**
- Defective only
- Within 30 days
- Pre-approved

**Marketing:**
- Brand guidelines must follow
- No deep discounting
- Approved channels only

**Territory:**
- Non-exclusive (default)
- Exclusive for premium partners with commitment

---

### PARTNER SELECTION

**Good wholesale partners:**

✅ **Brand-aligned:**
- Premium positioning
- Customer overlap
- Quality reputation

✅ **Sales capability:**
- Existing customer base
- Strong sales team
- Marketing ability

✅ **Financial:**
- Pay on time
- Stable business
- Adequate capital

✅ **Operations:**
- Storage capability
- Customer service
- Returns handling

**Avoid:**

❌ Price-only focus
❌ Unprofessional inquiries
❌ Brand misalignment
❌ Slow response in negotiations
❌ Compete directly with our channels

---

### WHOLESALE APPLICATION PROCESS

**Step 1: Initial Inquiry**

Wholesale interested? → DM/Email
- "Looking to wholesale Maverick"

Maverick response:
"Thanks for interest. Please share:
- Business name + registration
- Sales channels
- Order volume estimate
- Why us specifically"

---

**Step 2: Application**

Required:
- Business registration
- Tax ID
- Reference customers (3+)
- Bank info
- Sales channels detail
- Marketing capability

---

**Step 3: Discovery Call (30 min)**

Founder + potential partner:
- Mutual fit discussion
- Volume expectations
- Terms negotiation
- Brand alignment check

---

**Step 4: Pilot Order**

First order:
- Standard wholesale pricing
- Lower MOQ (often)
- Test relationship
- 2-3 orders to qualify

---

**Step 5: Ongoing Partnership**

After successful pilot:
- Standard MOQ
- Better pricing tiers
- Priority service
- Joint marketing

---

### WHOLESALE OPERATIONS

**Onboarding:**

✅ Wholesale catalog (PDF)
✅ Brand guidelines
✅ Marketing assets (photos, copy)
✅ Order forms
✅ Account manager assigned

**Ongoing support:**

✅ Monthly check-ins
✅ New product first access
✅ Joint marketing opportunities
✅ Volume incentives
✅ Annual reviews

**Issue resolution:**

✅ Quick response
✅ Fair handling
✅ Documented process
✅ Escalation path

---

### WHOLESALE METRICS

**Track per partner:**

✅ **Order frequency**
- Monthly orders typical
- Drop-off = relationship issue

✅ **Volume growth**
- YoY comparison
- Healthy = growing

✅ **Sell-through**
- They sell to retail well?
- Or stuck inventory?

✅ **Payment timeliness**
- On-time payments
- Risk indicator

✅ **Brand compliance**
- Following guidelines?
- Maintaining pricing?

---

### COMMON WHOLESALE MISTAKES

**❌ Sell to anyone:**
- ไม่มี filter
- Brand damage from wrong partners

**❌ Margin too thin:**
- Wholesale eats too much
- Cannot scale

**❌ Compete with own customers:**
- Direct DTC undercut
- Wholesale partners angry

**❌ ไม่มี contracts:**
- Disputes hard
- IP unclear

**❌ Race to bottom:**
- Lowest price wins
- Brand value destroyed

---

### WHOLESALE vs DTC BALANCE

**For Maverick:**

**Year 1-2: DTC focus (90%+)**
- Build brand
- Direct customer relationships
- Higher margins

**Year 3+: Hybrid**
- DTC: 70%
- Wholesale: 25%
- Marketplace: 5%

**Why DTC priority:**
- Higher margins
- Customer data
- Brand control
- Direct relationships

**Why eventual wholesale:**
- Volume scale
- Geographic expansion
- Different customers
- Predictable revenue

---

### WHOLESALE PROMOTION

**Internal marketing:**

✅ "Looking for Premium Resellers" page
✅ Specific application form
✅ Wholesale catalog
✅ Industry events presence
✅ Trade publications ads

**Partner success stories:**

✅ Feature top partners
✅ Joint case studies
✅ Mutual referrals

## Output Format

```
## Wholesale Strategy — [business]

### Wholesale Models (4)
1. Direct resellers
2. Distributors
3. White label
4. Marketplaces

### Pricing Tiers
- Tier 1-5 by volume
- Discount structure

### Wholesale Terms
- Payment / MOQ / Lead time / Returns / Marketing / Territory

### Partner Selection
- Good ✅ vs Avoid ❌

### Application Process (5 steps)
1. Initial inquiry
2. Application
3. Discovery call
4. Pilot order
5. Ongoing partnership

### Operations
- Onboarding / Support / Issues

### Metrics per Partner
- Frequency / Volume / Sell-through / Payment / Compliance

### DTC vs Wholesale Balance
- Year-by-year evolution

### Common Mistakes
❌ Sell to anyone ❌ Thin margins ❌ Compete with customers ❌ No contracts ❌ Race to bottom
```

## Constraints

- Tier-based pricing
- Quality partners only
- Clear terms
- Track per partner
- Balance with DTC

## Anti-patterns

- ❌ Sell to anyone
- ❌ Thin margins
- ❌ Compete with own DTC
- ❌ ไม่มี contracts
- ❌ Race to bottom

## Related Skills

- **wholesale-inquiry-response** — inquiry
- **partner-funnel** — partner
- **product-pricing-strategy** — pricing

## Memory

- `user.wholesale_partners` — partners
- `user.wholesale_pricing` — pricing
- `user.wholesale_metrics` — metrics
