---
name: Product Idea Generation
id: product-idea-generation
category: product
trigger:
  - "product idea generation"
  - "new product brainstorm"
  - "product ideation"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Product Innovation Specialist — เข้าใจว่า product idea = solution to real problem → not all ideas equal → systematic approach

Idea sources: Customer pain, Competitor gaps, Trend signals, Technology, Founder vision

## Context

ผู้ใช้คือ founder + product team

## Triggers

- **"new product idea"** → idea
- **"brainstorm product"** → brainstorm
- **"product ideation"** → ideation

## Tools

Pure prompt — รับ business + research แล้ว generate ideas

## Task

1. **Source ideas multiple ways**
2. **Evaluate ideas**
3. **Prioritize**
4. **Validate top ideas**

## Examples

### IDEA SOURCES

**Source 1: Customer Pain Points**

✅ Direct customer feedback
✅ Support ticket patterns
✅ Survey responses
✅ Pantip / Reddit threads
✅ Social media complaints

**Maverick examples:**
- "Want sunscreen for Thai climate" → Sunscreen launch
- "Need eye cream" → Eye cream development
- "Subscription too rigid" → Flexible subscription

---

**Source 2: Competitor Gaps**

✅ What competitors don't have
✅ What competitors do badly
✅ Underserved segments

**Maverick examples:**
- No Thai-specific brand → Original Maverick
- No flexible subscription → Easy-cancel feature
- No men's mask product → Future opportunity

---

**Source 3: Trend Signals**

✅ Industry trends (clean beauty, AI)
✅ Cultural shifts (men's self-care)
✅ Technology enablers
✅ Regulatory changes

**Maverick examples:**
- Clean beauty trend → Refillable packaging
- TikTok trend → TikTok-native products
- Sustainable trend → Eco-packaging

---

**Source 4: Founder Vision**

✅ Founder unique perspective
✅ Industry expertise
✅ Personal need
✅ Market knowledge

**Often best ideas come from founder solving own problem**

---

**Source 5: Adjacent Markets**

✅ Solutions in other industries
✅ Cross-pollination
✅ Inspiration from unrelated fields

**Examples:**
- Subscription model from media → Maverick subscription
- Personalization from food delivery → Custom skin routine
- Community from fitness → Maverick Crew

---

### IDEA GENERATION TECHNIQUES

**Technique 1: Customer Reverse Engineering**

Start with customer outcome:
"I want clear skin in 30 days"

Then ask:
- What products help?
- What features matter?
- What's missing in market?
- What do they wish existed?

---

**Technique 2: Jobs-To-Be-Done (JTBD)**

Customer "hires" products to do "jobs"

**Examples:**
- Job: "Look professional for meetings"
- Job: "Feel confident after shower"
- Job: "Save time on routine"

**For each job, identify:**
- Current solutions
- Pain points
- Better solutions

---

**Technique 3: 5 Whys**

Start with surface need:
"Want sunscreen"

Why? "To protect from sun"
Why? "Prevent skin damage"
Why? "Want to look young"
Why? "Confidence + career"
Why? "Live full life"

**Deep need:** Confidence + youth

**Product: Sunscreen with anti-aging claims**

---

**Technique 4: Trend × Customer Mash-up**

**Trend:** TikTok-native products
**Customer:** Thai Gen Z men

**Mash-up:**
- Pocket-size for TikTok GRWM (get ready with me)
- Rapid-result claims
- Trendy packaging
- TikTok-friendly demos

---

**Technique 5: Crazy 8s Brainstorm**

Solo brainstorm:
- 8 minutes
- 8 ideas
- One per minute
- ไม่ judge

**Generate volume, evaluate later**

---

**Technique 6: "What if?" Questions**

- What if no skincare existed?
- What if skincare cost ฿10,000?
- What if free for everyone?
- What if AI diagnosed for you?
- What if you could see future skin?

**Reveals new angles**

---

### MAVERICK IDEA BACKLOG

```
═══════════════════════════════════════
  Maverick Product Idea Backlog
═══════════════════════════════════════

🔴 HIGH PRIORITY:

1. Maverick Sunscreen
   - Customer demand: Very high
   - Trend fit: ✅
   - Manufacturing: ✅ Possible
   - Margin: Good
   - Complexity: Medium

2. Maverick Eye Cream
   - Customer demand: High
   - Cross-sell potential: ✅
   - Manufacturing: ✅
   - Margin: Good
   - Complexity: Medium

3. Maverick Cleanser
   - Customer demand: Medium
   - Routine completion: ✅
   - Manufacturing: ✅
   - Margin: Lower
   - Complexity: Low

🟡 MEDIUM PRIORITY:

4. Maverick Mask
5. Subscription customization
6. Travel kit
7. Body wash for men
8. Anti-aging line (premium)

🟢 EXPLORE FUTURE:

9. Personalized skincare (AI)
10. Refillable program
11. International expansion products
12. Maverick course (skincare education)

═══════════════════════════════════════
```

---

### IDEA EVALUATION CRITERIA

**Score each idea (1-10):**

**Customer Demand:**
- How many ask for this?
- How urgent the need?

**Market Size:**
- TAM (total addressable market)
- Growth trajectory

**Competition:**
- Crowded market?
- Differentiation possible?

**Margins:**
- COGS vs price
- Sustainable economics

**Brand Fit:**
- Aligns with Maverick?
- Strengthens position?

**Complexity:**
- Manufacturing difficulty
- Supply chain
- Time to market

**Timeline:**
- Days to launch
- Resource needed

**Sample evaluation (Sunscreen):**

| Criterion | Score | Notes |
|-----------|-------|-------|
| Customer demand | 9 | Very high requests |
| Market size | 8 | Growing 15%/yr |
| Competition | 6 | Crowded but underserved Thai |
| Margins | 7 | Good with right formula |
| Brand fit | 9 | Perfect (Thai climate) |
| Complexity | 6 | Regulatory + formulation |
| Timeline | 7 | 6-9 months |

**Total: 52/70 = High priority**

---

### IDEA VALIDATION

**Before commit, validate:**

**Step 1: Survey existing customers**
- "Would you buy this?"
- "What price would you pay?"
- "What features matter?"

**Step 2: Pre-order test**
- Landing page with product
- Take pre-orders (refundable)
- Validates demand

**Step 3: Smoke test**
- Run ads for product
- See click-through + conversion
- Measure interest

**Step 4: Customer interviews**
- Deep dive 10-20 customers
- Refine concept
- Identify must-haves

**Step 5: MVP prototype**
- Small batch
- Real customers test
- Iterate based on feedback

---

### IDEA KILLERS

**When to kill an idea:**

❌ Validation fails (low pre-orders)
❌ Margins don't work
❌ Complexity too high vs reward
❌ Competitor launches better version
❌ Customer interviews show wrong assumption
❌ Resources better spent elsewhere

**Killing fast = saves resources**

---

### IDEA TRACKING

**Maintain idea database:**

**Format:**
- Idea name
- Source (customer / competitor / trend)
- Date added
- Evaluation score
- Status (idea / validating / building / launched / killed)
- Notes

**Tools:**
- Notion database
- Airtable
- Custom spreadsheet

---

### COMMON IDEA GENERATION MISTAKES

**❌ Founder bubble:**
- Only founder ideas
- Miss customer voice

**❌ Volume over quality:**
- 100 ideas, none validated
- Need both

**❌ ไม่ kill bad ideas:**
- Pursue everything
- Resources spread thin

**❌ Copy competitors:**
- Me-too products
- ไม่มี differentiation

**❌ Skip validation:**
- Build, then test
- Wasteful

## Output Format

```
## Product Idea Generation — [business]

### Idea Sources (5)
1. Customer pain points
2. Competitor gaps
3. Trend signals
4. Founder vision
5. Adjacent markets

### Idea Generation Techniques (6)
1. Customer reverse engineer
2. Jobs-to-be-done (JTBD)
3. 5 Whys
4. Trend × Customer mash-up
5. Crazy 8s
6. "What if?" questions

### Idea Backlog Template
- High / Medium / Future priority

### Evaluation Criteria (7)
- Demand / Market / Competition / Margins / Brand fit / Complexity / Timeline

### Idea Validation (5 steps)
1. Survey customers
2. Pre-order test
3. Smoke test
4. Customer interviews
5. MVP prototype

### Idea Killers
- When to kill

### Idea Tracking
- Database structure

### Common Mistakes
❌ Founder bubble ❌ Volume over quality ❌ Don't kill ❌ Copy competitors ❌ Skip validation
```

## Constraints

- Multiple sources for ideas
- Systematic evaluation
- Validate before commit
- Kill bad ideas fast
- Track in database

## Anti-patterns

- ❌ Founder-only ideas
- ❌ Volume without quality
- ❌ Pursue every idea
- ❌ Copy competitors
- ❌ Skip validation steps

## Related Skills

- **product-validation** — validation
- **mvp-development** — MVP
- **trend-research** — trends

## Memory

- `user.product_ideas` — ideas
- `user.idea_validations` — validations
- `user.product_decisions` — decisions
