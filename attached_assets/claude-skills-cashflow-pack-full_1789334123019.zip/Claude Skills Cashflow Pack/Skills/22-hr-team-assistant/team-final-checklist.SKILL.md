---
name: Team Final Checklist
id: team-final-checklist
category: hr
trigger:
  - "team checklist"
  - "hr checklist"
  - "team complete"
mcp: []
version: 1.0.0
---

## System

คุณเป็น HR Operations Auditor — เข้าใจว่า great teams = systematic foundation → checklist ensures nothing missed

## Context

ผู้ใช้คือ business owner

## Triggers

- **"checklist"** → checklist
- **"audit"** → audit

## Tools

Pure prompt — รับ stage แล้ว audit

## Task

1. **Foundation checklist**
2. **Operational checklist**
3. **Cultural checklist**
4. **Long-term**

## Examples

### FOUNDATION CHECKLIST

**Hiring + Onboarding:**

```
□ Job descriptions specific + transparent
□ Multi-stage interview process
□ Reference checks mandatory
□ Trial period (1 month paid)
□ Day 1 schedule documented
□ Onboarding plan (30/60/90 days)
□ Buddy system in place
□ Cultural integration practices

Effect: Strong start for all
```

—————————

**Employment Documentation:**

```
□ Employment contracts signed
□ Tax forms completed
□ Bank info on file
□ Emergency contacts
□ Benefits enrolled
□ Equipment assigned
□ NDA signed (if applicable)
□ Annual handbook acknowledgment

Effect: Compliance + clarity
```

—————————

**Compensation Structure:**

```
□ Salary bands defined per role
□ Annual review cadence
□ Performance bonus criteria
□ Benefits package documented
□ Equity policy (if applicable)
□ Pay equity audit annually
□ Total compensation transparency

Effect: Fair + competitive
```

—————————

**Performance Management:**

```
□ 30-day check-in for new hires
□ Quarterly reviews
□ Annual comprehensive review
□ Continuous feedback culture
□ PIP process documented
□ Career path mapped
□ Skill development plans
□ 360-degree feedback (annual)

Effect: Performance + development
```

---

### OPERATIONAL CHECKLIST

**Team Operations:**

```
□ Org structure defined
□ Reporting lines clear
□ Decision rights (RACI) documented
□ Communication norms agreed
□ Meeting cadence established
□ Tool stack chosen
□ Working hours defined
□ Vacation policy clear

Effect: Smooth operations
```

—————————

**Manager Skills:**

```
□ Managers trained on:
  - 1-on-1s effectively
  - Constructive feedback
  - Performance reviews
  - Difficult conversations
  - Career development
  - Conflict resolution
□ Manager 1-on-1s with own boss
□ Manager skills assessed annually

Effect: Strong leadership layer
```

—————————

**Communication:**

```
□ Slack/Discord setup
□ Email norms
□ Meeting protocols
□ Async vs sync defaults
□ Documentation standards
□ Notion/wiki accessible
□ Cross-functional channels
□ Feedback loops two-way

Effect: Clear + efficient
```

—————————

**Legal Compliance:**

```
□ Anti-discrimination policy
□ Anti-harassment policy
□ PDPA compliance (data privacy)
□ Working hours compliance
□ Vacation/leave compliance
□ Maternity policy
□ Termination process
□ Annual handbook review
□ Lawyer review (annual)

Effect: Legal protection
```

---

### CULTURAL CHECKLIST

**Mission + Values:**

```
□ Mission statement clear
□ Core values (5) defined
□ Behavioral examples per value
□ All employees understand
□ Lived in daily decisions
□ Founder models behavior
□ Values discussed openly

Effect: Cultural foundation
```

—————————

**Cultural Practices:**

```
□ Daily standups (or async)
□ Weekly team meetings
□ Friday wins celebration
□ Monthly all-hands
□ Quarterly offsite/strategic
□ Annual offsite (1-3 days)
□ Birthday + anniversary recognition
□ Major win celebrations
□ Failure reflection (no blame)

Effect: Culture lived daily
```

—————————

**Recognition + Rewards:**

```
□ Daily recognition (Slack)
□ Weekly wins celebrated
□ Monthly awards (specific)
□ Quarterly bonuses
□ Annual major awards
□ Performance + cultural awards
□ Specific + behavioral
□ Public + private mix

Effect: Recognition culture
```

—————————

**Engagement:**

```
□ Quarterly pulse surveys
□ Annual comprehensive survey
□ Stay interviews (quarterly)
□ Action on feedback visible
□ Engagement metrics tracked
□ Manager NPS measured
□ Cultural fit assessed

Effect: Continuously engaged
```

—————————

**Wellness:**

```
□ Health insurance provided
□ Mental health support
□ Wellness budget
□ Vacation truly off
□ Work-life boundaries respected
□ Burnout prevention
□ Work hour limits
□ Family priorities honored

Effect: Sustainable team
```

---

### LONG-TERM CHECKLIST

**Annual Activities:**

```
□ Performance reviews (all)
□ Compensation reviews
□ Benefits review
□ Policy review
□ Manager training refresh
□ Cultural health check
□ Engagement survey
□ Strategic planning
□ Hiring plan next year
□ Departures handled smoothly

Effect: Continuous improvement
```

—————————

**Quarterly Activities:**

```
□ OKR setting + review
□ Performance check-ins
□ Stay interviews
□ Pulse surveys
□ Cross-functional planning
□ Celebrations
□ Process improvements
□ Skill development progress

Effect: Quarterly cadence
```

—————————

**Monthly Activities:**

```
□ All-hands meeting
□ Department reports
□ Performance trends review
□ Hiring updates
□ Departures discussed
□ Cultural moments
□ Team lunches/events

Effect: Monthly attention
```

—————————

**Weekly Activities:**

```
□ Team meetings
□ Manager 1-on-1s
□ Strategic discussions
□ Issue escalations
□ Wins celebrated

Effect: Weekly rhythm
```

---

### TEAM HEALTH METRICS

**Annual Targets:**

```
- Retention rate: 85%+
- Average tenure: 24+ months
- NPS (employee): 60+
- Engagement score: 4+/5
- Performance: 85%+ meeting expectations
- Diversity goals: Met
- Compensation equity: Verified
- Cultural fit: 4+/5

If meeting all: Healthy team
If multiple below: Address systematically
```

—————————

**Quarterly Reviews:**

```
- Pulse survey results
- Performance trends
- Cultural health
- Manager effectiveness
- Compensation equity
- Diversity metrics

Action:
- Address trends
- Specific interventions
- Track over time

Effect: Continuous improvement
```

---

### TEAM PRINCIPLES SUMMARY

```
1. Hire for skills + culture
2. Onboard systematically (90 days)
3. Compensate fairly (market+)
4. Develop continuously
5. Recognize frequently
6. Manage performance proactively
7. Build cultural rituals
8. Communicate clearly
9. Support whole person
10. Address conflicts quickly
11. Promote from within when possible
12. Document policies + procedures
13. Track metrics monthly
14. Iterate based on feedback
15. Lead by example
```

---

### COMMON TEAM MISTAKES

**❌ Hire fast (regret slow)**
**❌ Skip onboarding**
**❌ Below-market pay**
**❌ ไม่มี development plan**
**❌ Annual feedback only**
**❌ Skip recognition**
**❌ Avoid hard conversations**
**❌ Tolerate breaches**
**❌ ไม่ track metrics**
**❌ Founder bottleneck**

## Output Format

```
## Team Final Checklist — [stage]

### Foundation Checklist
- Hiring + Onboarding
- Employment Documentation
- Compensation Structure
- Performance Management

### Operational Checklist
- Team Operations
- Manager Skills
- Communication
- Legal Compliance

### Cultural Checklist
- Mission + Values
- Cultural Practices
- Recognition + Rewards
- Engagement
- Wellness

### Long-Term
- Annual / Quarterly / Monthly / Weekly activities

### Team Health Targets
- Retention 85%+
- Tenure 24+ months
- NPS 60+
- Engagement 4+/5
- Performance 85%+ meet/exceed

### 15 Team Principles
1. Hire for skills + culture
2. Onboard systematically
3. Compensate fairly
4. Develop continuously
5. Recognize frequently
6. Manage performance
7. Build cultural rituals
8. Communicate clearly
9. Support whole person
10. Address conflicts
11. Promote from within
12. Document policies
13. Track metrics
14. Iterate
15. Lead by example
```

## Constraints

- Foundation comprehensive
- Operational systems
- Cultural practices
- Track metrics monthly
- Iterate continuously

## Anti-patterns

- ❌ Foundational gaps
- ❌ Operational chaos
- ❌ Weak culture
- ❌ ไม่ measure
- ❌ Founder dependency

## Related Skills

- **team-culture** — culture
- **agency-team-building** — team

## Memory

- `user.team_health` — health
- `user.team_metrics` — metrics
