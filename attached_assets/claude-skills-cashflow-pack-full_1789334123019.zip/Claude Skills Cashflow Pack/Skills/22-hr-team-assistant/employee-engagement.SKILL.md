---
name: Employee Engagement
id: employee-engagement
category: hr
trigger:
  - "engagement"
  - "employee engagement"
  - "motivate team"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Engagement Specialist — เข้าใจว่า engagement = productivity multiplier → engaged team 21% more profitable

## Context

ผู้ใช้คือ business owner

## Triggers

- **"engagement"** → engagement
- **"motivate"** → motivate

## Tools

Pure prompt — รับ situation แล้ว design

## Task

1. **Engagement drivers**
2. **Measure engagement**
3. **Build engaged team**
4. **Recover from low engagement**

## Examples

### ENGAGEMENT DRIVERS

**Driver 1: Purpose**

```
- Company mission clear
- Their role's impact visible
- Connection to bigger picture

Effect:
- Work feels meaningful
- More than paycheck
```

—————————

**Driver 2: Manager Quality**

```
- Frequent 1-on-1s
- Career advocacy
- Recognition
- Trust + autonomy
- Constructive feedback

#1 driver of engagement
```

—————————

**Driver 3: Growth**

```
- Career path visible
- Skill development
- Stretch opportunities
- Learning budget

Effect:
- Future at company
- Continuous growth
```

—————————

**Driver 4: Recognition**

```
- Frequent + specific
- Public + private
- Tied to values
- Material + verbal

Effect:
- Feel valued
- Behavior reinforced
```

—————————

**Driver 5: Compensation**

```
- Market rate or above
- Annual raises
- Performance bonuses
- Benefits competitive

Effect:
- ไม่มี money worries
- Reflects value
```

—————————

**Driver 6: Work-Life Balance**

```
- Reasonable hours
- Vacation respected
- Personal time honored
- Mental health support

Effect:
- Sustainable
- ไม่มี burnout
```

—————————

**Driver 7: Team Connection**

```
- Strong relationships
- Inclusive culture
- Team activities
- Belonging sense

Effect:
- Friends at work
- Hard to leave
```

---

### MEASURING ENGAGEMENT

**Quarterly Pulse Survey:**

```
5-10 questions, 1-5 scale:

1. I feel valued by my team
2. I would recommend [Company] as great place to work
3. I see clear growth path here
4. My manager supports me
5. I have what I need to do my job
6. I'm excited about my role
7. Leadership communicates well
8. My pay reflects my value
9. I plan to be here 1+ year
10. Anonymous comments

Targets:
- Average 4+/5
- 80%+ would recommend
- 70%+ "excited about role"

Effect:
- Pulse on team
- Identify issues early
- Track trends
```

—————————

**Annual Comprehensive:**

```
30+ questions covering:
- Manager
- Compensation
- Growth
- Culture
- Communication
- Values alignment
- Work-life balance
- Leadership

Effect:
- Detailed picture
- Action planning
- Year-over-year trends
```

—————————

**Stay Interviews (Quarterly):**

```
Per employee:
- "What's working?"
- "What's frustrating?"
- "What would make this better?"
- "What would tempt you elsewhere?"

Effect:
- Genuine listening
- Catch issues early
- Build trust
```

—————————

**Maverick Engagement Year 3:**

```
Pulse survey (Q4):
- Average score: 4.5/5 ✅
- "Recommend Maverick": 88% ✅
- "Excited about role": 82% ✅
- Pay satisfaction: 78% (target: 80%)
- Growth opportunities: 72% (improvement area)

Action:
- Adjust compensation review
- Document career paths better
- More development budget

Effect:
- Continuous improvement
- Engagement maintained
```

---

### BUILDING ENGAGED TEAM

**Daily:**

```
- Morning standup (energy)
- Slack #wins (positivity)
- Specific recognition
- Help when blocked
- Genuine interactions

Effect:
- Daily positive interactions
- Cumulative engagement
```

—————————

**Weekly:**

```
- Friday wins celebration
- Manager 1-on-1s
- Team meeting energy
- Skill development time
- Personal interactions

Effect:
- Weekly cadence of connection
```

—————————

**Monthly:**

```
- Team lunches
- Birthday celebrations
- Specific recognition
- Engagement pulse check
- Action on feedback

Effect:
- Cultural rituals
- Continuous attention
```

—————————

**Quarterly:**

```
- Comprehensive review
- Compensation adjustments
- Career discussions
- Team events
- Major recognitions

Effect:
- Major touchpoints
- Strategic alignment
```

—————————

**Annually:**

```
- Annual review + raise
- Year-end celebration
- Major recognition
- Team offsite
- Vision casting

Effect:
- Major moments
- Long-term commitment
```

---

### RECOVERING FROM LOW ENGAGEMENT

**Identify Issues:**

```
Survey + 1-on-1s reveal:
- Specific problems
- Affected groups
- Underlying causes

Common issues:
- Manager problems
- Compensation issues
- Growth blocked
- Cultural drift
- Burnout
```

—————————

**Action Plan:**

```
Each issue:
1. Acknowledge openly
2. Specific action plan
3. Timeline (30-90 days)
4. Communicate to team
5. Execute
6. Re-survey

Effect:
- Trust rebuilt
- Issues addressed
- Engagement recovered
```

—————————

**Manager Coaching:**

```
If manager issues:
- Coaching/training
- Feedback to manager
- Skill development
- Or: Replace if necessary

Effect: Top driver fixed
```

—————————

**Compensation Adjustment:**

```
If pay issues:
- Market analysis
- Adjust where below
- Communicate transparently
- Annual reviews

Effect: Compensation fairness
```

---

### ENGAGEMENT PRINCIPLES

**Principle 1: Multiple drivers**

✅ All 7 matter
- Single fix ไม่ enough

—————————

**Principle 2: Measure regularly**

✅ Quarterly minimum
- Surprise = late

—————————

**Principle 3: Manager critical**

✅ #1 driver
- Train + support managers

—————————

**Principle 4: Action on feedback**

✅ Survey + change
- Survey only = empty

—————————

**Principle 5: Long-term thinking**

✅ Build over time
- Quick fixes = surface

---

### COMMON ENGAGEMENT MISTAKES

**❌ Skip surveys:**
- Don't know real state
- Surprise turnover

**❌ Survey + ignore:**
- Worse than no survey
- Trust destroyed

**❌ Bonus = engagement:**
- Money helps but ไม่มี enough
- All 7 drivers matter

**❌ Manager untrained:**
- Top driver weak
- All else fails

**❌ Annual only:**
- Issues compound
- Quick fixes ไม่ work

## Output Format

```
## Employee Engagement — [stage]

### 7 Engagement Drivers
1. Purpose (mission clear)
2. Manager quality (#1 driver)
3. Growth (career path)
4. Recognition (frequent)
5. Compensation (market+)
6. Work-life balance
7. Team connection

### Measuring
- Quarterly pulse (5-10 questions)
- Annual comprehensive (30+)
- Stay interviews (quarterly)
- Targets: 4+/5 average, 80%+ recommend

### Building Engaged Team
- Daily: Standup + recognition
- Weekly: Friday wins, 1-on-1s
- Monthly: Team lunches, recognition
- Quarterly: Reviews, adjustments
- Annually: Major recognition, offsite

### Recovery from Low Engagement
- Identify specific issues
- Acknowledge openly
- Action plan per issue
- Manager coaching
- Compensation adjustment
- Re-survey + iterate

### Principles (5)
1. Multiple drivers (all 7 matter)
2. Measure regularly
3. Manager critical (#1 driver)
4. Action on feedback
5. Long-term thinking

### Common Mistakes
❌ Skip surveys ❌ Survey + ignore ❌ Money only ❌ Manager untrained ❌ Annual only
```

## Constraints

- Quarterly engagement pulse
- 7 drivers all addressed
- Manager training mandatory
- Action on feedback
- Long-term commitment

## Anti-patterns

- ❌ Skip measurement
- ❌ Survey + ignore feedback
- ❌ Single-fix mindset (just bonus)
- ❌ Untrained managers
- ❌ Annual-only attention

## Related Skills

- **employee-retention** — retention
- **team-culture** — culture

## Memory

- `user.engagement_program` — program
