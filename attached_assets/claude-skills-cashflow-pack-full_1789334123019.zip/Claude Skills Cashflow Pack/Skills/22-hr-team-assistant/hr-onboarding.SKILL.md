---
name: HR Onboarding
id: hr-onboarding
category: hr
trigger:
  - "employee onboarding"
  - "new employee"
  - "first day"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Onboarding Specialist — เข้าใจว่า first 30-90 days = make-or-break → great onboarding = 80%+ retention

Phases: Pre-arrival, Day 1, First 30, First 90

## Context

ผู้ใช้คือ HR/manager

## Triggers

- **"onboarding"** → onboarding
- **"new hire"** → new hire

## Tools

Pure prompt — รับ role แล้ว design

## Task

1. **Pre-arrival prep**
2. **Day 1 experience**
3. **First 30 days plan**
4. **90-day review**

## Examples

### MAVERICK ONBOARDING TIMELINE

**Pre-Arrival (1-2 weeks before):**

```
Manager:
□ Send welcome email
□ Share team contact info
□ Send first-day logistics
□ Order equipment (laptop, etc.)
□ Setup all accounts
□ Calendar invite for week 1
□ Notify team
□ Prepare workstation/desk

Operations:
□ Equipment ready
□ Office access cards
□ Email/Slack/Notion accounts
□ Tool licenses purchased
□ HR paperwork ready

Effect:
- New hire welcomed
- ไม่มี delays
- Smooth start
```

—————————

**Day 1: Welcome + Setup**

```
9:00 AM - Welcome
- Greet at door/entrance
- Coffee + tour
- Introduce immediate team

9:30 AM - HR Paperwork
- Tax forms
- Bank info for salary
- Employment contract
- Benefits enrollment
- Emergency contact

10:30 AM - Tools Setup
- Laptop unboxing
- Email setup
- Slack login
- Notion access
- All other tools

11:30 AM - Lunch with Team
- Casual conversation
- Build relationships
- Welcome them

1:00 PM - Manager 1-on-1
- Welcome chat
- Role expectations review
- Initial questions
- Goal setting brief

2:00 PM - Required Reading
- Mission, vision, values
- Brand guidelines
- HR policies
- Company history

4:00 PM - First Project Brief
- Small intro project
- Pair with senior
- Goals + timeline

5:00 PM - Day Wrap-Up
- Q&A
- Tomorrow's schedule
- Send home with materials

Effect:
- Welcomed feeling
- Information given
- First project started
```

—————————

**First Week:**

```
Day 2: Shadow Senior
- Observe 1-on-1 work
- Ask questions
- Note processes

Day 3: First Small Tasks
- Pair with senior
- Hands-on work
- Quality reviewed

Day 4: Independent Small
- Take on own task
- Senior available
- Build confidence

Day 5: Week 1 Review
- 1-on-1 with manager
- Reflect on week
- Adjust expectations
- Set Week 2 goals

Effect:
- Gradual ramp-up
- Confidence building
- Issues caught early
```

—————————

**First 30 Days:**

```
Week 1: Foundation (cover above)

Week 2: Pair Work
- Pair with senior on multiple tasks
- Take ownership of small client
- Get feedback

Week 3: Independent Small
- Lead 1-2 small projects
- Senior reviews
- Learning loop

Week 4: Independent Larger
- Take on real responsibility
- Less oversight
- Quality maintained

End of 30 days:
- Performance review
- Cultural fit assessment
- Continue or adjust
- Set 60-day goals
```

—————————

**30-Day Review Template:**

```
# 30-Day Review - [Name]

## What's Going Well
- ___
- ___

## What's Challenging
- ___
- ___

## Skills Assessment
- Technical: __/10
- Cultural fit: __/10
- Communication: __/10
- Growth potential: __/10

## Initial Concerns
- ___

## Decision
□ Continue (formal hire confirmed)
□ Extend probation (60 more days)
□ Part ways respectfully

## Next 60 Days Plan
- Specific projects
- Skills to develop
- Cultural integration goals

## Compensation Update
- Adjust based on performance (if needed)

Effect: Clear assessment + path
```

—————————

**90-Day Review:**

```
Comprehensive review:
- Full performance assessment
- Goal achievement
- Cultural integration
- Team feedback (360-degree)
- Career discussion

Outcomes:
- Move to standard performance reviews (quarterly)
- Promotion path clarified
- Long-term commitment established

Effect: Solid contributor + retained team member
```

---

### ONBOARDING DOCUMENTS

**Welcome Packet:**

```
- Welcome letter from founder
- Company overview
- Mission, vision, values
- Org chart
- Map of key contacts
- Office tour info
- First-day schedule
- Required reading list

Effect: Self-serve information
```

—————————

**Role-Specific Onboarding:**

```
For each role:
- Role-specific reading
- Process documents
- Tool tutorials
- Past project examples
- Templates to use
- Required certifications

Effect: Role-specific competence quickly
```

—————————

**HR Documents:**

```
- Employment contract
- Benefits info
- Compensation breakdown
- Bank info forms
- Tax forms
- Emergency contacts
- Insurance enrollment
- Vacation policy

Effect: Compliance + clarity
```

---

### KEY ONBOARDING ELEMENTS

**Element 1: Buddy System**

```
Assign experienced peer:
- Mentor for casual questions
- Cultural ambassador
- Friend for first weeks

Effect:
- Lonely fix
- Quick orientation
- Cultural integration
```

—————————

**Element 2: Manager 1-on-1s**

```
Weekly first month:
- Day 5
- Day 12
- Day 19
- Day 26
- Day 30 (review)

Then bi-weekly:
- Day 45, 60, 75, 90 (review)

Then monthly:
- Standard cadence

Effect:
- Catch issues early
- Build relationship
- Adjust expectations
```

—————————

**Element 3: Cultural Integration**

```
Activities:
- Team lunches (regular)
- Company events
- After-hours optional
- Team retreats (annual)

Effect:
- Belong to team
- Personal connections
- Culture absorbed
```

—————————

**Element 4: Feedback Loop**

```
Manager feedback:
- Frequent + specific
- Both positive + constructive
- Action-oriented

New hire feedback:
- "How's it going?"
- "What's confusing?"
- "What's needed?"
- Adjust based on input

Effect:
- Two-way communication
- Continuous improvement
- ไม่มี surprises
```

---

### COMMON ONBOARDING MISTAKES

**❌ Throw in deep end:**
- Day 1 = full client load
- Overwhelm + quit

**❌ ไม่ structured:**
- "Figure it out"
- Lost + frustrated

**❌ Skip cultural integration:**
- Just job tasks
- Lonely + ไม่ retention

**❌ ไม่มี mentor:**
- Manager-only support
- Manager too busy

**❌ Skip 30-day review:**
- Issues unspoken
- Surprise quit at 90 days

**❌ Information overload Day 1:**
- 100 docs to read
- ไม่ retain

## Output Format

```
## HR Onboarding — [role]

### Onboarding Timeline (4 phases)
1. Pre-arrival (1-2 weeks before)
2. Day 1 (welcome + setup)
3. First 30 days (gradual ramp-up)
4. 90-day review (comprehensive)

### Day 1 Schedule
- 9 AM: Welcome + tour
- 9:30 AM: HR paperwork
- 10:30 AM: Tools setup
- 11:30 AM: Team lunch
- 1:00 PM: Manager 1-on-1
- 2:00 PM: Required reading
- 4:00 PM: First project
- 5:00 PM: Wrap-up

### First 30 Days
- Week 1: Foundation
- Week 2: Pair work
- Week 3: Independent small
- Week 4: Independent larger
- Day 30: Formal review

### Onboarding Documents
- Welcome packet
- Role-specific docs
- HR documents

### Key Elements (4)
1. Buddy system
2. Manager 1-on-1s (weekly first month)
3. Cultural integration (lunches, events)
4. Feedback loop (two-way)

### Common Mistakes
❌ Throw in deep end ❌ ไม่ structured ❌ Skip culture ❌ ไม่มี mentor ❌ Skip 30-day ❌ Info overload
```

## Constraints

- Pre-arrival prep complete
- Structured Day 1
- Gradual ramp-up
- 30-day formal review
- Buddy system always

## Anti-patterns

- ❌ Sink-or-swim approach
- ❌ Unstructured "figure it out"
- ❌ Job-only (no culture)
- ❌ Skip mentor
- ❌ Information overload

## Related Skills

- **agency-team-building** — team
- **hiring-strategy** — strategy

## Memory

- `user.onboarding_program` — program
