---
name: Coaching Employees
id: coaching-employees
category: hr
trigger:
  - "coaching"
  - "coach employees"
  - "employee coaching"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Coach — เข้าใจว่า coaching = develop people → instead of solving for them

## Context

ผู้ใช้คือ manager

## Triggers

- **"coaching"** → coaching

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **Coaching framework**
2. **Powerful questions**
3. **When to coach vs direct**
4. **Long-term development**

## Examples

### COACHING FRAMEWORK

**GROW Model:**

```
G - Goal (what they want)
R - Reality (current situation)
O - Options (paths forward)
W - Way Forward (action plan)

Process:
- Ask, ไม่ tell
- Their solutions = ownership
- Guide, ไม่ direct
- Build their capability
```

—————————

**Goal:**

```
Questions:
- "What outcome do you want?"
- "What does success look like?"
- "What would be best result?"

Effect:
- Clear destination
- Their language
- Aligned expectations
```

—————————

**Reality:**

```
Questions:
- "What's the current situation?"
- "What have you tried?"
- "What's working/not?"

Effect:
- Clear starting point
- Self-assessment
- Identify gaps
```

—————————

**Options:**

```
Questions:
- "What are your options?"
- "What else could you try?"
- "What would [admired person] do?"

Effect:
- Brainstorm solutions
- Their ideas
- Multiple paths
```

—————————

**Way Forward:**

```
Questions:
- "Which option will you take?"
- "What's the first step?"
- "When will you do this?"
- "How will you know it worked?"

Effect:
- Specific commitment
- Action plan
- Accountability
```

---

### POWERFUL QUESTIONS

**Open-Ended:**

```
✅ "Tell me about..."
✅ "What if..."
✅ "How would you..."
✅ "What's the impact of..."

❌ Closed (yes/no):
- "Did you do X?"
- "Are you OK?"

Effect:
- Deeper thinking
- Their solutions
- More learning
```

—————————

**Specific Questions:**

```
For exploration:
- "What's most important?"
- "What's the underlying need?"
- "What are you afraid of?"

For action:
- "What's stopping you?"
- "What support do you need?"
- "When will you start?"

For commitment:
- "On a scale 1-10, how committed?"
- "What would make it 10?"
- "What's your first action?"

Effect:
- Specific reflection
- Real commitment
```

—————————

**ไม่ Leading Questions:**

```
ไม่:
- "Don't you think you should...?"
- "Wouldn't it be better to...?"
- "Have you considered [my answer]?"

Yes:
- "What do you think?"
- "What are you considering?"
- "How might you approach this?"

Effect:
- Their thinking
- Real solutions
- Build capability
```

---

### WHEN TO COACH VS DIRECT

**Coach When:**

```
- Employee has capability
- Time available
- Building skills important
- Their solution = ownership
- Mid-level + senior employees
- Career development conversations
- Complex problems

Effect: Develop people long-term
```

—————————

**Direct When:**

```
- Crisis (no time)
- New employee (less capability)
- Specific information needed
- Clear right answer
- Emergency
- Compliance issues
- Beginner level

Effect: Quick + appropriate
```

—————————

**Mix:**

```
Most situations = mix:
- Coach for development
- Direct on specifics
- Adapt to person + situation

Effect:
- Right tool right time
- ไม่ one-style only
```

---

### COACHING IN 1-ON-1S

**Format:**

```
30-min weekly:
- Employee-driven agenda
- Their priorities
- Coaching questions
- Goals + support

Manager listens 70%, talks 30%

Effect:
- Real coaching
- ไม่มี status meeting
```

—————————

**Sample 1-on-1 Coaching:**

```
Employee: "I'm struggling with Brand A account."

ไม่:
"You should do X, Y, Z"

Yes:
"What specifically is challenging?"
"What have you tried so far?"
"What options do you see?"
"What support would help?"
"What's your first step?"

Effect:
- Their solution
- Confidence built
- Skills developed
```

—————————

**Skills Development:**

```
Questions:
- "What skills would help you grow?"
- "How could you develop these?"
- "What's your learning plan?"
- "How will you apply on real work?"

Effect:
- Self-directed learning
- Manager facilitates
```

---

### LONG-TERM COACHING

**Career Coaching:**

```
Questions:
- "Where do you see yourself in 5 years?"
- "What experiences would help you get there?"
- "What's the gap?"
- "What's your plan?"

Effect:
- Long-term vision
- Specific path
- Aligned development
```

—————————

**Performance Coaching:**

```
For underperformers:
- "What's getting in the way?"
- "What support do you need?"
- "How will you address this?"
- "When will you check progress?"

Effect:
- Their ownership
- ไม่ excuses
- Improvement
```

—————————

**Strength Coaching:**

```
For high performers:
- "What's your unique strength?"
- "How can you leverage more?"
- "What stretch challenge?"
- "Who can you mentor?"

Effect:
- Build on strengths
- Continued growth
- Leadership development
```

---

### EXTERNAL COACHING

**For Senior Employees:**

```
Executive coaches:
- ฿5K-30K/month
- Bi-weekly sessions
- 6-12 month engagements
- Specific outcomes

Best for:
- Senior leaders
- Specific challenges
- Career transitions
- Major decisions

Effect:
- Outside perspective
- Specialist expertise
- Deeper development
```

—————————

**Internal Coaching:**

```
Senior + junior pairs:
- Bi-weekly meetings
- Free
- Less formal
- Career-focused

Effect:
- Knowledge transfer
- Network building
- Cultural integration
```

---

### COACHING PRINCIPLES

**Principle 1: Ask, don't tell**

✅ Their solutions
- Telling = limit growth

—————————

**Principle 2: Listen 70%**

✅ Genuine listening
- Talk = ไม่ coaching

—————————

**Principle 3: Powerful questions**

✅ Open-ended
- Closed = limited

—————————

**Principle 4: Their pace**

✅ ไม่ rush
- Pressure = ไม่ thinking

—————————

**Principle 5: Build capability**

✅ Long-term focus
- Quick fix = dependency

---

### COMMON COACHING MISTAKES

**❌ Tell don't ask:**
- "Just do X"
- ไม่ build capability

**❌ Leading questions:**
- "Don't you think...?"
- ไม่ their thinking

**❌ Solve for them:**
- "Here's what to do"
- Quick fix, no growth

**❌ Skip when busy:**
- "ไม่มี time"
- Long-term loss

**❌ Coach inappropriate situations:**
- Crisis = direct
- New hire = guide more

## Output Format

```
## Coaching Employees — [situation]

### GROW Model
- G: Goal (what they want)
- R: Reality (current situation)
- O: Options (paths forward)
- W: Way Forward (action plan)

### Powerful Questions
- Open-ended ("Tell me about...")
- Specific (exploration, action, commitment)
- ไม่ leading

### When Coach vs Direct
- Coach: Capability + time + development
- Direct: Crisis, new hire, specific info
- Mix: Most situations

### 1-on-1 Coaching
- Employee-driven agenda
- Manager listens 70%
- Powerful questions
- Their solutions

### Long-Term Coaching
- Career (5-year vision)
- Performance (their ownership)
- Strengths (build on talents)

### External Coaching (Senior)
- Executive coaches ฿5K-30K/month
- Specialist expertise
- 6-12 month engagements

### Principles (5)
1. Ask, don't tell
2. Listen 70%
3. Powerful questions
4. Their pace
5. Build capability

### Common Mistakes
❌ Tell don't ask ❌ Leading questions ❌ Solve for them ❌ Skip when busy ❌ Coach inappropriate
```

## Constraints

- Ask questions, don't tell
- Listen 70% of time
- Open-ended powerful questions
- Match style to situation
- Build long-term capability

## Anti-patterns

- ❌ Tell-only management
- ❌ Leading questions
- ❌ Solve for employees
- ❌ Skip coaching when busy
- ❌ Coach in crisis (just direct)

## Related Skills

- **manager-skills** — manager
- **employee-development** — development

## Memory

- `user.coaching_practice` — practice
