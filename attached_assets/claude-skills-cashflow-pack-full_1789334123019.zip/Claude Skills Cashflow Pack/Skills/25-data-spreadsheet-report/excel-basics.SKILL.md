---
name: Excel Basics
id: excel-basics
category: data
trigger:
  - "excel basics"
  - "spreadsheet basics"
  - "google sheets"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Spreadsheet Coach — เข้าใจว่า Excel/Sheets = essential business tool → master = productivity

## Context

ผู้ใช้คือ business user

## Triggers

- **"excel"** → Excel
- **"spreadsheet"** → spreadsheet

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **Core skills**
2. **Common formulas**
3. **Best practices**
4. **Productivity tips**

## Examples

### CORE SKILLS

**Cell References:**

```
A1: Specific cell
A1:A10: Range
A:A: Entire column
1:1: Entire row
$A$1: Absolute reference (locked)
$A1: Column locked, row not
A$1: Row locked, column not

Effect: Reference correctly
```

—————————

**Basic Formulas:**

```
=A1+B1: Add
=A1-B1: Subtract
=A1*B1: Multiply
=A1/B1: Divide
=A1^2: Power
=ABS(A1): Absolute value
=ROUND(A1,2): Round to 2 decimals

Effect: Calculations
```

—————————

**Common Functions:**

```
SUM:
=SUM(A1:A10)

AVERAGE:
=AVERAGE(A1:A10)

MIN/MAX:
=MIN(A1:A10)
=MAX(A1:A10)

COUNT:
=COUNT(A1:A10) - numbers only
=COUNTA(A1:A10) - non-empty
=COUNTIF(A1:A10, ">100") - conditional

IF:
=IF(A1>100, "High", "Low")

Effect: Quick analysis
```

—————————

**Lookup Functions:**

```
VLOOKUP:
=VLOOKUP(A1, B1:D10, 2, FALSE)
- Find A1 in column B
- Return matching value from column 2 of range
- FALSE = exact match

INDEX/MATCH (more flexible):
=INDEX(C1:C10, MATCH(A1, B1:B10, 0))
- More powerful than VLOOKUP
- Two-way lookups possible

XLOOKUP (newer):
=XLOOKUP(A1, B1:B10, C1:C10)
- Modern replacement
- Easier syntax

Effect: Find data
```

—————————

**Text Functions:**

```
=LEN(A1): Length
=UPPER(A1): UPPERCASE
=LOWER(A1): lowercase
=PROPER(A1): Title Case
=TRIM(A1): Remove extra spaces
=CONCAT(A1,B1): Combine text
=LEFT(A1,5): First 5 chars
=RIGHT(A1,5): Last 5 chars
=MID(A1,3,5): Middle

Effect: Manipulate text
```

—————————

**Date Functions:**

```
=TODAY(): Current date
=NOW(): Current date + time
=DATE(2026,1,15): Specific date
=YEAR(A1), =MONTH(A1), =DAY(A1)
=DATEDIF(A1,B1,"d"): Days between
=EDATE(A1,3): 3 months later
=WEEKDAY(A1): Day of week (1-7)

Effect: Date math
```

---

### BEST PRACTICES

**Organize Data:**

```
- Headers in row 1
- Data starts row 2
- One topic per sheet
- Consistent formatting
- ไม่ merged cells (for data)

Effect: Workable data
```

—————————

**Format Properly:**

```
- Numbers as numbers
- Dates as dates
- Currency formatting
- Percentages as %
- Text as text

Avoid:
- Numbers as text
- Mixed formats

Effect: Calculations work
```

—————————

**Use Tables:**

```
Convert to Table (Excel):
- Auto-formatting
- Auto-expanding
- Built-in filters
- Structured references
- Easier formulas

Effect: Better data management
```

—————————

**Named Ranges:**

```
Define names:
- "SalesData" instead of A1:Z100
- More readable
- Easier to maintain
- Self-documenting

Effect: Cleaner formulas
```

—————————

**Data Validation:**

```
Restrict input:
- Dropdown lists
- Number ranges
- Date ranges
- Custom rules

Effect: ไม่มี bad data
```

---

### PRODUCTIVITY TIPS

**Keyboard Shortcuts (Critical):**

```
Cmd/Ctrl+C: Copy
Cmd/Ctrl+V: Paste
Cmd/Ctrl+Z: Undo
Cmd/Ctrl+Y: Redo
Cmd/Ctrl+S: Save
Cmd/Ctrl+F: Find
Cmd/Ctrl+H: Replace
F2: Edit cell
Cmd/Ctrl+;: Today's date
Cmd/Ctrl+Shift+;: Current time
Cmd/Ctrl+Arrow: Jump to end
Cmd/Ctrl+Shift+Arrow: Select to end
Cmd/Ctrl+End: Last cell
Cmd/Ctrl+Home: First cell

Effect: Speed
```

—————————

**Auto-Fill:**

```
- Type pattern (1, 2, 3)
- Drag down: Continues
- Or double-click fill handle
- Auto-extends

Effect: Quick series
```

—————————

**Paste Special:**

```
Ctrl+Alt+V (Paste Special):
- Values only (no formulas)
- Format only
- Transpose (rows ↔ columns)
- Other options

Effect: Specific paste
```

—————————

**Conditional Formatting:**

```
- Highlight cells based on rules
- Color scales
- Data bars
- Icon sets

Effect: Visual data
```

—————————

**Filter + Sort:**

```
- Filter: Show specific rows
- Sort: Reorder data
- Multiple criteria
- Custom sort

Effect: Find what need
```

---

### SHEETS-SPECIFIC

**Google Sheets Advantages:**

```
- Real-time collaboration
- Version history
- Auto-save
- Share easily
- Free + cloud-based
- Apps Script for automation

Effect: Modern workflow
```

—————————

**Sheets-Specific Functions:**

```
=GOOGLEFINANCE(): Stock data
=GOOGLETRANSLATE(): Translate
=IMPORTRANGE(): Pull from other sheets
=IMPORTHTML(): Pull from web
=ARRAYFORMULA(): Apply to array

Effect: Web-connected
```

—————————

**Excel vs Sheets:**

```
Excel pros:
- More powerful
- Larger datasets
- More features
- Power Query, Power Pivot

Sheets pros:
- Free
- Cloud-native
- Collaboration
- Easy sharing

Best:
- Use Sheets for collaboration
- Excel for power users

Effect: Match to need
```

---

### MAVERICK SPREADSHEET USE

**Common Sheets:**

```
- Financial dashboards
- Customer database
- Project trackers
- KPI tracking
- Forecasting models
- Budget tracking

Tools:
- Google Sheets primary (collaboration)
- Excel for advanced analysis
- Looker Studio for visualization

Effect: Versatile data work
```

—————————

**Build Once Template:**

```
For recurring needs:
- Build template carefully
- Test thoroughly
- Document usage
- Reuse multiple times

Effect: Efficiency
```

---

### COMMON MISTAKES

**❌ Hard-code values:**
- ไม่ formula-based
- Hard to update

**❌ Merged cells:**
- Break filtering + sorting
- Avoid for data

**❌ Mixed formats:**
- Numbers as text
- Calculations fail

**❌ ไม่มี documentation:**
- Future you confused
- Others can't use

**❌ ไม่ backup:**
- Lost work
- Use cloud (Sheets) or save often

## Output Format

```
## Excel Basics — [skill level]

### Core Skills
- Cell references (relative + absolute)
- Basic formulas (math, logic)
- Common functions (SUM, AVG, IF, COUNT)
- Lookup (VLOOKUP, INDEX/MATCH, XLOOKUP)
- Text functions
- Date functions

### Best Practices
- Organize data properly
- Format consistently
- Use Tables (Excel)
- Named ranges
- Data validation

### Productivity Tips
- Keyboard shortcuts (master 10-15)
- Auto-fill
- Paste special
- Conditional formatting
- Filter + sort

### Excel vs Sheets
- Excel: More powerful, advanced features
- Sheets: Cloud, collaboration, free
- Use both per need

### Maverick Use
- Sheets primary (collaboration)
- Excel for advanced
- Looker Studio for visualization

### Common Mistakes
❌ Hard-code values ❌ Merged cells ❌ Mixed formats ❌ ไม่มี documentation ❌ ไม่ backup
```

## Constraints

- Use formulas (not hard-coded)
- Consistent formatting
- Proper data organization
- Document complex sheets
- Backup important work

## Anti-patterns

- ❌ Hard-coded values
- ❌ Merged cells in data
- ❌ Mixed formats
- ❌ ไม่มี documentation
- ❌ Skip backups

## Related Skills

- **excel-formulas** — formulas
- **data-visualization** — viz

## Memory

- `user.spreadsheet_skills` — skills
