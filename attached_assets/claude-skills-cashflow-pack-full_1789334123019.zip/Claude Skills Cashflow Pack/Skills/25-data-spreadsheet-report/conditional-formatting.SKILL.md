---
name: Conditional Formatting
id: conditional-formatting
category: data
trigger:
  - "conditional formatting"
  - "highlight cells"
  - "color cells"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Conditional Formatting Specialist — เข้าใจว่า viz cells = quick insights → static = miss patterns

## Context

ผู้ใช้คือ Excel/Sheets user

## Triggers

- **"conditional formatting"** → CF

## Tools

Pure prompt — รับ data แล้ว design

## Task

1. **Common rules**
2. **Custom formulas**
3. **Best uses**
4. **Combine multiple**

## Examples

### COMMON RULES

**Highlight Cells Rules:**

```
Greater than:
- Cell value > X = format

Less than:
- Cell value < X = format

Between:
- X ≤ value ≤ Y

Equal to:
- Specific value match

Text contains:
- Specific text inside

Date occurring:
- Today, this week, etc.

Duplicates:
- Highlight duplicates

Effect: Common conditions
```

—————————

**Top/Bottom Rules:**

```
- Top 10 items
- Top 10%
- Bottom 10 items
- Bottom 10%
- Above average
- Below average

Use:
- Identify outliers
- Top performers
- Bottom performers

Effect: Quick identification
```

—————————

**Data Bars:**

```
Visual bars in cells:
- Length = value
- Color shows magnitude
- ไม่มี hide value

Use:
- Quick visual comparison
- Magnitude visible
- ไม่ need separate chart

Effect: In-cell visualization
```

—————————

**Color Scales:**

```
Gradient colors:
- 2-color: Min to Max
- 3-color: Min, Mid, Max
- Heat map style

Use:
- Performance ranking
- Magnitude visualization
- Pattern recognition

Effect: Visual gradients
```

—————————

**Icon Sets:**

```
Icons per cell:
- Arrows (up/down/flat)
- Traffic lights (red/yellow/green)
- Stars (1-5)
- Various sets

Use:
- Status indicators
- Performance vs target
- Quick scan

Effect: Icon-based status
```

---

### CUSTOM FORMULAS

**Powerful Custom Rules:**

```
Use formula:
=A1>100
=A1=$B$1
=AND(A1>100, B1<50)
=COUNTIF($A$1:A1, A1)>1 (duplicates)
=A1=TODAY()
=WEEKDAY(A1)>5 (weekends)

Effect: Any condition
```

—————————

**Highlight Entire Row:**

```
Apply to entire row:
- Select rows
- Conditional formatting
- Use formula: =$A1="Active"
- Format applied entire row

$ on column = lock column
ไม่ on row = relative

Effect: Row-based highlighting
```

—————————

**Compare Columns:**

```
Highlight if differ:
=A1<>B1

Highlight if greater:
=A1>B1

Multiple conditions:
=AND(A1>B1, C1="Active")

Effect: Comparison views
```

---

### BEST USES

**KPI Dashboard:**

```
Status indicators:
- Above target: Green
- Below 90% target: Red
- Between: Yellow

Implementation:
- Cell with %
- Conditional format colors
- Quick visual status

Effect: Dashboard-style
```

—————————

**Variance Analysis:**

```
Actual vs Budget:
- > 105% of budget: Red (overspend)
- 95-105%: Green (on track)
- < 95%: Yellow (under-spend?)

Color rule:
- Calculate %
- Conditional format

Effect: Quick variance scan
```

—————————

**Aging Reports:**

```
AR aging:
- < 30 days: Green
- 30-60 days: Yellow
- 60-90 days: Orange
- > 90 days: Red

Implementation:
- Calculate days
- Color scale or specific rules

Effect: Priority visible
```

—————————

**Pipeline Tracking:**

```
Sales pipeline:
- Prospect: Gray
- Qualified: Blue
- Proposal: Yellow
- Closed Won: Green
- Closed Lost: Red

Status formatting:
- Per status row
- Apply to entire row

Effect: Visual pipeline
```

—————————

**Project Status:**

```
Project rows:
- On track: Green
- At risk: Yellow
- Off track: Red
- Complete: Gray

Effect: Project dashboard
```

---

### MAVERICK USE CASES

**Customer Dashboard:**

```
Customer list:
- Tier 1 customers: Gold highlight
- High LTV: Color scale
- At-risk (low engagement): Red
- New customers: Highlight

Status icons:
- Health score 1-5 stars
- Trend arrows

Effect: Visual customer mgmt
```

—————————

**Financial Dashboard:**

```
Monthly metrics:
- Above target: Green check
- At target: Yellow check
- Below: Red X

Trend:
- Up arrow: Improving
- Down arrow: Declining
- Flat: Stable

Effect: Quick scan health
```

—————————

**Project Tracker:**

```
Tasks:
- Overdue: Red highlight
- Due today: Yellow
- Due this week: Light yellow
- Future: ไม่มี highlight
- Done: Green strikethrough

Effect: Priority visible
```

---

### MANAGE RULES

**Multiple Rules:**

```
- Multiple conditional formats per cell
- Order matters (priority)
- Stop if true option
- Manage Rules dialog

Effect: Complex rules
```

—————————

**Edit/Delete:**

```
Home → Conditional Formatting → Manage Rules:
- Edit existing
- Delete specific
- Reorder priority
- Apply to range

Effect: Maintain rules
```

—————————

**Copy Formatting:**

```
Format Painter:
- Click cell with format
- Click Format Painter
- Apply to other cells
- Conditional formats too

Effect: Spread quickly
```

—————————

**Clear Formatting:**

```
- Home → Clear → Clear Formats
- Or specific conditional clear

Effect: Reset
```

---

### COMMON MISTAKES

**❌ Over-format:**
- Everything colored
- ไม่มี contrast
- Visual chaos

**❌ Wrong references:**
- $ in wrong place
- Format wrong cells

**❌ Performance issues:**
- Too many rules
- Slow large data
- Reduce if needed

**❌ Color blindness:**
- Red/green only
- Add icons or patterns
- Accessible

**❌ ไม่ document:**
- Forget what rules mean
- Confusing later

## Output Format

```
## Conditional Formatting — [use case]

### Common Rules
- Highlight cells (>, <, between, equal, contains)
- Top/bottom (top 10, top 10%)
- Data bars (in-cell visual)
- Color scales (gradient)
- Icon sets (status icons)

### Custom Formulas
=A1>100, =A1=TODAY(), AND/OR conditions
- Highlight rows: =$A1="Active"
- Compare: =A1<>B1

### Best Uses
- KPI dashboards (status)
- Variance analysis (% colors)
- Aging reports (priority)
- Pipeline tracking (status)
- Project status (RAG)

### Maverick Examples
- Customer dashboard (tier, LTV, risk)
- Financial dashboard (above/below target)
- Project tracker (overdue/due colors)

### Manage Rules
- Multiple per cell
- Order matters
- Edit/delete in Manage Rules
- Format Painter to spread

### Common Mistakes
❌ Over-format ❌ Wrong references ❌ Performance issues ❌ Color blind not considered ❌ ไม่ document
```

## Constraints

- Use sparingly (don't over-format)
- Specific conditions
- Color blind-friendly
- Document rules
- Test on real data

## Anti-patterns

- ❌ Format everything
- ❌ Wrong $ references
- ❌ Too many rules (slow)
- ❌ Red/green only
- ❌ ไม่มี documentation

## Related Skills

- **excel-basics** — basics
- **data-visualization** — viz

## Memory

- `user.conditional_formatting` — CF
