---
name: Google Sheets Tips
id: google-sheets-tips
category: data
trigger:
  - "google sheets"
  - "sheets tips"
  - "sheets formulas"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Google Sheets Specialist — เข้าใจว่า Sheets = collaborative power → master = team productivity

## Context

ผู้ใช้คือ Sheets user

## Triggers

- **"google sheets"** → Sheets

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **Sheets-specific features**
2. **Collaboration**
3. **Automation**
4. **Tips**

## Examples

### SHEETS-SPECIFIC FEATURES

**Real-Time Collaboration:**

```
- Multiple users edit same time
- See cursors of others
- Auto-save
- Version history
- Comments + suggestions

Effect: Team work
```

—————————

**Sheets-Only Functions:**

```
=GOOGLEFINANCE("AAPL", "price")
- Real-time stock prices

=GOOGLETRANSLATE("Hello", "en", "th")
- Translate text

=IMPORTRANGE("URL", "Sheet!Range")
- Pull from another sheet

=IMPORTHTML("URL", "table", 1)
- Pull HTML tables

=IMPORTDATA("URL")
- Pull CSV from URL

=IMPORTXML("URL", "xpath")
- Pull XML data

=ARRAYFORMULA(A:A * B:B)
- Apply formula to entire array

Effect: Web-connected
```

—————————

**Smart Fill (AI):**

```
Type pattern:
- "John Smith" → "JS"
- "Jane Doe" → "JD"

Sheets suggests fill for rest
Press Enter to accept

Effect: Auto-pattern
```

—————————

**Explore (AI Insights):**

```
Bottom-right corner:
- Auto-suggested charts
- Quick stats
- Pivot recommendations
- Q&A about data

Effect: Quick insights
```

---

### COLLABORATION

**Sharing:**

```
Share with:
- Specific people (email)
- Anyone with link
- Public

Permissions:
- Viewer (read only)
- Commenter (read + comment)
- Editor (full)

Effect: Right access
```

—————————

**Comments:**

```
- Highlight cell → Comment
- @ mention people
- Discussion threads
- Resolve when done

Effect: Discussion in context
```

—————————

**Suggestions Mode:**

```
Like Word's track changes:
- Suggest edits
- Owner approves/rejects
- ไม่ direct edit

Effect: Review process
```

—————————

**Notifications:**

```
Get notified:
- Comments
- Edits
- Specific changes
- Set rules

Effect: Stay updated
```

—————————

**Version History:**

```
File → Version history:
- All changes tracked
- Restore previous
- Name versions
- See who changed what

Effect: Recover from mistakes
```

---

### AUTOMATION

**Apps Script:**

```
Built-in JavaScript:
- Custom functions
- Auto-actions on triggers
- Connect to APIs
- Workflow automation

Use cases:
- Email when condition met
- Auto-format
- Custom calculations
- API integrations

Effect: Powerful automation
```

—————————

**Scheduled Functions:**

```
Auto-run:
- Daily reports
- Data refresh
- Email summaries
- Backups

Set up:
- Apps Script triggers
- Time-based or event-based

Effect: Set + forget
```

—————————

**Macros:**

```
Record actions:
- Tools → Macros → Record
- Replay anytime
- Edit in Apps Script

Effect: Repetitive tasks
```

—————————

**Add-Ons:**

```
Marketplace:
- Many useful tools
- Some free, some paid
- Specific use cases:
  - Mail Merge
  - Form responses
  - Translations
  - Reports

Effect: Extended capabilities
```

---

### TIPS + TRICKS

**Tip 1: Quick Sum**

```
Select cells → bottom right:
- Sum, average, count auto-shown
- Quick check without formula

Effect: Fast
```

—————————

**Tip 2: Filter Views**

```
Multiple users:
- Each has own filter view
- Not affect others
- Save views

Effect: Personalized
```

—————————

**Tip 3: Conditional Formatting**

```
- Highlight based on rules
- Color scales
- Custom formulas
- Multiple rules per range

Effect: Visual data
```

—————————

**Tip 4: Data Validation**

```
- Dropdown lists
- Number ranges
- Specific text
- Custom rules

Effect: Clean data input
```

—————————

**Tip 5: Protect Ranges**

```
- Specific people can edit
- Lock formula cells
- Allow data input only
- Prevent accidental changes

Effect: Safer sheets
```

—————————

**Tip 6: Named Ranges**

```
- "TaxRate" instead of "Settings!B5"
- Easier to read formulas
- Maintain easier

Effect: Cleaner
```

—————————

**Tip 7: Data Connections**

```
- Connect to BigQuery
- Connect to other Sheets
- Connect to databases (some)

Effect: Live data
```

—————————

**Tip 8: Templates Gallery**

```
- Pre-built templates
- Many use cases
- Customize for needs
- Save time

Effect: Quick start
```

—————————

**Tip 9: Mobile App**

```
- View on go
- Quick edits
- Limited functionality
- Better for desktop

Effect: Anywhere access
```

—————————

**Tip 10: Keyboard Shortcuts**

```
Cmd/Ctrl+/: All shortcuts
Cmd/Ctrl+A: Select all
Cmd/Ctrl+Shift+V: Paste values
Cmd/Ctrl+Shift+Z: Redo

Effect: Speed
```

---

### MAVERICK SHEETS USE

**Common Sheets:**

```
- KPI dashboard (live)
- Financial tracker
- Customer database
- Project tracker
- Content calendar
- Team OKRs

All:
- Shared with team
- Real-time updates
- Comments enabled
- Mobile accessible

Effect: Team alignment
```

—————————

**Apps Script Examples:**

```
Auto-emails:
- Daily KPI summary to founder
- Weekly team report
- Monthly customer overview

Effect: Automated reporting
```

---

### COMMON SHEETS MISTAKES

**❌ Treat like Excel:**
- Miss collaborative features
- Ignore Sheets-specific functions

**❌ ไม่ use comments:**
- Communication outside sheet
- Lost context

**❌ Wrong permissions:**
- Edit when should be view
- Or view when should edit

**❌ ไม่ version history:**
- Mistakes irrecoverable

**❌ ไม่ explore Apps Script:**
- Manual repetitive tasks

## Output Format

```
## Google Sheets Tips — [skill level]

### Sheets-Specific
- Real-time collaboration
- Sheets-only functions (GOOGLEFINANCE, IMPORTRANGE)
- Smart Fill (AI)
- Explore (insights)

### Collaboration
- Sharing (Viewer/Commenter/Editor)
- Comments (@ mentions)
- Suggestions mode
- Notifications
- Version history

### Automation
- Apps Script (JavaScript)
- Scheduled functions
- Macros (record actions)
- Add-Ons (marketplace)

### 10 Tips
1. Quick sum (bottom right)
2. Filter views (personal)
3. Conditional formatting
4. Data validation
5. Protect ranges
6. Named ranges
7. Data connections
8. Templates gallery
9. Mobile app
10. Keyboard shortcuts

### Maverick Use
- KPI dashboard
- Financial tracker
- Customer DB
- Apps Script automations

### Common Mistakes
❌ Treat like Excel ❌ ไม่ comments ❌ Wrong permissions ❌ ไม่ version history ❌ Skip Apps Script
```

## Constraints

- Use collaborative features
- Set right permissions
- Explore Sheets-specific
- Apps Script for automation
- Mobile-friendly setup

## Anti-patterns

- ❌ Excel-only mindset
- ❌ Skip comments/discussion
- ❌ Wrong permission levels
- ❌ Manual repetitive tasks
- ❌ Ignore Sheets features

## Related Skills

- **excel-basics** — basics
- **data-visualization** — viz

## Memory

- `user.sheets_tips` — tips
