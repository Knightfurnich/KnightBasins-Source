---
name: Database Functions
id: database-functions
category: data
trigger:
  - "database functions"
  - "dsum dcount"
  - "filter unique"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Database Function Specialist — เข้าใจว่า D-functions + dynamic arrays = power query without leaving Excel

## Context

ผู้ใช้คือ data analyst

## Triggers

- **"database function"** → D-functions
- **"dynamic array"** → SORT, FILTER, UNIQUE

## Tools

Pure prompt — รับ data แล้ว design query

## Task

1. **D-functions**
2. **Dynamic arrays**
3. **Combine for analysis**
4. **Best practices**

## Examples

### D-FUNCTIONS

**Syntax:**

```
=DFUNCTION(database, field, criteria)

- database: Range with headers
- field: Column to operate on
- criteria: Range with criteria

Functions:
- DSUM, DAVERAGE, DCOUNT
- DMAX, DMIN, DPRODUCT
- DGET (single value)
- DCOUNTA, DSTDEV, DVAR

Effect: SQL-like queries
```

—————————

**Maverick Example:**

```
Database: Sales table A1:F1000
Headers: Date, Region, Product, Qty, Price, Total

Criteria range:
A20: Region    Product
A21: BKK       Vitamin C

DSUM:
=DSUM(A1:F1000, "Total", A20:B21)

Result: Total revenue from
BKK + Vitamin C combinations

Effect: Filtered aggregation
```

—————————

**Multi-Criteria:**

```
Criteria range:
        Region    Product       Date
Row 21: BKK       Vitamin C     >=2026/1/1
Row 22: CNX       Niacinamide   >=2026/1/1

DSUM totals BOTH conditions

Effect: Complex queries
```

---

### DYNAMIC ARRAYS

**FILTER Function:**

```
=FILTER(data, condition)

Examples:
=FILTER(A2:F100, B2:B100="BKK")

Returns:
- All BKK rows
- Spills automatically
- Updates when data changes

Effect: Dynamic filter
```

—————————

**UNIQUE Function:**

```
=UNIQUE(range)

Examples:
=UNIQUE(B2:B1000)
- Unique customers list

=UNIQUE(B2:C1000)
- Unique combinations

=SORT(UNIQUE(B2:B1000))
- Sorted unique list

Effect: Dedupe
```

—————————

**SORT Function:**

```
=SORT(array, [sort_index], [order])

Examples:
=SORT(A2:F100, 6, -1)
- Sort by column 6 descending

=SORTBY(A2:F100, F2:F100, -1)
- Sort by external array

Effect: Dynamic sort
```

—————————

**SEQUENCE Function:**

```
=SEQUENCE(rows, [columns], [start], [step])

Examples:
=SEQUENCE(12) → 1,2,3...12
=SEQUENCE(12,1,2026,0) → 12 rows of 2026

Use:
- Generate dates
- Numbering
- Calculations

Effect: Auto-generate
```

—————————

**TEXTSPLIT, TEXTJOIN:**

```
TEXTSPLIT:
=TEXTSPLIT(A1, ",")
- Split string to array

TEXTJOIN:
=TEXTJOIN(", ", TRUE, A1:A10)
- Combine to string

Effect: Text manipulation
```

---

### COMBINE FOR ANALYSIS

**Top N Customers:**

```
=SORT(
  FILTER(Customers, Revenue>0),
  3, -1)

Then take top 10:
=INDEX(
  SORT(FILTER(...)),
  SEQUENCE(10), {1,2,3})

Effect: Top performers
```

—————————

**Unique Customers per Region:**

```
=COUNTA(
  UNIQUE(
    FILTER(B2:B1000, A2:A1000="BKK")
  )
)

Result: Unique BKK customers

Effect: Distinct count
```

—————————

**Maverick Dashboard Logic:**

```
Active customers list:
=SORT(UNIQUE(FILTER(Customers,
  LastOrderDate>=TODAY()-90)))

Total revenue:
=SUM(FILTER(Sales[Total], 
  Sales[Date]>=DATE(2026,1,1)))

Top product:
=INDEX(
  Products, 
  MATCH(MAX(Revenue), Revenue, 0)
)

Effect: Live dashboard
```

---

### CRITERIA SYNTAX

**Comparison:**

```
=, >, <, >=, <=, <>

Examples:
- "BKK" (exact match)
- ">100" (greater than)
- ">=2026/1/1" (date)
- "<>0" (not zero)

Effect: Filter logic
```

—————————

**Wildcards:**

```
* (any chars)
? (single char)

Examples:
- "BK*" (starts with BK)
- "*Skin*" (contains Skin)
- "????" (4 chars exact)

Effect: Pattern matching
```

—————————

**Multiple Conditions:**

```
AND (same row):
Region    Product
BKK       Vitamin*

OR (different rows):
Region
BKK
CNX

Effect: Logical OR/AND
```

---

### COMPARING APPROACHES

**Task: Sum BKK Vitamin C 2026 sales**

—————————

**SUMIFS:**

```
=SUMIFS(F:F, A:A, "BKK", 
  C:C, "Vitamin C",
  B:B, ">="&DATE(2026,1,1))

Pros: Common, familiar
Cons: Hard to read with many criteria
```

—————————

**DSUM:**

```
=DSUM(database, "Total", criteria)

Where criteria range = small table
With Region, Product, Date headers

Pros: Reusable criteria
Cons: Need extra range
```

—————————

**FILTER + SUM:**

```
=SUM(FILTER(F2:F1000,
  (A2:A1000="BKK")*
  (C2:C1000="Vitamin C")*
  (B2:B1000>=DATE(2026,1,1))))

Pros: Most flexible
Cons: 365+ only
```

---

### MAVERICK USE CASES

**Customer Lookup Page:**

```
Input cell: Customer name
=FILTER(AllOrders,
  AllOrders[Customer]=A1)

Returns: All orders for that customer
- Auto-spills
- Updates instantly

Effect: Interactive lookup
```

—————————

**Top Products Live:**

```
=SORT(
  CHOOSE({1,2},
    UNIQUE(Products),
    SUMIF(Sales, Products, Total)
  ),
  2, -1
)

Returns: Products by revenue
- Always current
- Top performers visible

Effect: Auto-ranking
```

—————————

**Sales by Date Range:**

```
Input: Start date (B1), End date (B2)

=SUMIFS(Total, Date, ">="&B1, Date, "<="&B2)

For breakdown:
=FILTER(Sales, (Date>=B1)*(Date<=B2))

Effect: Flexible reporting
```

---

### PRINCIPLES

**Principle 1: Modern > Legacy**

```
✅ Use 365 dynamic arrays
- FILTER, UNIQUE, SORT
- More powerful + flexible

ไม่: Old D-functions if 365 available

Effect: Best tool
```

—————————

**Principle 2: Spill Awareness**

```
✅ Plan for spilling
- Empty cells below
- ไม่ overwrite

Effect: Clean spill
```

—————————

**Principle 3: Tables**

```
✅ Use Excel Tables as source
- Auto-expand
- Structured references

Effect: Maintainable
```

—————————

**Principle 4: Combine Functions**

```
✅ Nest dynamic arrays
- SORT(FILTER(UNIQUE(...)))
- Powerful combinations

Effect: Complex queries
```

---

### COMMON MISTAKES

**❌ ไม่ใช้ dynamic arrays:**
- Stuck with old methods
- More complex formulas

**❌ Spill blocked:**
- #SPILL! error
- Clear cells below

**❌ Wrong criteria format:**
- Date format mismatches
- Text vs number

**❌ ไม่ใช้ tables:**
- Hard-coded ranges
- Break when data grows

**❌ Over-nesting:**
- Hard to debug
- Use helper columns

## Output Format

```
## Database Functions — [task]

### D-Functions
- DSUM, DAVERAGE, DCOUNT
- DMAX, DMIN, DGET
- Database + field + criteria

### Dynamic Arrays (365)
- FILTER (rows by condition)
- UNIQUE (dedupe)
- SORT / SORTBY
- SEQUENCE
- TEXTSPLIT / TEXTJOIN

### Comparison
- SUMIFS: Common, simple criteria
- DSUM: Reusable criteria range
- FILTER+SUM: Most flexible (365)

### Maverick Examples
- Customer lookup page
- Top products live
- Sales by date range
- Region/product analysis

### Principles (4)
1. Modern > legacy (365)
2. Spill awareness
3. Use tables
4. Combine functions

### Common Mistakes
❌ Old methods only ❌ Spill blocked ❌ Wrong criteria format ❌ ไม่ tables ❌ Over-nesting
```

## Constraints

- Use 365 dynamic arrays when available
- Plan for spill space
- Use tables as source
- Document complex formulas
- Test edge cases

## Anti-patterns

- ❌ Stuck with legacy methods
- ❌ Block spill cells
- ❌ Hard-coded ranges
- ❌ Mismatched criteria types
- ❌ Over-nested formulas

## Related Skills

- **lookup-functions** — lookups
- **excel-formulas** — formulas

## Memory

- `user.database_functions` — D-funcs
