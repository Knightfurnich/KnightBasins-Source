---
name: Excel Formulas
id: excel-formulas
category: data
trigger:
  - "excel formulas"
  - "advanced formulas"
  - "complex formulas"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Excel Formula Specialist — เข้าใจว่า master formulas = master Excel → unlock data analysis

## Context

ผู้ใช้คือ Excel user

## Triggers

- **"formulas"** → formulas

## Tools

Pure prompt — รับ need แล้ว provide

## Task

1. **Advanced functions**
2. **Combine functions**
3. **Common scenarios**
4. **Debug formulas**

## Examples

### ADVANCED FUNCTIONS

**SUMIFS / COUNTIFS / AVERAGEIFS:**

```
SUMIFS:
=SUMIFS(C:C, A:A, "Maverick", B:B, ">100")
- Sum column C
- Where A = "Maverick" AND B > 100

COUNTIFS:
=COUNTIFS(A:A, "Active", B:B, "Bangkok")
- Count rows matching multiple conditions

AVERAGEIFS:
=AVERAGEIFS(C:C, A:A, "Q1", B:B, ">1000")

Effect: Conditional aggregation
```

—————————

**INDEX/MATCH (Power):**

```
=INDEX(return_range, MATCH(lookup, lookup_range, 0))

Two-way lookup:
=INDEX(B2:E10, MATCH(G1, A2:A10, 0), MATCH(H1, B1:E1, 0))
- Row matched by G1 in A
- Column matched by H1 in row 1

Better than VLOOKUP:
- Left or right lookup
- Faster on large data
- More flexible

Effect: Powerful lookups
```

—————————

**XLOOKUP (Modern):**

```
=XLOOKUP(lookup, lookup_range, return_range, [if_not_found], [match_mode], [search_mode])

Examples:
=XLOOKUP(A1, B:B, C:C) - basic
=XLOOKUP(A1, B:B, C:C, "Not found") - default
=XLOOKUP(A1, B:B, C:C, "", 1) - approximate match

Replaces VLOOKUP + INDEX/MATCH
Effect: Modern lookup
```

—————————

**IFERROR / IFNA:**

```
=IFERROR(formula, "Default")
- If error, show "Default"
- Catch #DIV/0!, #N/A, etc.

=IFNA(formula, "Not found")
- Specifically for #N/A
- VLOOKUP not found

Effect: Clean error handling
```

—————————

**IF Combined:**

```
Nested IF:
=IF(A1>100, "High", IF(A1>50, "Medium", "Low"))

IFS (modern):
=IFS(A1>100, "High", A1>50, "Medium", TRUE, "Low")
- Cleaner syntax
- No nesting

Effect: Multiple conditions
```

—————————

**SUMPRODUCT:**

```
=SUMPRODUCT(A1:A10, B1:B10)
- Multiplies each pair
- Then sums products
- Math: ฿qty × price

Or use as conditional sum:
=SUMPRODUCT((A:A="Maverick")*(B:B>100)*C:C)
- Powerful array formulas

Effect: Complex calculations
```

—————————

**Logical (AND, OR, NOT):**

```
=AND(A1>10, B1<100): Both true
=OR(A1>10, B1<100): Either true
=NOT(A1=10): Reverse

In IF:
=IF(AND(A1>10, B1<100), "Good", "Bad")

Effect: Complex conditions
```

—————————

**Statistical:**

```
=MEDIAN(A1:A10): Middle value
=MODE(A1:A10): Most common
=STDEV(A1:A10): Standard deviation
=PERCENTILE(A1:A10, 0.5): Specific percentile
=RANK(A1, A1:A10): Rank in list
=LARGE(A1:A10, 2): 2nd largest
=SMALL(A1:A10, 2): 2nd smallest

Effect: Statistical analysis
```

—————————

**Financial:**

```
=PMT(rate, nper, pv): Loan payment
=FV(rate, nper, pmt, pv): Future value
=PV(rate, nper, pmt, fv): Present value
=NPV(rate, range): Net present value
=IRR(range): Internal rate of return
=NPER(rate, pmt, pv, fv): Number of periods

Effect: Financial calculations
```

---

### COMBINE FUNCTIONS

**Lookup + Conditional:**

```
=IF(VLOOKUP(A1, B:D, 3, FALSE)>100, "High", "Low")

Effect: Logic + lookup
```

—————————

**Text Manipulation:**

```
=UPPER(LEFT(A1, FIND(" ", A1)-1))
- Get first word, uppercase

=TRIM(SUBSTITUTE(A1, "  ", " "))
- Clean double spaces

Effect: Complex text work
```

—————————

**Date Calculations:**

```
=NETWORKDAYS(A1, B1)
- Working days between dates
- Excludes weekends

=NETWORKDAYS.INTL(A1, B1, 1, holidays_range)
- Custom weekends + holidays

=EOMONTH(A1, 0): Last day of month
=WORKDAY(A1, 5): 5 working days from A1

Effect: Date intelligence
```

—————————

**Array Formulas:**

```
Excel 365:
=FILTER(B:B, A:A="Maverick")
- Returns all matching rows

=SORT(A:A, 1, -1)
- Sort descending

=UNIQUE(A:A)
- Remove duplicates

=SEQUENCE(10)
- Generate 1-10

=RANDARRAY(10, 1, 1, 100)
- Random numbers

Effect: Array operations
```

---

### COMMON SCENARIOS

**Sales Analysis:**

```
Total revenue this month:
=SUMIFS(B:B, A:A, ">="&DATE(2026,1,1), A:A, "<"&DATE(2026,2,1))

Top 5 customers:
=LARGE(C:C, ROW()-1) - in cells

Customer ranking:
=RANK(C2, C:C, 0)

Effect: Quick insights
```

—————————

**Variance Analysis:**

```
% Change YoY:
=(B2-A2)/A2

Variance from budget:
=B2-A2

Status indicator:
=IF(B2>A2*1.1, "🟢", IF(B2<A2*0.9, "🔴", "🟡"))

Effect: Performance tracking
```

—————————

**Customer Database:**

```
Find customer details:
=XLOOKUP(A1, customers!A:A, customers!B:B)

Count active customers:
=COUNTIFS(customers!C:C, "Active")

Average customer LTV:
=AVERAGEIFS(customers!D:D, customers!C:C, "Active")

Effect: Database management
```

—————————

**Project Tracking:**

```
Days to deadline:
=B2-TODAY()

Status based on date:
=IF(B2<TODAY(), "Overdue", IF(B2<TODAY()+7, "Due Soon", "On Track"))

Project completion %:
=COUNTIF(C:C, "Done")/COUNTA(C:C)

Effect: Project management
```

---

### DEBUG FORMULAS

**Error Codes:**

```
#DIV/0!: Division by zero
#N/A: Lookup ไม่ found
#NAME?: Bad function name
#NULL!: Wrong intersection
#NUM!: Number issue
#REF!: Bad reference
#VALUE!: Wrong type

Effect: Identify issues
```

—————————

**Formula Auditing:**

```
F9: Calculate selected portion
F2: Edit cell + see references
Ctrl+[ : Trace precedents
Ctrl+] : Trace dependents
Formula > Evaluate Formula

Effect: Step through
```

—————————

**Common Issues:**

```
Wrong reference type:
- $ for absolute, none for relative
- Adjust as needed

Mixed types:
- Numbers as text
- Use VALUE() to convert

Hidden spaces:
- TRIM() to clean
- LEN() to check

Wrong syntax:
- Check function help
- Comma vs semicolon (regional)

Effect: Fix common issues
```

—————————

**Debugging Process:**

```
1. Identify error type
2. Break formula into parts
3. Test each part
4. Find specific issue
5. Fix
6. Verify

Effect: Systematic
```

---

### MAVERICK USE CASES

**Financial Dashboard Formulas:**

```
Revenue YTD:
=SUMIFS(revenue!B:B, revenue!A:A, ">="&DATE(YEAR(TODAY()),1,1))

Margin per service:
=(SUMIFS(rev!B:B, rev!C:C, A2)-SUMIFS(cost!B:B, cost!C:C, A2))/SUMIFS(rev!B:B, rev!C:C, A2)

Top customer:
=INDEX(customers!A:A, MATCH(MAX(customers!C:C), customers!C:C, 0))

Effect: Real business value
```

—————————

**Cash Flow:**

```
Running balance:
=B2+SUMPRODUCT((C$2:C2)*(D$2:D2="In"))-SUMPRODUCT((C$2:C2)*(D$2:D2="Out"))

Days to runway:
=cashbalance/(monthly_burn/30)

Effect: Cash management
```

---

### FORMULA PRINCIPLES

**Principle 1: Start simple**

✅ Build incrementally
- Complex from start = errors

—————————

**Principle 2: Test thoroughly**

✅ Sample data check
- Trust but verify

—————————

**Principle 3: Document complex**

✅ Comments for tricky
- Future you confused

—————————

**Principle 4: Use named ranges**

✅ Readable formulas
- A1:Z100 confusing

—————————

**Principle 5: Error handling**

✅ IFERROR for cleanliness
- Errors look bad

---

### COMMON FORMULA MISTAKES

**❌ Hard-code values in formulas**
**❌ Wrong reference types ($)**
**❌ Mixed data types**
**❌ Over-nested IFs**
**❌ ไม่ test edge cases**

## Output Format

```
## Excel Formulas — [scenario]

### Advanced Functions
- SUMIFS, COUNTIFS, AVERAGEIFS
- INDEX/MATCH, XLOOKUP
- IFERROR, IFNA, IFS
- SUMPRODUCT
- AND, OR, NOT
- Statistical (MEDIAN, STDEV)
- Financial (PMT, NPV, IRR)

### Common Combinations
- Lookup + conditional
- Text manipulation
- Date calculations (NETWORKDAYS)
- Array formulas (FILTER, SORT, UNIQUE)

### Common Scenarios
- Sales analysis
- Variance analysis
- Customer database
- Project tracking

### Debug
- Error codes (#DIV/0, #N/A, etc.)
- F9 evaluate
- Trace precedents/dependents
- Systematic process

### Maverick Use
- Financial dashboards
- Cash flow
- Customer analysis
- Project tracking

### Principles (5)
1. Start simple
2. Test thoroughly
3. Document complex
4. Named ranges
5. Error handling

### Common Mistakes
❌ Hard-code values ❌ Wrong references ❌ Mixed types ❌ Over-nested ❌ ไม่ test edges
```

## Constraints

- Build incrementally
- Test thoroughly
- Document complex
- Use named ranges
- Handle errors

## Anti-patterns

- ❌ Hard-coded values
- ❌ Wrong reference types
- ❌ Mixed data types
- ❌ Over-nested IFs
- ❌ Untested formulas

## Related Skills

- **excel-basics** — basics
- **data-analysis** — analysis

## Memory

- `user.formulas` — formulas
