---
name: Spreadsheet Best Practices
id: spreadsheet-best-practices
category: data
trigger:
  - "spreadsheet best practices"
  - "excel standards"
  - "professional spreadsheet"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Spreadsheet Architect — เข้าใจว่า best practices = maintainable + scalable + auditable

## Context

ผู้ใช้คือ regular spreadsheet user

## Triggers

- **"best practices"** → standards
- **"professional"** → quality

## Tools

Pure prompt — รับ workbook แล้ว assess

## Task

1. **Structure principles**
2. **Formula best practices**
3. **Documentation**
4. **Avoid pitfalls**

## Examples

### STRUCTURE PRINCIPLES

**Separate Concerns:**

```
3 types of sheets:
1. Inputs (raw data, assumptions)
2. Calculations (formulas, intermediate)
3. Outputs (reports, dashboards)

ไม่ mix:
- Input next to formula
- Output mixed with raw

Effect: Clean architecture
```

—————————

**Maverick Workbook Design:**

```
Sheets:
1. README (instructions)
2. Inputs - Sales (raw data)
3. Inputs - Costs (raw data)
4. Inputs - Assumptions (variables)
5. Calc - Revenue (formulas)
6. Calc - Margin (formulas)
7. Output - Summary (report)
8. Output - Dashboard (visual)
9. Sensitivity (scenarios)
10. Source Notes (data origins)

Effect: Logical organization
```

—————————

**Color Coding:**

```
Standard:
- Blue text: Hard-coded inputs
- Black text: Formulas
- Green text: Links to other sheets
- Red text: Errors/warnings
- Yellow fill: Editable cells
- Gray fill: Locked/calculated

Effect: Visual clarity
```

—————————

**Naming Conventions:**

```
Sheets:
- Inputs prefix
- Calc prefix
- Output prefix
- Numbered (01, 02...)

Named ranges:
- TaxRate (clear)
- ไม่ "MyVariable1"

Tables:
- tblSales (prefix tbl)
- tblCustomers
- ไม่ "Table1" default

Effect: Self-documenting
```

---

### FORMULA BEST PRACTICES

**Build in Steps:**

```
Bad: One mega-formula
=IF(SUMIFS(...)>VLOOKUP(...),
INDEX(MATCH(...)),
SUMIF(...))

Good: Helper columns
- Step 1: SUMIFS result
- Step 2: VLOOKUP result
- Step 3: Compare
- Step 4: Final logic

Effect: Readable + debuggable
```

—————————

**Use Tables:**

```
Format as Table (Ctrl+T):
- Auto-expand
- Structured references
- Built-in features
- ไม่ break formulas

Reference:
=SUM(tblSales[Total])
- ไม่ A2:A1000

Effect: Robust
```

—————————

**Named Ranges:**

```
Define names:
- TaxRate (single cell)
- ProductList (range)
- BudgetMatrix (2D)

Use in formulas:
=Total * TaxRate
=VLOOKUP(B2, ProductList, 2, 0)

Effect: Clear meaning
```

—————————

**Avoid Volatile Functions:**

```
Volatile (recalc often):
- NOW(), TODAY()
- INDIRECT, OFFSET
- RAND, RANDBETWEEN

Use sparingly:
- Slow workbook
- Use only when needed

Effect: Performance
```

—————————

**Error Handling:**

```
Wrap in IFERROR:
=IFERROR(VLOOKUP(...), "Not Found")

ไม่:
- Leave #N/A everywhere
- Confusing for users

Effect: Clean output
```

---

### DOCUMENTATION

**README Sheet:**

```
First sheet:
- Purpose
- Author + date
- Last updated
- Key contacts
- How to use
- Sheets overview
- Important notes
- Version history

Effect: Onboard new users
```

—————————

**In-Sheet Notes:**

```
Per important cell:
- Right-click → New Note
- Or text in adjacent column
- Why this number?
- Source?
- Calculation method?

Effect: Future-proof
```

—————————

**Source Documentation:**

```
Sheet "Sources":
- For each input: where from
- "Sales: ERP export weekly"
- "Tax rate: gov website"
- "Forecasts: marketing team"

Effect: Audit trail
```

—————————

**Maverick Documentation:**

```
README content:
- "Maverick Skin 2026 Forecast"
- "Owner: CFO"
- "Updates: Monthly first Monday"
- "Contains: Revenue, costs, margin
   forecasts for 12 months"
- "Inputs: Sheets 2-4 (yellow cells)"
- "Calculations: Sheets 5-6 (locked)"
- "Outputs: Sheets 7-8 (presentation)"

Effect: Clear context
```

---

### AVOID PITFALLS

**❌ Hard-coded Numbers:**

```
Bad:
=Total * 0.07

Good:
=Total * TaxRate
(named range = 0.07)

Effect: Easy update
```

—————————

**❌ Magic Cells:**

```
Bad:
=A1+B5*C10
(why these cells?)

Good:
- Named ranges
- Labels nearby
- Comments

Effect: Understandable
```

—————————

**❌ Merged Cells:**

```
Avoid for data:
- Break formulas
- Sort issues
- Filter problems

Use:
- Center Across Selection (alignment)
- ไม่ true merge

Effect: Data integrity
```

—————————

**❌ Multiple Files:**

```
"Sales 2026 v2 FINAL FINAL.xlsx"

Use instead:
- One master file
- Cloud version history
- Named milestones

Effect: Single truth
```

—————————

**❌ ไม่มี Backup:**

```
Risk:
- Crashed file
- Accidental delete
- Corrupted

Use:
- Cloud auto-save
- Periodic local backup
- Archive year-end

Effect: Safe
```

---

### MAVERICK STANDARDS

**Workbook Standards:**

```
1. README first sheet
2. Color coded (input/formula/link)
3. Tables for all data ranges
4. Named ranges for constants
5. Helper columns over mega-formulas
6. IFERROR on lookups
7. Documentation per sheet
8. Source citations
9. Cloud-based (auto-save)
10. Version milestones marked

Effect: Professional quality
```

—————————

**Review Checklist:**

```
Before sharing:
- [ ] All sheets named clearly
- [ ] README updated
- [ ] No #REF!, #N/A errors
- [ ] Formulas explained
- [ ] Sources documented
- [ ] Permissions set
- [ ] Sample tested
- [ ] Print preview good

Effect: Quality control
```

---

### PERFORMANCE OPTIMIZATION

**Speed Issues:**

```
Common causes:
- Too much data (>100K rows)
- Volatile functions everywhere
- Whole column references (A:A)
- Complex array formulas
- Many external links

Fixes:
- Convert to table + filter
- Replace volatile
- Specific ranges
- Break into helpers
- Consolidate links

Effect: Snappy
```

—————————

**File Size:**

```
Reduce:
- Clear unused cells
- Compress images
- Remove old data (archive)
- Avoid format spam
- Save as .xlsb (binary)

Effect: Faster
```

---

### SECURITY + PRIVACY

**Sensitive Data:**

```
Personal info (PII):
- Encrypt workbook
- Limit access
- Mask in shares
- Comply PDPA (Thailand)

Financial:
- Lock formulas
- Hide reference sheets
- Audit trail

Effect: Compliant
```

---

### COMMON BEST-PRACTICE MISTAKES

**❌ Mix everything in one sheet**
**❌ Hard-code numbers in formulas**
**❌ ไม่ name ranges or tables**
**❌ Mega-formulas (one cell)**
**❌ ไม่ documentation**
**❌ Multiple file copies**
**❌ Merged cells in data**
**❌ ไม่มี error handling**

## Output Format

```
## Spreadsheet Best Practices — [scope]

### Structure
- Separate inputs/calc/output
- 3 sheet types
- Color coding
- Naming conventions

### Formula Best Practices
- Build in steps (helpers)
- Use tables (auto-expand)
- Named ranges
- Avoid volatile
- Error handling (IFERROR)

### Documentation
- README sheet
- In-cell notes
- Source citations
- Version history

### Avoid Pitfalls
- Hard-coded numbers
- Magic cells
- Merged cells
- Multiple file versions
- ไม่มี backup

### Maverick Standards (10)
1. README first
2. Color coded
3. Tables for data
4. Named ranges
5. Helper columns
6. IFERROR
7. Documentation
8. Source citations
9. Cloud-based
10. Versions marked

### Performance
- ไม่ whole column refs
- Reduce volatile
- Archive old data
- Compress images

### Common Mistakes
❌ Mix concerns ❌ Hard-coded ❌ ไม่ named ranges ❌ Mega-formulas ❌ ไม่ docs ❌ Multiple copies ❌ Merged cells ❌ ไม่ error handling
```

## Constraints

- Separate inputs/calc/output
- Use tables + named ranges
- Document everything
- Single source of truth
- Cloud-based versions

## Anti-patterns

- ❌ Mixed concerns
- ❌ Hard-coded values
- ❌ ไม่ documentation
- ❌ Multiple file versions
- ❌ Mega-formulas

## Related Skills

- **excel-basics** — basics
- **excel-formulas** — formulas

## Memory

- `user.spreadsheet_best_practices` — practices
