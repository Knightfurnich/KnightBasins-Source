---
name: Lookup Functions
id: lookup-functions
category: data
trigger:
  - "vlookup"
  - "lookup function"
  - "index match"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Lookup Specialist — เข้าใจว่า lookups = data joining → master = power user

## Context

ผู้ใช้คือ Excel/Sheets user

## Triggers

- **"lookup"** → lookup
- **"vlookup"** → VLOOKUP

## Tools

Pure prompt — รับ scenario แล้ว guide

## Task

1. **VLOOKUP basics**
2. **INDEX/MATCH (better)**
3. **XLOOKUP (best)**
4. **Common scenarios**

## Examples

### VLOOKUP BASICS

**Syntax:**

```
=VLOOKUP(lookup_value, table_array, col_index, [range_lookup])

Example:
=VLOOKUP("Maverick", A:E, 3, FALSE)
- Find "Maverick" in column A
- Return value from column 3 (column C)
- FALSE = exact match

Effect: Find related data
```

—————————

**Limitations:**

```
- Lookup column must be leftmost
- Can't lookup left
- Returns first match only
- ไม่มี exact column flexible (use number)
- Slower on large data

Effect: Limited
```

—————————

**Common Issues:**

```
#N/A: Not found
- Check spelling
- Check leading/trailing spaces
- Check data type (text vs number)
- Use IFERROR wrapper

Wrong column:
- Count from leftmost (1, not 0)
- Verify column index

Effect: Common mistakes
```

---

### INDEX/MATCH (Better)

**Syntax:**

```
=INDEX(return_range, MATCH(lookup, lookup_range, 0))

Example:
=INDEX(C:C, MATCH("Maverick", A:A, 0))
- MATCH finds row of "Maverick" in A
- INDEX returns value from column C

Effect: Same result as VLOOKUP
```

—————————

**Advantages over VLOOKUP:**

```
- Lookup any column (left/right)
- More flexible
- Faster on large data
- Easier to modify
- Two-way lookups possible

Effect: More powerful
```

—————————

**Two-Way Lookup:**

```
=INDEX(B2:E10, MATCH(G1, A2:A10, 0), MATCH(H1, B1:E1, 0))

- Row from MATCH G1 in column A
- Column from MATCH H1 in row 1
- Returns intersection

Use case:
- Pricing matrix (size × color)
- Performance grid (department × month)

Effect: Matrix lookups
```

—————————

**Examples:**

```
Find customer revenue:
=INDEX(B:B, MATCH(A1, customer_names, 0))

Find product price:
=INDEX(prices, MATCH(SKU, sku_list, 0))

Find department head:
=INDEX(heads, MATCH(department, dept_list, 0))

Effect: Various lookups
```

---

### XLOOKUP (Modern)

**Syntax:**

```
=XLOOKUP(lookup, lookup_range, return_range, [if_not_found], [match_mode], [search_mode])

Basic:
=XLOOKUP(A1, B:B, C:C)

With default:
=XLOOKUP(A1, B:B, C:C, "Not found")

Effect: Modern lookup
```

—————————

**Advantages:**

```
- Cleaner syntax (no nesting)
- Built-in error handling
- Lookup left or right
- Approximate match modes
- Search direction (top-down or bottom-up)
- Returns array (multiple cells)

Effect: Best of both worlds
```

—————————

**Examples:**

```
Find latest order:
=XLOOKUP(A1, customer_names, order_dates, "No orders", 0, -1)
- Search bottom-up = latest

Find next available:
=XLOOKUP(A1, dates, status, "Available", 0, 1)
- Search top-down = first

Multi-column return:
=XLOOKUP(A1, products, product_info)
- Returns multiple columns

Effect: Powerful + clean
```

—————————

**Availability:**

```
- Excel 365 + 2021
- Google Sheets ✅

ไม่มี:
- Excel 2019 or earlier
- Use INDEX/MATCH instead

Effect: Modern Excel
```

---

### COMMON SCENARIOS

**Customer Database:**

```
Master sheet:
- Customer ID | Name | Email | Phone | LTV

Lookup formulas:
=XLOOKUP(A1, customer_id, customer_name)
=XLOOKUP(A1, customer_id, customer_email)

Effect: Build views from master
```

—————————

**Product Catalog:**

```
Products: SKU | Name | Price | Category

Pricing lookup:
=XLOOKUP(B2, sku, price)

Category lookup:
=XLOOKUP(B2, sku, category)

Effect: Order processing
```

—————————

**Salary Lookup:**

```
Employees: ID | Name | Salary | Department

Find salary:
=XLOOKUP(A1, employee_id, salary)

Department head:
=XLOOKUP(department, dept_list, head)

Effect: HR queries
```

—————————

**Pricing Matrix:**

```
Sizes (rows) × Colors (columns) = price

=INDEX(price_matrix, MATCH(size, size_list, 0), MATCH(color, color_list, 0))

Effect: Multi-dimensional pricing
```

—————————

**Historical Data:**

```
Find price on specific date:
=INDEX(prices, MATCH(date, dates, 1))
- 1 = approximate (find largest <= date)

Effect: Time-based lookups
```

---

### MAVERICK USE CASES

**Customer Profitability:**

```
Customer master sheet:
- ID, Name, Tier, Account Manager

Project sheet:
- Project ID, Customer ID, Revenue, Cost

Lookup customer name:
=XLOOKUP(B2, customer_id, customer_name)

Lookup customer tier:
=XLOOKUP(B2, customer_id, customer_tier)

Effect: Build profitability per customer
```

—————————

**Project Reporting:**

```
Find latest status:
=XLOOKUP(A1, project_id, status, "ไม่มี", 0, -1)
- Bottom-up = latest

Find first kick-off:
=XLOOKUP(A1, project_id, start_date, "", 0, 1)
- Top-down = first

Effect: Status reports
```

—————————

**Financial Dashboard:**

```
Pull current month metrics:
=XLOOKUP(EOMONTH(TODAY(),0), month_dates, revenue)
=XLOOKUP(EOMONTH(TODAY(),0), month_dates, profit)

Effect: Auto-current data
```

---

### COMMON MISTAKES

**❌ Approximate match unintentional:**
- VLOOKUP without FALSE = approximate
- Wrong results
- Always specify FALSE/0

**❌ Insertions break VLOOKUP:**
- Insert column = wrong index
- Use INDEX/MATCH or XLOOKUP

**❌ ไม่มี error handling:**
- #N/A everywhere
- Wrap with IFERROR/IFNA

**❌ Slow with VLOOKUP:**
- Large data = slow
- Use INDEX/MATCH for speed

**❌ ไม่ understand match types:**
- 0 = exact, 1 = ascending, -1 = descending
- Use 0 unless approximate needed

## Output Format

```
## Lookup Functions — [scenario]

### 3 Main Functions
1. VLOOKUP (legacy, leftmost)
2. INDEX/MATCH (powerful, flexible)
3. XLOOKUP (modern, cleanest)

### VLOOKUP
=VLOOKUP(lookup, range, col_index, FALSE)
- Lookup column must be leftmost
- Limited but common

### INDEX/MATCH
=INDEX(return_range, MATCH(lookup, lookup_range, 0))
- More flexible
- Can lookup left
- Two-way matrix lookups

### XLOOKUP
=XLOOKUP(lookup, lookup_range, return_range, [if_not_found], [match_mode], [search_mode])
- Modern + clean
- Built-in error handling
- Search direction
- Return arrays

### Common Scenarios
- Customer database
- Product catalog
- Salary lookup
- Pricing matrix
- Historical data

### Maverick Use
- Customer profitability
- Project reporting
- Financial dashboards

### Common Mistakes
❌ Approximate unintentional ❌ Insertion breaks VLOOKUP ❌ ไม่มี error handling ❌ Slow VLOOKUP ❌ Match type confusion
```

## Constraints

- Use XLOOKUP if available
- INDEX/MATCH for older Excel
- Always specify exact match (0/FALSE)
- Wrap with IFERROR
- Test with edge cases

## Anti-patterns

- ❌ VLOOKUP without FALSE
- ❌ Hard-coded column index
- ❌ ไม่มี error handling
- ❌ VLOOKUP for large data
- ❌ Approximate by accident

## Related Skills

- **excel-formulas** — formulas
- **data-analysis** — analysis

## Memory

- `user.lookup_functions` — lookups
