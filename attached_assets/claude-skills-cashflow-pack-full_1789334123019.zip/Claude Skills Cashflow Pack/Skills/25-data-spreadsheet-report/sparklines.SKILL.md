---
name: Sparklines
id: sparklines
category: data
trigger:
  - "sparklines"
  - "in-cell charts"
  - "mini charts"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Sparkline Specialist — เข้าใจว่า sparkline = trend at-a-glance → dashboard powerful

## Context

ผู้ใช้คือ dashboard creator

## Triggers

- **"sparkline"** → mini chart
- **"in-cell"** → cell-level

## Tools

Pure prompt — รับ data แล้ว design

## Task

1. **Sparkline types**
2. **Create + customize**
3. **Use in dashboards**
4. **Best practices**

## Examples

### SPARKLINE TYPES

**Line Sparkline:**

```
Use:
- Trend over time
- Continuous data
- Compare patterns

Show:
- Direction (up/down)
- Volatility
- Recent vs historical

Maverick example:
- Monthly revenue
- Weekly sales by product
- Daily traffic

Effect: Trend visible
```

—————————

**Column Sparkline:**

```
Use:
- Discrete comparisons
- Bar-style trends
- Magnitude focus

Show:
- Relative size
- Period values

Maverick example:
- Quarterly KPIs
- Daily counts
- Weekly orders

Effect: Comparison view
```

—————————

**Win/Loss Sparkline:**

```
Use:
- Binary outcomes
- Positive vs negative
- Streak patterns

Show:
- Up bars (positive)
- Down bars (negative)

Maverick example:
- Daily profit/loss
- Goal hit/miss
- Win/lose streaks

Effect: Binary trends
```

---

### CREATE SPARKLINES

**Process:**

```
1. Select destination cell
2. Insert tab → Sparklines
3. Choose type (Line/Column/Win-Loss)
4. Data Range: A1:L1 (12 months data)
5. Click OK

Effect: Mini chart in cell
```

—————————

**Multiple at Once:**

```
1. Select multiple destination cells
2. Insert sparkline
3. Data Range: A2:L10 (10 rows × 12 months)
4. Each row gets own sparkline

Effect: Quick batch
```

---

### CUSTOMIZE

**Color + Style:**

```
Sparkline Tools tab:
- Color (line/columns)
- Marker color
- Style presets

Effect: Branded look
```

—————————

**Show Markers:**

```
Highlight specific points:
- High point
- Low point
- First/Last
- Negative
- Markers (all)

Maverick: Show high + low + last
- Identify peak
- Identify trough
- Current state

Effect: Key data points
```

—————————

**Axis Settings:**

```
Vertical axis:
- Auto (per sparkline)
- Same for all (compare directly)

Horizontal axis:
- Show date axis
- General (default)

Tip: Use same scale for comparison

Effect: Fair comparison
```

—————————

**Show Empty Cells:**

```
Options:
- Gaps (blank space)
- Zero
- Connect with line

Effect: Handle missing data
```

---

### USE IN DASHBOARDS

**KPI Trend View:**

```
Layout:
| Metric        | Value | Trend    |
|---------------|-------|----------|
| Revenue       | ฿2.5M | sparkline|
| Customers     | 250   | sparkline|
| Avg Order     | ฿10K  | sparkline|
| Margin %      | 35%   | sparkline|

Effect: Compact KPI dashboard
```

—————————

**Maverick Monthly Dashboard:**

```
Big numbers (current):
- Revenue: ฿2.5M ↑
- Orders: 4,200 ↑
- AOV: ฿595 →
- CAC: ฿180 ↓

Sparklines (12 months trend):
- Each KPI: line sparkline
- High/low markers
- Quick visual context

Effect: Number + trend
```

---

### COMPARISON DASHBOARDS

**Product Performance:**

```
| Product       | Sales | Trend     |
|---------------|-------|-----------|
| Vitamin C     | ฿500K | sparkline |
| Niacinamide   | ฿420K | sparkline |
| Retinol       | ฿380K | sparkline |
| Hyaluronic    | ฿350K | sparkline |

Same scale across all:
- Visual comparison
- Spot trends
- Identify movers

Effect: Pattern recognition
```

—————————

**Region Performance:**

```
| Region | Q1   | Q2   | Q3   | Q4   | Trend |
|--------|------|------|------|------|-------|
| BKK    | 1.2M | 1.3M | 1.5M | 1.8M | spkl  |
| CNX    | 0.6M | 0.7M | 0.8M | 0.9M | spkl  |
| HKT    | 0.4M | 0.5M | 0.6M | 0.7M | spkl  |

All trending up - visible

Effect: Multi-region overview
```

---

### SPARKLINE PRINCIPLES

**Principle 1: Compact**

```
✅ One row in spreadsheet
- Fits dashboard
- ไม่ takes space

Effect: Dense info
```

—————————

**Principle 2: Comparable**

```
✅ Same scale
- When comparing
- Fair view

Effect: Apples to apples
```

—————————

**Principle 3: Highlight Key**

```
✅ Markers on important
- High/low points
- First/last
- Negatives

Effect: Quick insight
```

—————————

**Principle 4: ไม่ Replace Charts**

```
✅ Sparklines complement
- ไม่ replace full charts
- Pair with big numbers

Effect: Right tool
```

—————————

**Principle 5: Limited Series**

```
✅ One series per sparkline
- ไม่ multi-line
- Use full chart for that

Effect: Clear meaning
```

---

### COMMON SPARKLINE MISTAKES

**❌ Different scales:**
- Compare unfairly
- Misleading

**❌ Too small:**
- ไม่ readable
- Useless

**❌ Cluttered markers:**
- All markers shown
- Confusing

**❌ Wrong type:**
- Line for discrete
- Column for trend

**❌ Replace big chart:**
- Sparkline ไม่ enough detail
- Use full chart for analysis

## Output Format

```
## Sparklines — [purpose]

### Types
- Line (trends)
- Column (comparisons)
- Win/Loss (binary)

### Create
1. Select cell
2. Insert sparkline
3. Choose type
4. Set data range

### Customize
- Color/style
- Markers (high/low/last)
- Axis (same scale)
- Empty cells handling

### Dashboard Use
- KPI table with trends
- Product comparisons
- Regional views
- Compact + powerful

### Maverick Examples
- Monthly KPI trends
- Product performance
- Region comparison

### Principles (5)
1. Compact
2. Comparable
3. Highlight key
4. ไม่ replace charts
5. Limited series

### Common Mistakes
❌ Different scales ❌ Too small ❌ Cluttered ❌ Wrong type ❌ Replace big chart
```

## Constraints

- Same scale to compare
- Highlight key markers
- Pair with big numbers
- One series each
- Readable size

## Anti-patterns

- ❌ Different scales (unfair)
- ❌ Tiny sparklines
- ❌ All markers shown
- ❌ Wrong type
- ❌ Replace full charts

## Related Skills

- **dashboard-design** — dashboard
- **charts-graphs** — charts

## Memory

- `user.sparklines` — sparklines
