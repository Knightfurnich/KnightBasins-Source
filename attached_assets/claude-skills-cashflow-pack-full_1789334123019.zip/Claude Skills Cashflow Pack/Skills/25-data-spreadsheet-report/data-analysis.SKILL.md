---
name: Data Analysis
id: data-analysis
category: data
trigger:
  - "data analysis"
  - "analyze data"
  - "insights from data"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Data Analysis Specialist — เข้าใจว่า analysis = insights → drives decisions

## Context

ผู้ใช้คือ analyst

## Triggers

- **"analysis"** → analysis

## Tools

Pure prompt — รับ data + question แล้ว guide

## Task

1. **Analysis types**
2. **Common methods**
3. **Tools**
4. **Communicate findings**

## Examples

### ANALYSIS TYPES

**Descriptive:**

```
What happened?
- Summary statistics
- Trends
- Distributions
- Aggregations

Tools:
- Pivot tables
- Charts
- Dashboards

Effect: Understand past
```

—————————

**Diagnostic:**

```
Why did it happen?
- Root cause analysis
- Drill-down
- Comparisons
- Correlations

Methods:
- Five whys
- Pareto analysis
- Cohort analysis
- A/B testing

Effect: Explain past
```

—————————

**Predictive:**

```
What will happen?
- Forecasting
- Trend extrapolation
- Predictive models
- Statistical models

Tools:
- Excel forecasting
- Specialized software
- Machine learning

Effect: Anticipate future
```

—————————

**Prescriptive:**

```
What should we do?
- Optimization
- Recommendations
- Decision support
- Strategic guidance

Effect: Action-oriented
```

---

### COMMON METHODS

**Trend Analysis:**

```
Process:
1. Plot over time
2. Identify patterns
3. Calculate growth rates
4. Note inflection points
5. Project forward (cautiously)

Effect: Direction visible
```

—————————

**Cohort Analysis:**

```
Group by start date:
- Customer cohorts (signed up Jan, Feb, etc.)
- Track each cohort over time
- Compare performance

Use cases:
- Retention analysis
- Lifetime value
- Marketing channel comparison

Effect: Pattern recognition
```

—————————

**Pareto Analysis (80/20):**

```
80% of effects from 20% of causes:
- Top customers
- Best products
- Major issues

Process:
1. Sort by impact
2. Calculate cumulative %
3. Identify 80% point
4. Focus on top 20%

Effect: Strategic focus
```

—————————

**Variance Analysis:**

```
Compare actual vs:
- Budget
- Forecast
- Prior period
- Industry benchmark

For each significant variance:
- Investigate cause
- Document
- Action plan

Effect: Manage performance
```

—————————

**Correlation:**

```
Relationship between variables:
- =CORREL(A:A, B:B) = correlation
- 1: Perfect positive
- -1: Perfect negative
- 0: No correlation

Caution:
- Correlation ≠ causation
- Spurious correlations
- Confounding variables

Effect: Identify relationships
```

—————————

**A/B Testing:**

```
Compare two versions:
- Same conditions except 1 change
- Measure outcome
- Statistical significance
- Decide based on data

Effect: Data-driven decisions
```

—————————

**Funnel Analysis:**

```
Step-by-step conversion:
- Visitors → Leads
- Leads → Trials
- Trials → Customers
- Customers → Renewals

Identify:
- Drop-off points
- Optimization opportunities
- Conversion rates

Effect: Optimize process
```

—————————

**RFM Analysis (Customers):**

```
Segment customers by:
- Recency (last purchase)
- Frequency (purchase count)
- Monetary (total spent)

Identify:
- VIPs (high all 3)
- Loyal (high F)
- Lost (low R, was high)
- New (high R, low F)

Effect: Targeted marketing
```

---

### MAVERICK ANALYSIS EXAMPLES

**Customer Cohort:**

```
Year of acquisition cohorts:
- Y1 customers: Avg LTV ฿1.5M
- Y2 customers: Avg LTV ฿2M
- Y3 customers: Avg LTV ฿2.5M (TBD)

Insights:
- LTV increasing over time
- Better retention each cohort
- Acquisition quality improving

Effect: Track improvement
```

—————————

**Service Profitability (Pareto):**

```
4 service lines:
- Marketing strategy: ฿4M (27%)
- Performance ads: ฿6M (40%)
- Brand identity: ฿2M (13%)
- Course/community: ฿1.5M (10%)
- Other: ฿1.5M (10%)

80/20:
- Top 2 services = 67% revenue
- Focus on these
- Optimize remaining

Effect: Strategic focus
```

—————————

**Marketing ROI:**

```
By channel:
- Facebook Ads: ฿200K spend, ฿1M revenue, 5x ROAS
- TikTok Ads: ฿100K, ฿800K, 8x ROAS ⭐
- LinkedIn: ฿50K, ฿200K, 4x ROAS
- Content: ฿100K, ฿1.5M, 15x ROAS ⭐⭐

Insights:
- Content marketing top
- Scale TikTok investment
- Optimize LinkedIn or cut

Action: Reallocate budget
Effect: Higher returns
```

—————————

**Customer Churn:**

```
Pattern detected:
- Churn spike at month 6
- After major project completion
- Lack of follow-up

Root cause:
- ไม่มี post-project engagement
- Customer feels abandoned
- Move on

Action:
- 90-day follow-up program
- Account manager assigned
- Quarterly check-ins

Result: Churn reduced 50%
Effect: Higher retention
```

---

### TOOLS

**Spreadsheets:**

```
- Excel (powerful)
- Sheets (collaborative)
- Pivot tables
- Functions
- Built-in charts

Effect: Most needs
```

—————————

**Visualization:**

```
- Looker Studio (free)
- Tableau (powerful)
- Power BI (Microsoft)

Effect: Beautiful dashboards
```

—————————

**Statistical:**

```
- R (free, powerful)
- Python (pandas, scipy)
- SAS (enterprise)
- SPSS (enterprise)

Effect: Advanced analysis
```

—————————

**Specialized:**

```
- Mixpanel (product analytics)
- Amplitude (user behavior)
- Hotjar (UX analytics)
- Various per industry

Effect: Domain-specific
```

—————————

**Maverick Stack:**

```
- Excel/Sheets primary
- Looker Studio dashboards
- Notion documentation
- Cost: ฿0/month

Effect: Sufficient for SME
```

---

### COMMUNICATE FINDINGS

**Audience-Specific:**

```
For executives:
- Executive summary
- Key insights (3-5)
- Specific recommendations
- Visual + brief

For team:
- Detailed findings
- Methodology
- Implications
- Action items

Effect: Right message
```

—————————

**Storytelling:**

```
Structure:
- Setup (context)
- Conflict (problem identified)
- Resolution (insight + action)

Effect: Engaging
```

—————————

**Visualizations:**

```
- 1 chart per insight
- Clear titles
- Highlight key data
- Source noted
- Simple + clean

Effect: Quick comprehension
```

—————————

**Action-Oriented:**

```
Always end with:
- Specific actions
- Owner assigned
- Timeline
- Success metric

ไม่:
- Just data
- ไม่มี recommendations

Effect: Drives decisions
```

---

### ANALYSIS PRINCIPLES

**Principle 1: Question first**

✅ What want to know?
- Data without question = waste

—————————

**Principle 2: Clean data**

✅ Foundation
- Dirty = bad insights

—————————

**Principle 3: Multiple methods**

✅ Triangulate
- Single = limited

—————————

**Principle 4: Caveat results**

✅ Limitations stated
- Over-claim = trust loss

—————————

**Principle 5: Action-oriented**

✅ ไม่ just data
- Recommendations + actions

---

### COMMON ANALYSIS MISTAKES

**❌ Analysis without question:**
- Random data
- ไม่มี insights

**❌ Skip data quality:**
- Bad data → bad insights

**❌ Confirmation bias:**
- Look for what want
- Ignore contradicting

**❌ Correlation = causation:**
- Cor ≠ cause
- Mistakes

**❌ Over-claim:**
- "Definitely" / "Always"
- Trust lost when wrong

**❌ ไม่ act:**
- Analyze + ignore
- Wasted

## Output Format

```
## Data Analysis — [type]

### 4 Analysis Types
1. Descriptive (what happened)
2. Diagnostic (why)
3. Predictive (what will happen)
4. Prescriptive (what to do)

### Common Methods
- Trend analysis
- Cohort analysis
- Pareto (80/20)
- Variance analysis
- Correlation
- A/B testing
- Funnel analysis
- RFM analysis

### Maverick Examples
- Customer cohorts (LTV improving)
- Service Pareto (top 2 = 67%)
- Marketing ROI (content best)
- Churn patterns (post-project)

### Tools
- Spreadsheets primary
- Looker Studio dashboards
- Statistical (R, Python) advanced

### Communicate Findings
- Audience-specific
- Storytelling structure
- Visual + clean
- Action-oriented

### Principles (5)
1. Question first
2. Clean data
3. Multiple methods
4. Caveat results
5. Action-oriented

### Common Mistakes
❌ ไม่มี question ❌ Bad data ❌ Confirmation bias ❌ Cor = cause ❌ Over-claim ❌ ไม่ act
```

## Constraints

- Start with question
- Clean data first
- Multiple methods
- Action-oriented
- Communicate clearly

## Anti-patterns

- ❌ Random analysis
- ❌ Skip data quality
- ❌ Confirmation bias
- ❌ Confuse correlation/causation
- ❌ Analyze without action

## Related Skills

- **pivot-tables** — pivots
- **data-visualization** — viz

## Memory

- `user.data_analysis` — analysis
