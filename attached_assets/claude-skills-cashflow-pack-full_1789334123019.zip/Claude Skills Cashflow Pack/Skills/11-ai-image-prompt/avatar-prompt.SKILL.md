---
name: Avatar Prompt
id: avatar-prompt
category: ai-image
trigger:
  - "avatar prompt"
  - "profile picture ai"
  - "character avatar"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Avatar Designer — เข้าใจว่า avatar = personal brand visual — used in social profile, course platform, signature, business card

Avatar styles: Realistic photo, Cartoon illustration, 3D render, Pixel art, Minimal icon

## Context

ผู้ใช้คือ founder + creator ที่ต้องการ avatar

## Triggers

- **"profile picture"** → profile pic
- **"character design"** → character
- **"brand avatar"** → brand

## Tools

Pure prompt — รับ description + style แล้วเขียน avatar prompt

## Task

1. **Realistic photo avatar**
2. **Cartoon illustrated avatar**
3. **3D rendered avatar**
4. **Multi-platform consistency**

## Examples

### REALISTIC PHOTO AVATAR

```
/imagine prompt: Professional headshot avatar, 
Asian Thai male, 35 years old, 
short black hair, well-groomed beard, 
warm genuine smile with eye contact, 
wearing premium navy button-up, 
neutral background (subtle gradient), 
soft front lighting, 
shot at 85mm, 
photorealistic professional portrait, 
ultra-detailed, 8K 
--ar 1:1 --v 6 --s 100
```

---

### CARTOON ILLUSTRATED AVATAR

```
/imagine prompt: Cartoon avatar illustration, 
Asian male, 35, friendly smile, 
short hair, beard, glasses, 
wearing navy shirt, 
flat illustration style, 
clean lines, 
warm color palette (cream, navy, gold), 
modern character design, 
suitable for profile picture 
--ar 1:1 --v 6 --s 250
```

---

### 3D RENDERED AVATAR

```
/imagine prompt: 3D rendered avatar, 
Pixar-style stylized Asian male character, 
35 years old, friendly expression, 
short hair, beard, 
wearing modern outfit, 
soft 3D rendering, 
warm pastel colors, 
glossy material finish, 
high quality 3D character design 
--ar 1:1 --v 6 --s 300
```

---

### MINIMAL ICON AVATAR

```
/imagine prompt: Minimal icon avatar, 
geometric stylized "M" letterform, 
gold on deep navy background, 
clean simple lines, 
flat design icon, 
professional brand mark, 
suitable for various platforms 
--ar 1:1 --v 6 --s 100
```

---

### PIXEL ART AVATAR

```
/imagine prompt: Pixel art avatar, 
8-bit style Asian male character, 
short hair, friendly face, 
limited 16-color palette, 
retro gaming aesthetic, 
32x32 base resolution stylized, 
nostalgic profile picture 
--ar 1:1 --v 6 --s 250
```

---

### AVATAR STYLES COMPARISON

| Style | Use Case |
|-------|----------|
| Realistic photo | LinkedIn, professional, B2B |
| Cartoon illustration | Personal brand, creator, casual |
| 3D rendered | Modern, tech-forward, gaming |
| Pixel art | Niche, retro, gaming community |
| Minimal icon | Brand-only, no person needed |

---

### AVATAR CONSISTENCY (Multi-Platform)

**Same avatar everywhere:**
- LinkedIn
- Twitter / X
- Instagram
- Facebook
- YouTube
- Course platform
- Email signature
- Business card

**Why?**
- Brand recognition
- Personal brand consistency
- Easy identification
- Trust building

---

### AVATAR BACKGROUND OPTIONS

**Option 1: Plain Color**
- Solid brand color
- Clean simple
- Works small

**Option 2: Gradient**
- Subtle 2-color gradient
- Modern feel
- Visual interest

**Option 3: Studio**
- Neutral grey/cream
- Professional
- Photo-style

**Option 4: Brand Pattern**
- Subtle pattern
- Branded feel
- Less common

**Option 5: Transparent**
- For specific uses
- PNG format
- Versatile

---

### AVATAR SIZES (Platform Specs)

| Platform | Size |
|----------|------|
| LinkedIn | 400x400 |
| Twitter/X | 400x400 |
| Instagram | 320x320 |
| Facebook | 170x170 (rendered) |
| YouTube | 800x800 |
| Slack | 192x192 |
| GitHub | 460x460 |

**Master file:** 1024x1024 (downscale for each)

---

### COMMON AVATAR MISTAKES

**❌ Group photo as avatar:**
- Hard to identify
- Looks unprofessional

**❌ Selfie:**
- Casual feel
- Lower professional perception

**❌ Cropped weird:**
- Face cut off
- Or too zoomed out

**❌ Outdated photo:**
- 5+ year old photo
- Doesn't look like you

**❌ Different per platform:**
- Inconsistent
- Confuses identity

---

### AVATAR REFRESH FREQUENCY

**Update avatar:**
- Every 1-2 years
- Major personal change (haircut, age)
- Brand refresh
- New role / title

**Don't update too often:**
- Confuses recognition
- Inconsistent feel

---

### AVATAR USES

**Direct use:**
- Social profiles
- Course platform
- Slack / Discord
- Email signature

**Marketing use:**
- Author bio
- Speaker bio
- About page
- Press kit

**Variation:**
- Black/white version
- Brand color variants
- Larger version (poster)

---

### MAVERICK AVATAR TEMPLATE

```
/imagine prompt: Personal brand avatar, 
[STYLE - realistic photo/cartoon/3D/icon], 
[SUBJECT - Asian Thai male, 35, etc.], 
[EXPRESSION - confident smile], 
[OUTFIT - brand-aligned], 
[BACKGROUND - solid/gradient/pattern], 
[BRAND COLORS - navy + gold + cream], 
clean professional design, 
suitable for multi-platform use 
--ar 1:1 --v 6 --s [100-300 by style]
```

## Output Format

```
## Avatar Prompt — [style]

### Generated Prompts
- Realistic photo (1:1)
- Cartoon illustrated (1:1)
- 3D rendered (1:1)
- Pixel art (1:1)
- Minimal icon (1:1)

### Avatar Styles
| Style | Use Case |

### Multi-Platform Consistency
- Same avatar everywhere
- Recognition + trust

### Background Options
- Plain / Gradient / Studio / Pattern / Transparent

### Sizes by Platform
| Platform | Size |

### Refresh Frequency
- Every 1-2 years

### Common Mistakes
❌ Group photo ❌ Selfie ❌ Cropped weird ❌ Outdated ❌ Inconsistent

### Brand Template
[Maverick template]
```

## Constraints

- Same avatar across platforms
- 1:1 square aspect
- Recognizable at small size
- Brand-consistent
- Master file 1024x1024

## Anti-patterns

- ❌ Group photo as avatar
- ❌ Casual selfie
- ❌ Different per platform
- ❌ Outdated photo
- ❌ Hard to identify face

## Related Skills

- **portrait-prompt** — portrait
- **founder-photo-prompt** — founder
- **logo-design-prompt** — logo

## Memory

- `user.avatar` — current avatar
- `user.avatar_history` — previous
- `user.avatar_template` — template
