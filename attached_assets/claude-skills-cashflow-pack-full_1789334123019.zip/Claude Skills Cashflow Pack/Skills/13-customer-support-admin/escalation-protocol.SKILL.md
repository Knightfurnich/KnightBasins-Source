---
name: Escalation Protocol
id: escalation-protocol
category: customer-support
trigger:
  - "escalation protocol"
  - "escalate to manager"
  - "complex issue handling"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Customer Support Operations — เข้าใจว่า escalation = critical for complex issues — ไม่ escalate = damaged customer + brand

Escalation levels: L1 Admin → L2 Senior Admin/CS Lead → L3 Founder/Owner

## Context

ผู้ใช้คือ admin team

## Triggers

- **"escalate"** → escalate
- **"complex issue"** → complex
- **"manager required"** → manager

## Tools

Pure prompt — รับ situation แล้วเขียน protocol

## Task

1. **When to escalate**
2. **How to escalate**
3. **Escalation levels**
4. **Documentation**

## Examples

### ESCALATION DECISION TREE

```
Issue arrives
   ↓
Can L1 admin handle?
   ↓
Yes → Handle (90% of cases)
No → Escalate to L2
   ↓
Can L2 handle?
   ↓
Yes → Handle (8% of cases)
No → Escalate to L3 (Founder)
   ↓
L3 handles (2% critical)
```

---

### ESCALATION LEVELS

**LEVEL 1 (Admin / Customer Service Rep):**

**Handles:**
✅ FAQ questions
✅ Order tracking
✅ Standard refunds (within policy)
✅ Product education
✅ Simple complaints
✅ Promotion code applies
✅ Basic troubleshooting

**Authority:**
- Refund up to ฿1,000
- Voucher up to ฿200
- Standard responses
- Template-based fixes

---

**LEVEL 2 (Senior Admin / Customer Service Lead):**

**Handles (escalated from L1):**
✅ Refund > ฿1,000
✅ Repeat customer issues
✅ Quality complaints
✅ Difficult customers
✅ Custom situations
✅ Skin reaction (medical)
✅ Voucher > ฿200

**Authority:**
- Refund up to ฿5,000
- Voucher up to ฿1,000
- Free product replacement
- Make exceptions to policy
- Manager-level decisions

---

**LEVEL 3 (Founder / Owner):**

**Handles (escalated from L2):**
✅ Legal threats
✅ PR / reputation issues
✅ VIP customers
✅ Bulk orders / wholesale
✅ Press / media inquiry
✅ Influencer relationships
✅ Major refunds (> ฿5,000)
✅ Strategic decisions

**Authority:**
- Any refund/voucher
- Brand-level decisions
- Legal consultation
- Public relations
- Long-term strategy

---

### WHEN TO ESCALATE — DECISION FACTORS

**Escalate when:**

✅ Issue exceeds your authority limit
✅ Customer requests manager
✅ Legal / safety implications
✅ Public visibility (review, social media)
✅ VIP customer flagged
✅ Repeat issue with same customer
✅ Unusual situation outside templates
✅ You feel uncertain → safer to escalate

**Don't escalate when:**

❌ Customer is just rude (handle politely)
❌ Standard situation (use templates)
❌ Asking simple FAQ (educate)
❌ Quick fixable error (fix yourself)

---

### HOW TO ESCALATE

**Step 1: Acknowledge with customer**

```
"ขอโทษครับ คุณ [Name]
เรื่องนี้ผมต้อง consult กับทีมก่อน
ขอเวลา 1-2 ชั่วโมง — จะกลับมาภายในเวลานั้น

สามารถ DM เพิ่มข้อมูล:
- รายละเอียดเพิ่มเติม
- รูปประกอบ
- เลข order

ผมจะดูและแจ้งกลับ"
```

---

**Step 2: Document in escalation system**

**Required info:**

```
**ESCALATION REQUEST**

Date/Time: [Auto]
Submitted by: [Admin name]
Customer: [Name + contact]
Order #: [If applicable]

Issue Type:
[ ] Complaint
[ ] Refund > limit
[ ] Quality issue
[ ] Legal concern
[ ] PR concern
[ ] Custom request
[ ] Other: ___

Issue Description:
[Detailed summary]

What I tried:
- [Action 1]
- [Action 2]

Customer's request:
[What they want]

My recommendation:
[Suggested resolution]

Urgency:
[ ] Critical (1 hr)
[ ] High (4 hrs)
[ ] Standard (24 hrs)
```

---

**Step 3: Escalation channel**

**For urgent:**
- Slack DM to L2 Lead
- Phone call if critical
- LINE if Founder direct

**For standard:**
- Slack channel #escalations
- Email to manager
- Notion ticket

**For documentation:**
- Always write up case
- Save chat transcript
- Photo/screenshot evidence

---

**Step 4: Hand-off**

```
Hand-off message to L2:

"Hi [L2 Name],
Escalating Case #[X]:

Customer: [Name]
Issue: [Brief]
Urgency: [Level]
What I tried: [Actions]
Why escalating: [Reason]

Notion: [Link]
Chat: [Screenshot]
Order: [Link]"
```

---

**Step 5: Follow-up to customer**

```
"สวัสดีครับ คุณ [Name]

ขอ update — ทีมของเรากำลังดูแลเรื่องนี้
จะมีคน senior ติดต่อมาให้ภายใน [time]

ขอบคุณที่อดทน
— Admin"
```

---

### ESCALATION COMMUNICATION

**Internal communication tone:**
- Professional
- Neutral (don't bias L2)
- Factual (don't editorialize)
- Specific (clear ask)

**Customer-facing tone:**
- Apologetic
- Reassuring
- Non-blaming
- Solution-oriented

---

### URGENCY LEVELS

**🚨 CRITICAL (response < 1 hr):**
- Legal threat
- PR risk
- Safety issue (skin reaction severe)
- Major customer threatening public

**🔴 HIGH (response < 4 hrs):**
- VIP customer
- Refund > ฿5,000
- Quality complaint
- Negative public review

**🟡 STANDARD (response < 24 hrs):**
- Refund > ฿1,000
- Custom request
- Repeat issue

**🟢 LOW (response < 48 hrs):**
- General inquiry
- Long-term suggestion
- Non-urgent feedback

---

### COMMON ESCALATION SCENARIOS

**Scenario 1: Customer threatens legal action**
- Immediate L3 escalation
- Don't engage further
- Document everything
- Save all communications

**Scenario 2: Customer post negative review**
- L2 handles initially
- L3 if viral
- Public response + private DM
- Quick resolution

**Scenario 3: Customer wants ฿10,000 refund**
- Beyond L1 authority
- L2 reviews case
- L3 if exception needed
- Document reasoning

**Scenario 4: Skin reaction (medical)**
- L2 immediately
- L3 if severe
- Medical advice (don't give)
- Refund + apology
- Document for safety records

**Scenario 5: VIP customer angry**
- L2 priority
- L3 within 1 hour
- Personal touch
- Win back priority

---

### COMMON ESCALATION MISTAKES

**❌ Escalate too quickly:**
- "Talk to manager" reflexively
- Should try to handle first

**❌ Don't escalate enough:**
- Try to handle alone
- Make wrong decision
- Customer angry

**❌ ไม่มี documentation:**
- L2 has no context
- Repeat same questions
- Customer frustrated

**❌ ไม่ communicate to customer:**
- Customer waits silent
- Doesn't know happening

**❌ Slow internal escalation:**
- Sit on case
- Customer issue worsens

---

### TRACKING ESCALATIONS

**Metrics:**

- Total escalations / month
- Escalations by type
- L1 → L2 rate
- L2 → L3 rate
- Resolution time
- Customer satisfaction post-escalation

**Targets:**
- L1 handle: 90%+ of cases
- L2 handle: 8% of cases
- L3 handle: 2% of cases (mostly exceptions)
- Resolution within urgency SLA

**Use to:**
- Train L1 admins better
- Update FAQ
- Improve product
- Process improvements

## Output Format

```
## Escalation Protocol — [scenario]

### Escalation Levels
- L1 Admin (90% cases)
- L2 Senior/CS Lead (8% cases)
- L3 Founder (2% critical)

### Decision Factors
- When to escalate ✅
- When NOT to escalate ❌

### How to Escalate (5 Steps)
1. Acknowledge customer
2. Document case
3. Use channel (Slack/Email)
4. Hand-off message
5. Follow-up customer

### Urgency Levels
- Critical (<1h) / High (<4h) / Standard (<24h) / Low (<48h)

### Common Scenarios
- Legal / Negative review / Big refund / Skin reaction / VIP

### Tracking
- Metrics + targets

### Common Mistakes
❌ Too quickly ❌ Not enough ❌ No documentation ❌ No customer communication ❌ Slow internal
```

## Constraints

- Try L1 first (90% target)
- Document every escalation
- Communicate to customer
- Follow urgency SLAs
- Track metrics

## Anti-patterns

- ❌ Reflexive escalation
- ❌ ไม่ escalate when needed
- ❌ Skip documentation
- ❌ Silent to customer
- ❌ Slow internal handoff

## Related Skills

- **customer-support-sop** — SOP
- **complaint-handling-script** — complaint
- **negative-feedback-response** — feedback

## Memory

- `user.escalation_protocol` — protocol
- `user.escalation_log` — log
- `stats.escalation_metrics` — metrics
