---
name: Customer Survey Script
id: customer-survey-script
category: customer-support
trigger:
  - "customer survey script"
  - "feedback survey"
  - "nps survey"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Customer Insights Specialist — เข้าใจว่า survey = ฟัง customer voice → improve product + service + brand

Survey types: NPS, CSAT, Product feedback, Post-purchase, Annual

## Context

ผู้ใช้คือ admin + product team

## Triggers

- **"customer survey"** → survey
- **"NPS"** → NPS
- **"feedback collection"** → feedback

## Tools

Pure prompt — รับ survey goal แล้วเขียน script

## Task

1. **Survey types**
2. **Question design**
3. **Distribution**
4. **Analysis + action**

## Examples

### NPS SURVEY (Quarterly)

**Sent quarterly to all customers:**

```
Subject: 1 คำถาม — ขอเวลา 30 วินาที 🙏

สวัสดีครับ คุณ [Name]

แค่ 1 คำถาม:

🤔 จาก 0-10 คุณจะแนะนำ Maverick 
ให้เพื่อนผู้ชายมั้ย?

[0] [1] [2] [3] [4] [5] [6] [7] [8] [9] [10]
   Definitely not          Definitely yes

[After answer:]
"ทำไมให้คะแนนเท่านั้น?" 
[Open text answer]

ขอบคุณครับ — feedback ของคุณช่วยเราพัฒนา

— ครูเอ็ม
```

**NPS Categories:**
- 0-6: Detractors (improve quickly)
- 7-8: Passives (neutral, room to grow)
- 9-10: Promoters (advocates)

**NPS Score = % Promoters - % Detractors**

**Targets:**
- 70+: Excellent
- 50-70: Good
- 30-50: Average
- <30: Needs improvement

---

### CSAT SURVEY (Post-Purchase)

**Sent 14-30 days after purchase:**

```
Subject: ใช้ Maverick เป็นไงบ้างครับ? 30 วินาที

สวัสดีครับ คุณ [Name]

ผ่านไป 14 วัน หลังคุณซื้อ Maverick Reset
ขอ 30 วินาที feedback:

⭐ 1. คะแนนความพึงพอใจ (1-5):
[1] [2] [3] [4] [5]

⭐ 2. คุณเห็นผลแค่ไหน?
◯ เห็นผลชัดเจน (love it)
◯ เห็นผลบ้าง (working)
◯ ยังไม่เห็นผล (not yet)
◯ ผลไม่ดี (not happy)

⭐ 3. คุณจะซื้อซ้ำไหม?
◯ ใช่ แน่นอน
◯ อาจจะ
◯ ไม่

⭐ 4. มีอะไรที่อยากให้เราดีขึ้น?
[Open text]

ขอบคุณครับ! 🙏
+ Reward: ฿100 voucher next order

— ครูเอ็ม
```

---

### PRODUCT FEEDBACK SURVEY (Detailed)

**For specific product analysis:**

```
Subject: Maverick Reset Survey (5 mins)

สวัสดีครับ คุณ [Name]

ขอ 5 นาที — feedback ละเอียด
จะนำมา improve product + brand

Questions (10):

1. ใช้ Maverick มากี่สัปดาห์? 
   [1-2 / 3-4 / 5-8 / 8+]

2. ใช้กี่ครั้งต่อสัปดาห์?
   [Daily / 4-5x / 2-3x / Once]

3. ผลลัพธ์ที่เห็น (เลือกได้หลายข้อ):
   ◯ ผิวมันลดลง
   ◯ รูขุมขนเล็กลง
   ◯ สิวลดลง
   ◯ ผิวเรียบขึ้น
   ◯ ผิวสว่างขึ้น
   ◯ ยังไม่เห็นผล

4. คะแนนผลลัพธ์ 1-10:
   [Slider]

5. คะแนนเนื้อ texture 1-10:
   [Slider]

6. คะแนนกลิ่น 1-10:
   [Slider]

7. คะแนน packaging 1-10:
   [Slider]

8. คะแนนคุ้มค่า 1-10:
   [Slider]

9. ฺBest อะไรของ Maverick?
   [Open text]

10. ที่อยากให้ดีขึ้น?
    [Open text]

ขอบคุณ! 🙏
+ ฿200 voucher (สำหรับ feedback ละเอียด)

— ครูเอ็ม
```

---

### ANNUAL CUSTOMER SURVEY

**Sent end of year to all customers:**

```
Subject: 2026 ปีนี้กับ Maverick — ขอความเห็น

สวัสดีครับ คุณ [Name]

ปีนี้ Maverick + คุณ — เป็นไงบ้าง?

ขอ 5 นาที — ปรับปรุงปีหน้า:

1. โดยรวม ปีนี้ Maverick เป็นไง?
   [1-10 slider]

2. สินค้า:
   ◯ ดีมาก
   ◯ ดี
   ◯ ปานกลาง
   ◯ น้อย

3. Customer service:
   [1-10 slider]

4. Communication (LINE OA, email):
   ◯ มากเกินไป
   ◯ พอดี
   ◯ น้อยเกินไป

5. ราคา:
   ◯ คุ้มมาก
   ◯ พอเหมาะ
   ◯ แพงไป

6. Brand image:
   [1-10 slider]

7. ปีหน้าอยากเห็น Maverick ทำอะไร?
   [Open text]

8. ฯ มีอะไรที่อยากบอกผม?
   [Open text]

ขอบคุณ — feedback ทำให้เราดีขึ้น
+ ฿300 voucher (annual reward)

— ครูเอ็ม, Founder
```

---

### SHORT POLLS (LINE OA / Story)

**Quick 1-question polls:**

**Poll 1:** "Maverick Reset เห็นผลแล้วยัง?"
- ◯ เห็นผลแล้ว
- ◯ ยังไม่เห็น
- ◯ เพิ่งเริ่มใช้

**Poll 2:** "อยากเห็นสินค้าใหม่อะไร?"
- ◯ Cleanser
- ◯ Sunscreen
- ◯ Mask
- ◯ Body care

**Poll 3:** "วันไหนคุณอ่าน LINE OA?"
- ◯ Morning
- ◯ Lunch
- ◯ Evening
- ◯ Random

---

### SURVEY DESIGN PRINCIPLES

**1. Keep Short**
- 1-3 questions ideal
- 5-10 questions max
- Respect customer time

**2. Mix Question Types**
- Multiple choice (easy)
- Slider (1-10)
- Open text (insights)
- Yes/No (specific)

**3. Reward Participation**
- Voucher / Discount
- Increase response rate
- ฿50-300 typical

**4. Multi-Channel**
- Email (longer surveys)
- LINE OA (quick polls)
- Website pop-up
- In-product prompt

**5. Action on Feedback**
- Acknowledge
- Show what changed
- Close the loop

---

### RESPONSE RATES

**Typical benchmarks:**

| Survey Type | Response Rate |
|-------------|---------------|
| 1-question NPS | 30-50% |
| 5-question CSAT | 15-30% |
| 10-question detailed | 5-15% |
| Annual survey | 10-20% |
| LINE OA poll | 20-40% |

**Higher reward = higher response**

---

### ANALYSIS + ACTION

**Process feedback:**

**Step 1: Categorize**
- Positive themes
- Negative themes
- Suggestions
- Common patterns

**Step 2: Prioritize**
- High frequency issues
- High impact suggestions
- Quick wins
- Long-term changes

**Step 3: Act**
- Update product/process
- Improve communication
- Train team
- Adjust strategy

**Step 4: Close Loop**
- Tell customers what changed
- "Based on your feedback..."
- Build trust + loyalty

---

### COMMON SURVEY MISTAKES

**❌ Too long:**
- 30+ questions
- Low completion
- Bad data

**❌ Generic questions:**
- "How are you?"
- ไม่ specific

**❌ ไม่มี reward:**
- Low response rate
- Sample bias

**❌ ไม่ analyze:**
- Collect data, ไม่ใช้
- Waste effort

**❌ ไม่ act on feedback:**
- Customer gave time
- Nothing changes
- Trust eroded

## Output Format

```
## Customer Survey Script — [type]

### Survey Types
- NPS / CSAT / Product / Annual / Short polls

### Survey Examples
[Per type templates]

### Design Principles
1. Keep short (1-3 ideal)
2. Mix question types
3. Reward participation
4. Multi-channel
5. Action on feedback

### Response Rates Benchmarks
| Type | Rate |

### Analysis + Action
- Categorize / Prioritize / Act / Close loop

### Common Mistakes
❌ Too long ❌ Generic ❌ No reward ❌ No analyze ❌ No action
```

## Constraints

- Short surveys (1-10 questions)
- Reward participation
- Multi-channel
- Analyze + act on feedback
- Close loop with customers

## Anti-patterns

- ❌ 30+ question surveys
- ❌ Generic questions
- ❌ ไม่มี reward
- ❌ Collect data, no action
- ❌ ไม่ close loop

## Related Skills

- **client-feedback-digest** — digest
- **review-request-automation** — review
- **customer-support-sop** — SOP

## Memory

- `user.surveys` — surveys
- `user.feedback_data` — data
- `stats.nps_score` — NPS
