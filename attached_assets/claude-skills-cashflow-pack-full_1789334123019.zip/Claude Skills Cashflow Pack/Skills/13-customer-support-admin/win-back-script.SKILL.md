---
name: Win Back Script
id: win-back-script
category: customer-support
trigger:
  - "win back script"
  - "lost customer"
  - "reactivation message"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Customer Recovery Specialist — เข้าใจว่า lost customer recoverable — 30-50% can be won back ด้วย right approach

Win-back stages: Understand why → Address concerns → Re-offer → Show change

## Context

ผู้ใช้คือ admin + customer success team

## Triggers

- **"reactivate customer"** → reactivate
- **"lost customer"** → lost
- **"churned customer"** → churned

## Tools

Pure prompt — รับ customer history แล้วเขียน win-back

## Task

1. **Identify lost customer**
2. **Understand reason**
3. **Personalized outreach**
4. **Make offer**
5. **Track success**

## Examples

### WIN-BACK SCENARIOS

**Scenario 1: 30 Days Inactive (Soft Win-Back)**

**Trigger:** No purchase / engagement 30 days

**Outreach:**
```
สวัสดีครับ คุณ [Name]

หายไปนานเลยครับ 🙏
ครบ 30 วันแล้วที่ไม่ได้ติดต่อ

หวังว่าทุกอย่างยังดี

หากผิวยังโอเค — keep using Maverick ก็ได้
หากต้องการเปลี่ยน routine — DM ปรึกษา

🎁 สำหรับลูกค้าเก่า:
COMEBACK10 — 10% off (ใช้ได้ 7 วัน)

ไม่ใช้ก็ไม่เป็นไร
ผมยังนึกถึงคุณอยู่
— ครูเอ็ม
```

---

**Scenario 2: 60 Days Inactive (Direct Win-Back)**

**Outreach:**
```
สวัสดีครับ คุณ [Name]

2 เดือนแล้วที่หายไป

ขอเข้าใจ — มีเหตุผลอะไรไหมครับ?
- ผลไม่ตามคาดหวัง?
- ราคาแพงไป?
- เปลี่ยนยี่ห้อ?
- เลิกใช้สกินแคร์?
- อื่นๆ?

ตอบ DM กลับมา จะ help หา solution

🎁 Special offer:
COMEBACK20 — 20% off
+ Free Toner (ลองเพิ่ม)

ใช้ภายใน 7 วัน

— ครูเอ็ม
```

---

**Scenario 3: 90 Days + Refund History (Hard Win-Back)**

**Customer:** Refunded 60 days ago

**Outreach:**
```
สวัสดีครับ คุณ [Name]

3 เดือนที่แล้ว — คุณ refund Maverick
ผมเสียใจที่เกิดขึ้นแบบนั้น

อยากบอก:
ผม listen feedback ของคุณ
ผม improve product ตั้งแต่ตอนนั้น:

✅ Reformulated (less irritation)
✅ Better packaging
✅ Faster shipping
✅ Better customer service

🎁 Comeback offer:
- Try ใหม่ฟรี (free sample 5ml)
- หรือ 30% off ครั้งใหม่
- 60-day money back (ขยาย จาก 30)

ไม่บังคับ — ถ้าไม่อยากกลับ ผมเคารพ
แต่ถ้าอยากลอง — ผมยินดี

— ครูเอ็ม
```

---

**Scenario 4: Subscription Cancelled**

**Customer:** Cancelled subscription 3 months ago

**Outreach:**
```
สวัสดีครับ คุณ [Name]

3 เดือนตั้งแต่คุณ cancel subscription
ผิวยังดีอยู่ไหม?

หากของหมดแล้ว:
🎁 Reactivate offer:
- Subscribe ฿530/เดือน (lock-in price)
- + Free Toner (welcome back)
- + ฿100 voucher (next order)

หากยังมีของใช้:
ใช้ต่อสบาย — เก็บ offer ไว้ใช้ภายหลัง

🔁 Subscription benefits:
✅ Save ฿720/ปี
✅ Free shipping always
✅ Skip / cancel anytime
✅ Lock-in price

DM "Resubscribe" ถ้าสนใจ
— ครูเอ็ม
```

---

**Scenario 5: VIP Lost Customer**

**Customer:** Was VIP but inactive 6 months

**Outreach (personal, from founder):**
```
สวัสดีครับ คุณ [Name]

ผม [Founder name]

ดู records ของคุณ — เคย Maverick VIP customer
ซื้อกัน 8 ครั้งแล้ว

6 เดือนที่ผ่านมา — เงียบหายไป
ผมอยากเข้าใจ:

1. เกิดอะไรขึ้น?
2. มีอะไรที่ทำผิดไป?
3. ผมช่วยอะไรได้?

ในใจผม คุณยังเป็น Maverick VIP
ของขวัญพิเศษส่งให้:

🎁 [Limited edition product] — ฟรี
🎁 Personal video call (30 นาที)
🎁 Lifetime VIP status (ถ้ากลับมา)

DM ตอบ — ผม personal ดูแล
— [Founder name], Founder Maverick
```

---

### WIN-BACK SEGMENT STRATEGY

**Segment by:**

**Inactivity period:**
- 30 days: Soft (curious check-in)
- 60 days: Medium (direct ask)
- 90 days: Hard (last chance offer)
- 180+ days: Final (let go gracefully)

**Reason for leaving:**
- Refund: Address quality concern
- Cancelled subscription: New offer
- Just stopped: Curiosity probe
- Negative experience: Apology + win-back

**Customer value:**
- VIP / High LTV: Personal touch from founder
- Standard: Automated sequence + voucher
- Low value: Email blast acceptable

---

### WIN-BACK OFFER ESCALATION

**First outreach (30 days):**
- 10% off
- Soft tone

**Second (60 days):**
- 20% off
- Free product add
- Direct ask

**Third (90 days):**
- 30% off
- Free product full
- Founder personal note

**Fourth (180 days):**
- 40% off (last try)
- Free product + bonus
- "If you decline — no more outreach"

**Note:** Decreasing personal cost = increasing offer value

---

### WIN-BACK COPY PRINCIPLES

**1. Acknowledge Time Gap**
- "หายไปนานเลย"
- "30 วันแล้ว"
- Show you noticed

**2. Show Care (Not Sales)**
- "หวังว่าทุกอย่างดี"
- "ผมนึกถึงคุณ"
- Human first

**3. Ask Why (Optional)**
- Make it easy to answer
- Multiple choice helps
- Open text option

**4. Make Compelling Offer**
- Discount appropriate to inactivity
- Bonus product
- Limited time

**5. Graceful Exit if "No"**
- Respect their choice
- Don't be pushy
- Leave door open

---

### WIN-BACK METRICS

**Track:**

- Total inactive customers
- Win-back outreach rate
- Reactivation rate
- Revenue from reactivated
- Cost of reactivation

**Targets:**

| Metric | Target |
|--------|--------|
| Reactivation 30-day | 15-25% |
| Reactivation 60-day | 10-15% |
| Reactivation 90-day | 5-10% |
| Reactivation 180+ | 2-5% |
| Reactivation revenue | 5-15% of total |

**ROI:**
- Win-back cost: ฿100-500 per customer
- Lifetime value reactivated: ฿2,000-10,000
- ROI: 4-20x typical

---

### POST WIN-BACK ONBOARDING

**If they come back:**

**Day 1:**
- Welcome back email
- Special VIP-style treatment
- Personal note from founder

**Day 7:**
- Check-in
- Offer help
- Make sure satisfied

**Day 30:**
- Re-engage in regular customer journey
- Join Maverick Crew if eligible
- Refresh subscription

**Goal:** Don't lose them again

---

### LETTING GO GRACEFULLY

**After 4 win-back attempts:**

```
สวัสดีครับ คุณ [Name]

นี่คือข้อความสุดท้ายจากผม

ผม respect choice ของคุณที่ไม่กลับมา

หากกลับมาในอนาคต:
- LINE OA: @maverickskin
- Website: maverickskin.com
- Email: hello@maverickskin.com

ขอบคุณที่เคย trust Maverick
หวังว่าทุกอย่างจะดีกับคุณ

— ครูเอ็ม, Founder
```

**Auto-mark as "lost" — stop outreach**

---

### COMMON WIN-BACK MISTAKES

**❌ Same offer for all:**
- VIP gets generic email
- Lose chance to reactivate

**❌ Too pushy:**
- 10 emails in a week
- Customer permanent block

**❌ ไม่ ask why:**
- Don't understand
- Wrong offer

**❌ Discount too quickly:**
- 50% off first message
- Devalue brand

**❌ Won-back, ignore:**
- Same neglect that lost them
- Lose again

## Output Format

```
## Win Back Script — [scenario]

### Win-Back Scenarios
1. 30 days inactive (soft)
2. 60 days inactive (direct)
3. 90 days + refund (hard)
4. Cancelled subscription
5. VIP lost (personal)

### Segment Strategy
- By inactivity / reason / value

### Offer Escalation
- 30/60/90/180 days

### Copy Principles
1. Acknowledge time
2. Show care
3. Ask why
4. Compelling offer
5. Graceful exit

### Metrics & Targets
| Metric | Target |

### Post Win-Back Onboarding
- Day 1, 7, 30 plan

### Letting Go
- After 4 attempts
- Final goodbye

### Common Mistakes
❌ Same for all ❌ Too pushy ❌ Don't ask why ❌ Discount too soon ❌ Ignore after win-back
```

## Constraints

- Segment by value/reason
- Personalized approach
- Maximum 4 outreach attempts
- Track ROI
- Graceful exit if firm "no"

## Anti-patterns

- ❌ Generic mass win-back
- ❌ Pushy multiple attempts
- ❌ Skip understanding why
- ❌ Discount immediately
- ❌ Ignore won-back customer

## Related Skills

- **cancellation-handling** — cancellation
- **follow-up-message** — follow-up
- **lead-nurture-automation** — nurture

## Memory

- `user.win_back_scripts` — scripts
- `stats.win_back_rate` — rate
- `user.lost_customers` — segment
