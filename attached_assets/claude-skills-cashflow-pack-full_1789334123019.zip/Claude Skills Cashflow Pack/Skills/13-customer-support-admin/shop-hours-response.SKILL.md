---
name: Shop Hours Response
id: shop-hours-response
category: customer-support
trigger:
  - "shop hours response"
  - "business hours"
  - "operating hours"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Customer Support — เข้าใจว่า hours questions = simple but important — clear info builds trust + sets expectations

## Context

ผู้ใช้คือ admin

## Triggers

- **"shop hours"** → hours
- **"open hours"** → open
- **"closing time"** → closing

## Tools

Pure prompt — รับ business setup แล้วเขียน response

## Task

1. **Operating hours info**
2. **Holiday schedule**
3. **After-hours expectations**
4. **Multi-channel coverage**

## Examples

### SHOP HOURS RESPONSE TEMPLATES

**Q: เปิดกี่โมง?**

**Response:**
```
สวัสดีครับ คุณ [Name]

⏰ เวลาทำงาน Maverick:

📅 จันทร์-เสาร์: 09:00-21:00
📅 อาทิตย์: 10:00-18:00
🚫 หยุด: วันหยุดราชการสำคัญ

📦 ส่งของ:
- จันทร์-เสาร์ก่อน 14:00 → ส่งวันเดียวกัน
- หลัง 14:00 / อาทิตย์ → ส่งวันถัดไป

💬 ตอบ DM:
- เวลาทำงาน: ภายใน 30 นาที
- นอกเวลา: ภายในเช้า

มีคำถามเพิ่ม DM มาเลย
```

---

**Q: ปิดเมื่อไหร่?**

**Response:**
```
🚪 ปิดวันนี้:
- จันทร์-เสาร์: 21:00
- อาทิตย์: 18:00

📅 หยุดประจำปี:
- วันสงกรานต์ (เม.ย.)
- วันปีใหม่ (1 ม.ค.)
- วันหยุดราชการสำคัญ

จะแจ้งล่วงหน้าทุกครั้งใน LINE OA + IG

จะสั่งของก่อนปิดได้:
- จันทร์-เสาร์ ก่อน 14:00 = ส่งวันเดียวกัน
- หลัง 14:00 = วันถัดไป
```

---

**Q: ตอบเมล/แชทตอนไหน?**

**Response:**
```
💬 Response Time:

⚡ LINE OA:
- เวลาทำงาน (จันทร์-เสาร์ 09:00-21:00): < 30 นาที
- นอกเวลา: ภายในเช้าวันถัดไป

📧 Email:
- ภายใน 24 ชั่วโมง (เวลาทำงาน)

📞 FB Messenger:
- < 30 นาที (เวลาทำงาน)

🚨 Urgent (e.g. damaged product):
- DM "URGENT" → priority response
- ตอบภายใน 1 ชั่วโมง
```

---

**Q: ส่งของเมื่อไหร่?**

**Response:**
```
📦 Shipping Schedule:

จันทร์-เสาร์:
✅ Pack + Ship ทุกวัน
✅ ออเดอร์ก่อน 14:00 → ส่งวันเดียวกัน
✅ ออเดอร์หลัง 14:00 → ส่งวันถัดไป

อาทิตย์:
🛌 ทีม pack ไม่ทำงาน
📦 ออเดอร์อาทิตย์ → ส่งจันทร์เช้า

⚡ Express (Bangkok เท่านั้น):
- เพิ่ม ฿100
- 1-2 วันทำการ

📍 Tracking:
- Auto-email + LINE OA
```

---

**Q: หยุดสงกรานต์ไหม?**

**Response:**
```
🌊 สงกรานต์ Holiday:

📅 [Specific dates - announce 2 weeks before]
🚫 ปิด: เม.ย. 13-15
✅ เปิด: เม.ย. 16

ก่อน hold:
- ออเดอร์ก่อน 11 เม.ย. = ส่งทันก่อนปิด
- ออเดอร์ 12-15 เม.ย. = ส่ง 16 เม.ย.

🎁 สงกรานต์ Promo:
SONGKRAN15 — 15% off
+ Free Sunscreen

🌸 สุขสันต์วันสงกรานต์!
— Maverick Team
```

---

### HOLIDAY SCHEDULE COMMUNICATION

**2 weeks before holiday:**

```
📅 HOLIDAY NOTICE

[Holiday name + dates]

🚫 Maverick ปิด: [date]
✅ เปิดอีกครั้ง: [date]

ส่งของ:
- ออเดอร์ก่อน [date] = ส่งทันก่อนปิด
- ออเดอร์ระหว่างหยุด = ส่งกลับหลังเปิด

ตอบแชท:
- จะตอบกลับภายใน 24 ชั่วโมงหลังเปิด

ขอบคุณที่เข้าใจ
— Maverick Team
```

---

### AFTER-HOURS AUTO-REPLY

**For LINE OA / Messenger:**

```
สวัสดีครับ! ขอบคุณที่ติดต่อ Maverick 🙏

ขณะนี้ outside office hours
(จันทร์-เสาร์ 09:00-21:00)

จะตอบกลับ:
- คำถามทั่วไป: ภายในเช้า
- เคสด่วน (damaged, ไม่ได้รับ): priority

ในระหว่างนี้:
🌐 maverickskin.com
📚 maverickskin.com/faq
📦 Order tracking via order #

ขอบคุณครับ
```

---

### THAI HOLIDAYS TO CONSIDER

**Major Thai holidays (typically closed):**

- วันปีใหม่ (Jan 1)
- วันมาฆบูชา
- วันสงกรานต์ (Apr 13-15)
- วันแรงงาน (May 1)
- วันฉัตรมงคล (May 4)
- วันวิสาขบูชา
- วันเฉลิมพระชนมพรรษา (Jul 28)
- วันแม่ (Aug 12)
- วันคล้ายวันสวรรคต (Oct 13)
- วันปิยมหาราช (Oct 23)
- วันคล้ายวันพระบรมราชสมภพ (Dec 5)
- วันรัฐธรรมนูญ (Dec 10)
- วันสิ้นปี (Dec 31)

**Communicate 2 weeks before each**

---

### COMMUNICATING HOURS — BEST PRACTICES

**1. Multiple Visible Places**
- Website footer
- LINE OA welcome
- FB Page about
- IG bio
- Email signature

**2. Auto-Replies After Hours**
- Set expectations
- Provide alternatives
- Don't leave silent

**3. Pin Holiday Schedules**
- 2 weeks notice
- LINE OA broadcast
- Social media post
- Website banner

**4. Consistency**
- Same hours all platforms
- ไม่ contradict
- Update simultaneously

---

### COMMON HOURS MISTAKES

**❌ Inconsistent info:**
- Different on FB vs LINE
- Customer confused

**❌ ไม่มี holiday notice:**
- Customer expects, no response
- Frustration

**❌ ไม่มี after-hours reply:**
- Silent + cold
- Lower trust

**❌ Vague:**
- "Sometimes we're open"
- Customer can't plan

**❌ Outdated info:**
- Hours changed, ไม่ update
- Customer angry

## Output Format

```
## Shop Hours Response — [topic]

### Standard Hours Templates
- เปิดกี่โมง / ปิดเมื่อไหร่ / Response time / Shipping schedule

### Holiday Schedule
- 2-week advance notice
- Communicate clearly

### After-Hours Auto-Reply
- Set expectations
- Alternative resources

### Thai Holidays Calendar
- Major holidays to plan around

### Best Practices
1. Multiple visible places
2. Auto-replies after hours
3. Pin holiday schedules
4. Consistency

### Common Mistakes
❌ Inconsistent ❌ No holiday notice ❌ No after-hours ❌ Vague ❌ Outdated
```

## Constraints

- Specific hours (not vague)
- Multiple platform consistency
- Holiday advance notice
- After-hours auto-reply
- Update info regularly

## Anti-patterns

- ❌ Inconsistent across platforms
- ❌ ไม่มี holiday notice
- ❌ ไม่มี after-hours reply
- ❌ Vague hours
- ❌ Outdated information

## Related Skills

- **inbox-greeting-script** — greeting
- **customer-support-sop** — SOP
- **holiday-greeting-customer** — holiday

## Memory

- `user.shop_hours` — hours
- `user.holiday_schedule` — schedule
- `user.after_hours_reply` — reply
