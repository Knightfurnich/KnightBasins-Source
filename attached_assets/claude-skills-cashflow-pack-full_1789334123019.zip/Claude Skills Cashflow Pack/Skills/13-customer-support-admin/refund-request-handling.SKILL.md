---
name: Refund Request Handling
id: refund-request-handling
category: customer-support
trigger:
  - "refund request handling"
  - "money back process"
  - "return policy script"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Customer Service Specialist — เข้าใจว่า refund request handle ดี = customer respect even if leaving + word-of-mouth positive

Refund principles: Don't argue, Quick processing, Document, Learn from reason

## Context

ผู้ใช้คือ admin + finance team

## Triggers

- **"refund script"** → script
- **"return process"** → return
- **"money back"** → money back

## Tools

Pure prompt — รับ refund situation แล้วเขียน script

## Task

1. **Acknowledge request**
2. **Understand reason**
3. **Process quickly**
4. **Learn for improvement**

## Examples

### REFUND REQUEST SCENARIOS

**Scenario 1: Within Money-Back Period**

**Customer message:**
"ใช้ Maverick มา 3 สัปดาห์แล้ว ไม่เห็นผล ขอคืนเงิน"

**Script:**
```
สวัสดีครับ คุณ [Name]

ขอบคุณที่ลอง Maverick Reset 🙏
ขอโทษที่ผลไม่ตรงกับที่คาดหวัง

ใน 30-day money back guarantee 
ของเรา — refund ทันทีไม่มีปัญหา

ขอ:
1. เลข order
2. ช่องทางคืน (บัตรเครดิต / โอน)

จะ:
✅ Refund 100% ภายใน 3 วันทำการ
✅ ไม่ต้องส่งของกลับ (ถือไว้)
✅ ไม่ต้องเหตุผลเพิ่ม

ก่อนคืน ผมขอ feedback สั้นๆ:
- ใช้กี่ครั้งต่อสัปดาห์?
- มีอะไรที่เราพอจะปรับให้ดีขึ้น?

ขอบคุณที่ลอง Maverick
— ครูเอ็ม
```

---

**Scenario 2: Skin Reaction**

**Customer message:**
"ผิวระคายเคือง ขอคืนเงิน"

**Script:**
```
สวัสดีครับ คุณ [Name]

ขอโทษมากๆ ที่เกิดอาการระคายเคือง 🙏
ผมเป็นห่วงคุณ

หยุดใช้ทันทีครับ
- ล้างน้ำเย็น
- ใส่ moisturizer basic
- ถ้ารุนแรง พบแพทย์ผิวหนัง

ขอ:
1. รูปผิวที่เกิดอาการ
2. เลข order

จะ:
✅ Refund 100% ทันที (ไม่ต้องรอ)
✅ ส่งสินค้าทดแทน (เลือกผลิตภัณฑ์อื่น) ถ้าต้องการ
✅ ปรึกษาผู้เชี่ยวชาญ skincare ฟรี

จะ analyze ingredient และดูว่าแพ้ตัวไหน
ครั้งหน้าเลือกได้แม่นยำขึ้น

ขอโทษอีกครั้งครับ
— ครูเอ็ม
```

---

**Scenario 3: Outside Money-Back Period**

**Customer message:**
"ใช้แล้ว 60 วัน ไม่เห็นผล ขอคืนเงิน"

**Script:**
```
สวัสดีครับ คุณ [Name]

ขอบคุณที่ลอง Maverick

ขออธิบายตรงๆ ครับ:
30-day money back ของเรา
ผ่านไปแล้ว 30 วัน

แต่ผมไม่อยากปฏิเสธโดยไม่ช่วย

ขอ:
1. เลข order
2. รูปผิวก่อน-หลัง (ถ้ามี)
3. ใช้ทุกคืนไหม?

ผมจะดู case-by-case:
- ใช้ตามคำแนะนำ + ผิวไม่ดีขึ้น → 50% refund
- มี medical issue → full refund
- อื่นๆ → ส่วนลด 30% สินค้าครั้งหน้า

แจ้งสถานการณ์มา จะหาทางช่วย
— ครูเอ็ม
```

---

**Scenario 4: Bought by Mistake**

**Customer message:**
"กดผิด สั่งซื้อโดยไม่ได้ตั้งใจ ขอคืน"

**Script:**
```
สวัสดีครับ คุณ [Name]

ไม่เป็นไรครับ เกิดขึ้นได้ 

ขอ:
1. เลข order (เพื่อ verify)
2. สถานะ: ส่งแล้วหรือยัง?

หากยังไม่ส่ง:
✅ Cancel ทันที + Refund 100%

หากส่งไปแล้ว:
✅ ส่งกลับให้เรา (เราจ่ายค่าส่ง)
✅ Refund 100% เมื่อรับของ

ใช้เวลาประมาณ 5-7 วัน
— ครูเอ็ม
```

---

**Scenario 5: Just Want Out (No Reason)**

**Customer message:**
"ขอ refund ครับ ไม่อยากใช้แล้ว"

**Script:**
```
สวัสดีครับ คุณ [Name]

ไม่เป็นไรครับ
ใน 30-day money back: refund ทันที

ขอเลข order

ก่อน refund ขอ feedback สั้นๆ:
- มีอะไรที่ไม่พอใจ?
- ราคา? ผล? เวลา? อื่นๆ?

ผมจะนำมาปรับปรุง

จะ refund ภายใน 3 วันทำการ
ขอบคุณที่ลอง Maverick
— ครูเอ็ม
```

---

### REFUND PROCESS TIMELINE

**Same day:**
- Receive request
- Acknowledge
- Verify order
- Begin process

**Day 1-2:**
- Approve in system
- Trigger refund (Stripe/bank)
- Email confirmation

**Day 3-5:**
- Refund hits customer account
- Follow-up email
- Mark closed

**Day 7-10:**
- Final follow-up if needed
- Customer survey

---

### REFUND POLICY GUIDELINES

**Standard policy (Maverick):**
- 30 days from delivery
- Money back 100%
- No need to return product
- No questions asked

**Exceptions:**
- Skin reaction → Refund anytime
- Damaged product → Replace + refund
- Wrong item → Replace + keep wrong (gift)
- Late delivery (>14 days) → Partial or full refund

**No refund:**
- Outside 30 days (with exceptions)
- Used product extensively (after 60+ days)
- Custom orders / personalized

---

### COLLECTING FEEDBACK ON REFUND

**Why?** Learn + improve

**Quick survey:**
"Before we refund, 30-second feedback:

1. Reason for refund:
   ◯ Didn't see results
   ◯ Skin reaction
   ◯ Too expensive
   ◯ Changed mind
   ◯ Other

2. What could we improve?
   [text field]"

**Use feedback to:**
- Improve product
- Adjust marketing
- Change customer education
- Identify trends

---

### REFUND METRICS

**Track:**
- Refund rate (% of orders)
- Refund reasons (categorize)
- Refund processing time
- Customer return rate (do they buy again?)

**Healthy benchmarks:**
- Refund rate: < 5%
- Processing time: < 3 days
- Customer satisfaction post-refund: 70%+
- Return purchase: 10-20%

---

### COMMON REFUND MISTAKES

**❌ ทำให้ยาก:**
- Long forms
- Hard to find info
- Multiple steps

**❌ Argue with customer:**
- "But you said..."
- Loses anyway, brand damaged

**❌ ช้า:**
- 14+ days to process
- Customer angry

**❌ ไม่ learn:**
- ไม่เก็บ feedback
- Repeat issues

**❌ Take personally:**
- Founder feels rejected
- Defensive response

## Output Format

```
## Refund Request Handling — [scenario]

### Refund Scenarios
1. Within money-back period
2. Skin reaction
3. Outside money-back period
4. Bought by mistake
5. Just want out (no reason)

### Refund Process Timeline
- Same day → Day 7-10

### Policy Guidelines
- Standard / Exceptions / No refund

### Collecting Feedback
- Quick survey
- Use for improvement

### Metrics
- Refund rate / Time / Satisfaction / Return purchase

### Common Mistakes
❌ Make hard ❌ Argue ❌ Slow ❌ No learning ❌ Take personally
```

## Constraints

- Quick acknowledge
- No argue with customer
- Process within 3 days
- Collect feedback
- Brand maintained even if leaving

## Anti-patterns

- ❌ Make refund difficult
- ❌ Argue with customer
- ❌ Slow processing
- ❌ ไม่ collect feedback
- ❌ Defensive emotional

## Related Skills

- **complaint-handling-script** — complaint
- **customer-support-sop** — SOP
- **return-policy-response** — return

## Memory

- `user.refund_scripts` — scripts
- `stats.refund_metrics` — metrics
- `user.refund_reasons` — reasons
