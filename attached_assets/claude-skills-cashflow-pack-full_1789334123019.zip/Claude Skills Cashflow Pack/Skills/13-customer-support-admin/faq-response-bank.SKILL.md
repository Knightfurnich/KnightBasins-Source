---
name: FAQ Response Bank
id: faq-response-bank
category: customer-support
trigger:
  - "faq response bank"
  - "common questions"
  - "quick reply templates"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Customer Service Specialist — เข้าใจว่า 80% ของคำถามซ้ำๆ — มี FAQ response bank = เร็ว + consistent + scalable

FAQ categories: Pricing, Shipping, Product, Refund, Subscription, Use, Ingredients

## Context

ผู้ใช้คือ admin + customer support team

## Triggers

- **"common questions"** → common
- **"quick replies"** → quick
- **"FAQ templates"** → templates

## Tools

Pure prompt — รับ business + common questions แล้วเขียน bank

## Task

1. **20-30 most common FAQs**
2. **Templated responses**
3. **Personalization tips**
4. **Categorization**

## Examples

### FAQ RESPONSE BANK — Maverick

```
═══════════════════════════════════════
  FAQ RESPONSE BANK
═══════════════════════════════════════

**CATEGORY 1: PRICING**

**Q: ราคาเท่าไหร่?**
"Maverick Reset 30ml = ฿590
ส่งฟรีออเดอร์ ≥ ฿500
มี Subscribe & Save 10% (฿530/เดือน)"

**Q: แพงไปไหม?**
"30ml ใช้ได้ 60-90 วัน
= ฿7-10/วัน
เทียบกับ ยี่ห้อ premium ฿1,500+
ผมว่าคุ้มค่ามาก"

**Q: มีส่วนลดไหม?**
"ตอนนี้ของกำลังจัด Launch Sale
30% off สำหรับ First-time buyer
Code: FIRST30
หรือ Subscribe & Save 10% ตลอดไป"

═══════════════════════════════════════

**CATEGORY 2: SHIPPING**

**Q: ส่งกี่วัน?**
"Bangkok: 1-2 วัน
ต่างจังหวัด: 2-4 วัน
ส่งทั่วประเทศไทย"

**Q: ค่าส่งเท่าไหร่?**
"ฟรีค่าส่ง ออเดอร์ ≥ ฿500
ออเดอร์ < ฿500: ฿50"

**Q: ส่งวันไหน?**
"ส่งทุกวัน จันทร์-เสาร์
ออเดอร์ก่อน 14:00 → ส่งวันเดียวกัน
หลัง 14:00 → ส่งวันถัดไป"

**Q: ส่งต่างประเทศได้ไหม?**
"ขณะนี้ส่งเฉพาะในไทย
สากลกำลังพัฒนาอยู่ครับ"

═══════════════════════════════════════

**CATEGORY 3: PRODUCT**

**Q: ส่วนผสมอะไรบ้าง?**
"Maverick Reset:
- Niacinamide 5%
- Zinc PCA 1%
- Salicylic Acid 0.5%
- Glycerin
- Hyaluronic Acid

ไม่มี: Paraben, Sulfate, น้ำหอม"

**Q: ใช้ตอนไหน?**
"แนะนำใช้ตอนกลางคืน
1. ล้างหน้า
2. หยด 2 หยด ทาทั่วใบหน้า
3. ตามด้วยมอยส์เจอร์ไรเซอร์ (ถ้าผิวแห้ง)
4. นอน

ตอนเช้าทาครีมกันแดด"

**Q: ปลอดภัยไหม?**
"✅ อย. registered
✅ ผลิตที่ ISO 22716 (Thailand)
✅ Dermatologist tested
✅ No animal testing
ทุก batch ผ่าน QC"

**Q: เห็นผลกี่วัน?**
"78% ของผู้ใช้เห็นผลใน 3 สัปดาห์
- สัปดาห์ 1: ผิวเริ่มดีขึ้น
- สัปดาห์ 2-3: ผิวมันลดลงชัดเจน
- สัปดาห์ 4: ผลเต็มที่
ใช้ทุกคืน 4 สัปดาห์"

═══════════════════════════════════════

**CATEGORY 4: REFUND**

**Q: ขอคืนเงินได้ไหม?**
"ได้ครับ มี 30-day money back guarantee:
✅ ใช้ครบขวด ไม่พอใจ คืนเงิน 100%
✅ ไม่ต้องส่งกลับ
✅ ไม่ต้องเหตุผล
✅ Process ภายใน 3 วันทำการ

DM มาบอก order number ครับ"

**Q: คืนเงินเข้าไหน?**
"คืนเข้าบัตร/ช่องทางที่ชำระมา
ใช้เวลา 3-7 วันทำการ"

═══════════════════════════════════════

**CATEGORY 5: SUBSCRIPTION**

**Q: Subscribe & Save คืออะไร?**
"ออเดอร์อัตโนมัติทุกเดือน:
- ราคา ฿530 (ลด 10% จาก ฿590)
- ประหยัด ฿720/ปี
- ฟรีค่าส่งทุกครั้ง
- Skip / cancel ได้ทุกเดือน"

**Q: cancel subscription ยังไง?**
"DM มาบอก จะ cancel ให้
หรือเข้า account.maverickskin.com
กด 'Manage Subscription'"

═══════════════════════════════════════

**CATEGORY 6: USE / TROUBLESHOOTING**

**Q: ผิวแห้ง ใช้ได้ไหม?**
"ได้ครับ แต่อาจต้องใช้พร้อมมอยส์เจอร์ไรเซอร์
หรือใช้ทุก 2 คืน (แทนทุกคืน)
DM แจ้งสภาพผิว จะ recommend ให้"

**Q: ใช้กับ Vitamin C ได้ไหม?**
"ได้ครับ
- Vitamin C: ใช้เช้า
- Niacinamide (Maverick): ใช้เย็น
ไม่ขัดกัน"

**Q: ผิวระคายเคือง ทำไงดี?**
"หยุดใช้ก่อนนะครับ
ใส่มอยส์เจอร์ไรเซอร์เยอะๆ
DM อาการมา จะดูว่าควรลดความถี่หรือเปลี่ยน"

═══════════════════════════════════════

**CATEGORY 7: ORDER STATUS**

**Q: ออเดอร์ของฉันส่งไหนแล้ว?**
"ขอเลข order หน่อยครับ (เช่น ORD-1234)
จะเช็ค status + tracking ให้ทันที"

**Q: ของยังไม่ได้รับ**
"เช็ค tracking number ของคุณ:
[link]
หากเลย ETA แจ้งมาเลย จะตามให้"

═══════════════════════════════════════
```

---

### PERSONALIZATION TIPS

**Each template should include:**

✅ Customer name (when known)
✅ Relevant order info (when applicable)
✅ Specific to their situation
✅ Brand voice (warm + professional)

**Avoid:**

❌ Pure copy-paste (feels robotic)
❌ Generic "Customer" address
❌ Same exact words for everyone
❌ Missing context

---

### TEMPLATE USAGE

**Quick Reply Setup:**
- Save in LINE OA, FB, IG quick replies
- Tag/categorize for fast access
- Update monthly with new common Qs

**When to customize:**
- Customer asked specific detail
- Unique situation
- Need empathy

**When to use template:**
- Standard FAQ
- Repeat question
- Quick acknowledgment

---

### COMMON FAQ MISTAKES

**❌ Pure copy-paste:**
- Robotic feel
- ลูกค้ารู้สึกไม่ใส่ใจ

**❌ ไม่อัพเดท:**
- Templates outdated
- ราคาเก่า

**❌ Too long:**
- 5+ paragraphs
- ลูกค้าไม่อ่าน

**❌ ไม่ตอบคำถาม:**
- Generic response
- ไม่แก้ปัญหา

**❌ ไม่มี follow-up:**
- ตอบจบแล้วเงียบ
- Lose engagement

## Output Format

```
## FAQ Response Bank — [business]

### Categories (7+)
1. Pricing
2. Shipping
3. Product
4. Refund
5. Subscription
6. Use / Troubleshooting
7. Order status

### Templates (20-30+ FAQs)
[Q + A pairs]

### Personalization Tips
- Use name / order info / specific
- Brand voice consistent

### Template Usage
- Quick reply setup
- Customize vs template

### Common Mistakes
❌ Pure copy-paste ❌ Outdated ❌ Too long ❌ Doesn't answer ❌ No follow-up
```

## Constraints

- 20-30 most common Qs covered
- Brand voice consistent
- Personalize each response
- Update monthly
- Multi-channel ready

## Anti-patterns

- ❌ Pure copy-paste
- ❌ Outdated info
- ❌ Too long responses
- ❌ Generic / no personalization
- ❌ ไม่มี follow-up

## Related Skills

- **inbox-greeting-script** — greeting
- **customer-support-sop** — SOP
- **objection-handling-20** — objection

## Memory

- `user.faq_bank` — FAQ
- `user.faq_categories` — categories
- `stats.faq_usage` — usage frequency
