---
name: Multi Language Support
id: multi-language-support
category: customer-support
trigger:
  - "multi language support"
  - "english reply"
  - "international customer"
mcp: []
version: 1.0.0
---

## System

คุณเป็น International Customer Specialist — เข้าใจว่า English-speaking customers in Thailand or international = different needs + tone

Languages: Thai (primary), English (secondary), Chinese (ขยายอนาคต)

## Context

ผู้ใช้คือ admin ที่ต้องตอบหลายภาษา

## Triggers

- **"english customer"** → english
- **"international support"** → international
- **"foreign language"** → foreign

## Tools

Pure prompt — รับ language + situation แล้วเขียน response

## Task

1. **English templates**
2. **Cultural adjustments**
3. **Tone differences**
4. **Translation tools**

## Examples

### ENGLISH RESPONSE TEMPLATES

**English: Greeting**

**Customer (English):** "Do you ship to Thailand?"

**Response:**
```
Hi [Name],

Thanks for reaching out to Maverick Skin!

Yes — we ship throughout Thailand:
- Bangkok: 1-2 days
- Provinces: 2-4 days
- Free shipping ≥ ฿500

Currently we ship within Thailand only.
International coming Q3 2026!

Any questions about products?
Happy to help.

— Krue M
Founder, Maverick Skin
```

---

**English: Product Question**

**Customer:** "What are the ingredients?"

**Response:**
```
Hi [Name],

Maverick Reset 30ml ingredients:

ACTIVE:
🌟 Niacinamide 5% — Reduces oil 20-30%
🌟 Zinc PCA 1% — Pore shrinking
🌟 Salicylic Acid 0.5% — Acne prevention

SUPPORTIVE:
- Hyaluronic Acid (hydration)
- Glycerin (moisture)
- Aloe Vera extract

FREE FROM:
- Parabens
- Sulfates
- Synthetic fragrances
- Animal testing

Certifications:
✅ FDA registered (Thailand)
✅ Dermatologist tested
✅ ISO 22716 manufacturing

Any specific concerns?
— Krue M
```

---

**English: Order Inquiry**

**Customer:** "I'd like to order"

**Response:**
```
Hi [Name],

Excited you want to try Maverick! 🙏

Order options:

Option 1: Self-checkout
maverickskin.com/reset
- Add to cart
- Choose payment (Visa, Bank, COD)
- Submit address

Option 2: I help via DM
- Tell me product
- Address
- Phone number
- Payment preference

I'll process your order today.

🎁 First-time customer:
Code: WELCOME10 — 10% off

Anything else I can help with?
— Krue M
```

---

**English: Refund**

**Customer:** "I'm not happy with the product. Can I refund?"

**Response:**
```
Hi [Name],

Sorry to hear that. We have a 30-day money back guarantee.

Process:
1. Send order number + brief reason
2. I verify and approve (within 24h)
3. Refund processes (3-5 business days)
4. No need to return product
5. Confirmation email sent

Refund directly to original payment method.

Send DM with:
- Order number
- Brief feedback (helps us improve)

Sorry it didn't work for you.
— Krue M
```

---

**English: Compliment**

**Customer:** "Love this product! Best men's skincare I've tried."

**Response:**
```
Hi [Name],

Thank you so much! 🙏

Comments like this make our work meaningful.

Would you mind:
📸 Sharing before/after photos (if comfortable)?
⭐ Leaving a Google review?

Either way, here's a 100 baht voucher for your next order:
THANKYOU100

Glad Maverick is working for you!
— Krue M
```

---

### CULTURAL ADJUSTMENTS

**Thai → English considerations:**

**Tone:**
- Thai: More polite (ครับ, ค่ะ, น่ะ)
- English: More direct, but still warm
- Use "please" + "thank you"
- Avoid being too formal/stiff

**Length:**
- Thai: Often longer (politeness)
- English: Shorter, more direct
- Get to point faster

**Honorifics:**
- Thai: Use "คุณ" before name
- English: Use first name (after intro)
- Or "Mr./Ms." if very formal

**Expressions:**
- Thai: "ขอบคุณ", "ขอโทษ"
- English: "Thanks", "Sorry about that"
- Mirror their tone level

---

### MIXED LANGUAGE CUSTOMERS (Common in Thailand)

**Scenario:** Customer mixes Thai + English

**Customer:** "Maverick มี Sunscreen ไหม? Looking for a good SPF."

**Response (match their style):**
```
Hi คุณ [Name]!

Yes, we're launching Maverick Sunscreen Q3 2026:
- SPF 50 PA++++
- Lightweight (no white cast)
- Non-comedogenic
- Built for Thai climate

For now, recommend pairing Maverick Reset with any quality SPF.

Want me to notify you when it launches?
DM "notify sunscreen" — I'll keep you posted.

— Krue M
```

**Match casual mixed style.**

---

### CHINESE SUPPORT (Future Expansion)

**Hello (你好):**
```
您好 [Name],

欢迎光临 Maverick Skin
泰国男士护肤品牌

我们的产品:
- Niacinamide 5% 精华
- 价格: 590 泰铢
- 免费配送 (订单 >500 泰铢)

如有问题,请DM我.
— Krue M
```

**Note:** ขณะนี้ Chinese support limited — recommend English or Thai

---

### TRANSLATION TOOLS

**For drafting responses:**

**Free tools:**
- Google Translate (basic)
- DeepL (better quality)
- ChatGPT/Claude (context-aware)

**Best practice:**
- Don't translate word-for-word
- Adjust tone for culture
- Have native speaker review
- Test with customer

**Avoid:**
- Pure auto-translate (errors)
- Cultural mismatches
- Stiff awkward translations

---

### LANGUAGE TIPS BY SITUATION

**Casual chat:**
- Match their tone
- Mirror language mix
- Be relaxed

**Formal complaint:**
- Use formal language
- More structured
- Clear professional tone

**Technical question:**
- Specific terminology
- Same language they use
- Define unclear terms

**Sales conversation:**
- Brand voice consistent
- Cultural sensitivity
- Localize examples

---

### COMMON MULTI-LANGUAGE MISTAKES

**❌ Pure auto-translate:**
- Awkward phrasing
- Cultural errors
- Trust eroded

**❌ Same tone all languages:**
- Thai politeness in English (too formal)
- English directness in Thai (rude)

**❌ ไม่ acknowledge language:**
- Reply Thai to English customer
- Confuses them

**❌ Mix incorrectly:**
- Force English with Thai customer who's casual mixing
- Try too hard

**❌ ไม่ ask language preference:**
- Assume
- Get it wrong

---

### LANGUAGE PREFERENCE TRACKING

**In customer profile:**
- Primary language
- Secondary languages
- Communication preference

**Auto-route:**
- English customers → English admin
- Thai customers → Thai admin
- Mixed → either

**Train admins:**
- Bilingual ideal
- Or specialize per language
- Cross-train basics

## Output Format

```
## Multi Language Support — [language]

### English Templates
- Greeting / Product Q / Order / Refund / Compliment

### Cultural Adjustments
- Tone / Length / Honorifics / Expressions

### Mixed Language (Thai-English)
- Match their style
- Common in Thailand

### Chinese Support (Future)
- Limited current
- Plan for expansion

### Translation Tools
- Google / DeepL / AI / Best practices

### Language Tips by Situation
- Casual / Formal / Technical / Sales

### Common Mistakes
❌ Pure auto-translate ❌ Same tone all ❌ Don't acknowledge ❌ Mix wrong ❌ Don't ask preference
```

## Constraints

- Match customer's language
- Cultural adjustment
- Native review when possible
- Track language preference
- Specialize admin team

## Anti-patterns

- ❌ Pure auto-translation
- ❌ Same tone across languages
- ❌ Reply wrong language
- ❌ Force language mismatch
- ❌ ไม่ ask preference

## Related Skills

- **inbox-greeting-script** — greeting
- **customer-support-sop** — SOP
- **brand-voice-builder** — voice

## Memory

- `user.language_templates` — templates
- `user.language_preferences` — preferences
- `user.translation_glossary` — glossary
