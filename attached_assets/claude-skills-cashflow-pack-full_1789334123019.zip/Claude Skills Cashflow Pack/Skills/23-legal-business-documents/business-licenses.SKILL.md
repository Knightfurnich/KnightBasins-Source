---
name: Business Licenses
id: business-licenses
category: legal
trigger:
  - "business license"
  - "licenses needed"
  - "permits"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Licensing Specialist (Thailand) — เข้าใจว่า right licenses = legal operations → wrong/missing = closure + fines

## Context

ผู้ใช้คือ business

## Triggers

- **"license"** → license
- **"permit"** → permit

## Tools

Pure prompt — รับ business type แล้ว guide

## Task

1. **License types**
2. **Industry-specific**
3. **Registration**
4. **Maintenance**

## Examples

### COMMON THAI BUSINESS LICENSES

**Required for All:**

```
1. Business Registration (DBD)
- Required for company/sole prop
- Cost: ฿1K-30K
- Time: 1-14 days

2. Tax ID
- Revenue Department
- Cost: Free
- For tax filings

3. VAT Registration (if applicable)
- > ฿1.8M revenue
- Cost: Free
- Required by law

4. Social Security Registration (with employees)
- Within 30 days of first hire
- Cost: Free

Effect: Foundation legal
```

—————————

**E-Commerce License (DBD):**

```
For online businesses:
- Selling products online
- Required if specific criteria

Process:
- Register on DBD website
- Provide business info
- Display certificate online
- Free

Display:
- Website footer
- Trust badge

Effect: Customer trust + legal
```

—————————

**Food + Beverage:**

```
- FDA approval (if processed food)
- Halal certification (if applicable)
- Health permits (if restaurant)
- License from MOPH

Cost: Varies
Effect: Required to sell food
```

—————————

**Cosmetics + Skincare:**

```
For Maverick:
- FDA cosmetic notification
- Manufacturing license (or contract)
- Quality control certifications
- Halal cert (optional)

Cost:
- FDA notification: ฿5K-20K per product
- Manufacturing: Varies (contract typical)

Time: 30-60 days FDA
Effect: Legal to sell
```

—————————

**Healthcare/Medical:**

```
- Medical practice license
- Pharmacist license (if applicable)
- Equipment certifications
- Specific specialties

ไม่ for skincare typically
Effect: Healthcare specific
```

—————————

**Liquor License:**

```
For alcohol:
- Excise Department
- Specific permits
- Licensing fees significant

ไม่ usually for SMEs
Effect: Alcohol-specific
```

—————————

**Tourism License:**

```
- TAT registration
- Tour operator license
- Hotels licensing

Specific to industry
Effect: Tourism business
```

—————————

**Education License:**

```
For schools/courses:
- Ministry of Education
- Specific requirements
- Curriculum approval

For online courses:
- Often ไม่ formal license required
- Specific categories regulated

Maverick course:
- ไม่มี formal license required
- Skill course, ไม่ accredited

Effect: Verify per situation
```

—————————

**Professional Licenses:**

```
Specific professions:
- Lawyer (Thai Bar)
- Accountant (FAP)
- Doctor (Medical Council)
- Engineer (Council of Engineers)
- Architect

For consulting/services:
- ไม่ usually licensed
- Some specialized: yes

Effect: Profession-specific
```

—————————

**Manufacturing License:**

```
For factories:
- Factory permit (Industrial Works)
- Environmental
- Safety
- Specific industry

Cost: Significant
Effect: Manufacturing-specific
```

—————————

**Import/Export:**

```
For trading:
- Customs registration
- Specific product permits
- HS code classification
- Trade compliance

Cost: Setup ฿20K+
Effect: Trade-specific
```

—————————

**Construction License:**

```
For construction:
- Construction company permit
- Specific licenses per scope
- Insurance requirements

Effect: Construction-specific
```

---

### MAVERICK LICENSES

**Required:**

```
1. Limited Company registration ✅
2. Tax ID ✅
3. VAT registration (when ฿1.8M+) ✅
4. Social Security (with employees) ✅
5. E-commerce DBD registration ✅
6. FDA cosmetic notifications (per product) ✅

Optional:
- Halal certification
- ISO certifications (manufacturing)
- Trademark registration ✅

Total cost: ฿50K-100K initial + maintenance
Effect: Fully compliant
```

---

### LICENSE PROCESS (General)

**Step 1: Identify Required**

```
Research:
- Industry-specific
- Local requirements
- Online research
- Lawyer/consultant

Check:
- DBD website
- Industry associations
- Government websites
- Lawyer specialist

Effect: Know what need
```

—————————

**Step 2: Prepare Documents**

```
Common requirements:
- Company registration
- Tax ID
- Owner/director info
- Financial statements (some)
- Specific certifications
- Address proof

Effect: Ready to apply
```

—————————

**Step 3: Submit Application**

```
- Government office (specific)
- Online (some)
- Through agent/lawyer

Cost:
- Government fees
- Lawyer fees (if used)
- Specific certifications

Effect: Application in
```

—————————

**Step 4: Approval Process**

```
- Review period (varies)
- Possible follow-up
- Inspections (some industries)
- Approval or rejection

Time: 1 month - 2 years (specialized)
Effect: License granted (or not)
```

—————————

**Step 5: Maintain**

```
- Display license (as required)
- Annual renewals
- Compliance audits
- Updated information

Cost: Annual fees + compliance
Effect: Ongoing operation
```

---

### LICENSE COMPLIANCE

**Annual Renewals:**

```
Most licenses:
- Annual renewal required
- Pay renewal fees
- File compliance reports
- Maintain records

ไม่ renew:
- License expires
- Operations illegal
- Fines accumulate
- Forced closure

Effect: Calendar critical
```

—————————

**Inspections:**

```
Some industries:
- Periodic inspections
- Compliance verification
- Possible findings

Be prepared:
- Records up to date
- Compliance maintained
- Address findings

Effect: Pass inspections
```

—————————

**Updates:**

```
When change:
- Address change
- Owner change
- Business model change
- New products/services

Update licenses + registrations
Notify authorities

Effect: Compliance maintained
```

---

### COMMON LICENSE MISTAKES

**❌ Operate without license:**
- Illegal operations
- Heavy fines
- Forced closure
- Reputation damaged

**❌ ไม่ renew:**
- License expires
- Fines accumulate
- Re-registration needed

**❌ DIY complex:**
- FDA, manufacturing
- Mistakes costly
- Use specialists

**❌ ไม่ display:**
- Some require visible
- Customer trust

**❌ Outdated info:**
- Address changes
- ไม่ updated
- Compliance gap

## Output Format

```
## Business Licenses — [industry]

### Required for All
1. Business Registration (DBD)
2. Tax ID (Revenue Department)
3. VAT (if > ฿1.8M)
4. Social Security (with employees)

### Industry-Specific (Examples)
- E-commerce (DBD online)
- Cosmetics (FDA notification per product)
- Food (FDA + health permits)
- Education (Ministry, varies)
- Manufacturing (factory permit)
- Import/Export (customs)
- Trademark (DPI)

### Maverick Licenses
- Company registration
- Tax + VAT
- Social Security
- E-commerce
- FDA cosmetic notifications (per product)
- Trademark

Cost: ฿50K-100K initial + maintenance

### License Process (5 steps)
1. Identify required
2. Prepare documents
3. Submit application
4. Approval process
5. Maintain (renewals + compliance)

### Maintenance
- Annual renewals
- Inspections
- Updates when changes

### Principles (3)
1. Identify all requirements
2. Use specialists for complex
3. Maintain + renew

### Common Mistakes
❌ Operate without ❌ ไม่ renew ❌ DIY complex ❌ ไม่ display ❌ Outdated info
```

## Constraints

- Identify all required licenses
- Use specialists for complex
- Renewal calendar maintained
- Display required licenses
- Update when changes

## Anti-patterns

- ❌ Operate unlicensed
- ❌ Skip renewals
- ❌ DIY complex licenses
- ❌ ไม่ display
- ❌ Outdated information

## Related Skills

- **business-registration** — registration
- **legal-compliance** — compliance

## Memory

- `user.business_licenses` — licenses
