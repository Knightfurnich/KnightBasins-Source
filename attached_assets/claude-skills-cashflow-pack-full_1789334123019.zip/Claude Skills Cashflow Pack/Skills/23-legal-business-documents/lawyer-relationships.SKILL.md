---
name: Lawyer Relationships
id: lawyer-relationships
category: legal
trigger:
  - "find lawyer"
  - "work with lawyer"
  - "legal counsel"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Lawyer Relationship Specialist — เข้าใจว่า right lawyer = business asset → wrong = liability + cost

## Context

ผู้ใช้คือ business

## Triggers

- **"lawyer"** → lawyer

## Tools

Pure prompt — รับ situation แล้ว guide

## Task

1. **Find right lawyer**
2. **Build relationship**
3. **Cost management**
4. **Effective work**

## Examples

### TYPES OF LAWYERS

**Generalist (Solo Practitioner):**

```
Pros:
- Lower cost
- Personal attention
- Variety of matters
- Long-term relationship

Cons:
- Limited specialty
- Less depth
- Solo limits

Best for: Small businesses general matters
Cost: ฿2K-10K/hour
```

—————————

**Boutique Specialty Firm:**

```
Pros:
- Specialty depth
- Relevant expertise
- Industry knowledge

Cons:
- Higher cost
- ไม่ all areas

Best for: Specific industries/issues
Cost: ฿5K-15K/hour
```

—————————

**Large Law Firm:**

```
Pros:
- All specialties
- Deep resources
- Brand prestige
- International capabilities

Cons:
- Highest cost
- Less personal attention
- Junior associates work
- Bureaucratic

Best for: Major matters, large companies
Cost: ฿8K-30K/hour
```

—————————

**In-House Counsel:**

```
Employee lawyer:
- Full-time + benefits
- Cost: ฿100K-500K/month
- Best for: Large companies (20+ employees)

ไม่ for SMEs typically
```

---

### FINDING LAWYER

**Sources:**

```
Best:
- Referrals (other founders, accountants)
- Industry associations
- Personal network

Medium:
- LinkedIn search
- Bar association directory
- Online directories

Lower priority:
- Cold search
- Random websites

Effect: Quality matters
```

—————————

**What to Look For:**

```
- Industry expertise
- Reasonable rates
- Communication style
- Responsiveness
- References from clients
- Specific experience

Verify:
- Bar membership
- Reputation
- Past cases (within ethics)
- Client testimonials

Effect: Right fit
```

—————————

**Interview Process:**

```
First meeting (often free):
- Discuss your needs
- Their experience
- Communication style
- Fee structure
- References
- Process for working

Effect:
- Match fit
- ไม่ pressure
```

—————————

**Maverick Lawyer Search:**

```
Year 1:
- Asked 5 founder friends
- Got 3 referrals
- Met all 3
- Chose specialty firm (skincare experience)
- ฿8K/hour rate
- Strong communication

Effect: Right lawyer found
```

---

### TYPES OF LEGAL WORK

**Foundational:**

```
- Business registration
- Contracts (templates)
- Privacy policy + TOS
- Trademark filing
- Employment templates

Cost: ฿50K-200K initial setup
Effect: Legal foundation
```

—————————

**Ongoing:**

```
- Annual filings review
- Contract reviews
- Compliance checks
- General questions
- Specific issues

Cost: ฿100K-500K/year retainer
Effect: Constant access
```

—————————

**Project-Based:**

```
- Specific transactions
- Major deals
- Disputes
- Special situations

Cost: Per project (฿20K-1M+)
Effect: Project-specific
```

—————————

**Crisis:**

```
- Lawsuit threatened
- Major dispute
- Government investigation
- Criminal allegations
- M&A

Cost: ฿200K-millions
Effect: Critical defense
```

---

### COST MANAGEMENT

**Fee Structures:**

```
Hourly:
- ฿2K-30K/hour
- Pay for time spent
- Common for ongoing

Flat Fee:
- ฿5K-50K per task
- Predictable cost
- Best for routine

Retainer:
- ฿20K-100K/month
- Set monthly hours
- Predictable + access

Contingency:
- % of recovery (lawsuits)
- ไม่ upfront cost
- Lawyer takes risk

Effect: Match structure to need
```

—————————

**Reduce Costs:**

```
- Be prepared (organized info)
- Specific questions
- ไม่ small chat (clock)
- Use email (cheaper than calls)
- Templates (reduce per-use)
- Hybrid (you do basics, lawyer reviews)

Effect: Get value, reduce bill
```

—————————

**Maverick Cost Pattern:**

```
Year 1 (early): ฿100K initial setup
Year 2: ฿150K (templates + reviews)
Year 3: ฿250K (retainer + projects)
Year 5: ฿500K+ (mature operations)

Effect: Investment in protection
```

---

### EFFECTIVE WORKING

**Communication:**

```
Best practices:
- Clear questions
- All relevant info
- Documented records
- Responsive to lawyer
- ไม่ panic emails
- Professional tone

Effect:
- Better legal advice
- Faster resolutions
- Lower costs
```

—————————

**What to Bring/Send:**

```
For meetings:
- Specific issue
- All relevant documents
- Background context
- Goals/objectives
- Specific questions

ไม่:
- Vague "got a problem"
- Show up unprepared
- Skip background
```

—————————

**Be a Good Client:**

```
- Pay on time
- Respect their time
- Provide info quickly
- Don't argue every charge
- Build long-term relationship
- Refer others (if great)

Effect:
- Lawyer prioritizes you
- Better service
- Reasonable accommodations
```

---

### COMMON LAWYER ISSUES

**Issue 1: Slow Responsiveness**

```
- ไม่ reply for days
- Missing deadlines
- Poor communication

Fix:
- Set expectations upfront
- Polite reminder
- Discuss directly
- Switch if persistent
```

—————————

**Issue 2: Surprise Bills**

```
- Higher than expected
- Hidden charges
- ไม่ communicated

Fix:
- Estimates upfront
- Approval over thresholds
- Ask before tasks
- Negotiate
```

—————————

**Issue 3: Wrong Specialty**

```
- Generalist on complex
- Out of depth
- Mistakes

Fix:
- Specialty firm for complex
- Verify expertise upfront
- Ask their specific experience
```

—————————

**Issue 4: ไม่ Aligned**

```
- Different communication style
- Conflicting approaches
- Personality clash

Fix:
- Try resolution
- Or switch lawyer
- ไม่มี one right
```

—————————

**Issue 5: Ethics Concerns**

```
- Conflicts of interest
- Confidentiality breach
- Inappropriate behavior

Fix:
- Address directly
- Bar association complaint
- Switch immediately
```

---

### LAWYER RELATIONSHIP PRINCIPLES

**Principle 1: Right specialty**

✅ Match to need
- Generalist on complex = mistakes

—————————

**Principle 2: Build relationship**

✅ Long-term partnership
- Constant rotation = costly

—————————

**Principle 3: Be prepared**

✅ Organized + specific
- Random = wasted billable

—————————

**Principle 4: Pay promptly**

✅ Good client behavior
- Late = priority drops

—————————

**Principle 5: Trust but verify**

✅ Their expertise + your judgment
- Blind trust ไม่ smart

---

### COMMON LAWYER MISTAKES

**❌ DIY everything:**
- Save lawyer fees
- Costly mistakes

**❌ Wrong specialty:**
- Generalist on M&A
- Mistakes

**❌ ไม่ communicate clearly:**
- Vague questions
- Wrong answers

**❌ Skip lawyer entirely:**
- Major matters
- Catastrophic risk

**❌ Bargain hunt:**
- Cheap lawyer = cheap quality
- Worth premium

**❌ Wait until crisis:**
- ไม่มี lawyer relationship
- Expensive emergency

## Output Format

```
## Lawyer Relationships — [need]

### 4 Lawyer Types
1. Generalist (solo, ฿2-10K/hr)
2. Boutique specialty (฿5-15K/hr)
3. Large firm (฿8-30K/hr)
4. In-house counsel (large companies only)

### Finding Lawyer
- Sources: Referrals best, industry, network
- Look for: Industry expertise, communication, references
- Interview process (often free)
- Maverick: Specialty firm chosen via referrals

### Cost Management
- Fee structures: Hourly, Flat, Retainer, Contingency
- Reduce costs: Prepared, specific, templates
- Maverick: ฿100K-500K/year (scaled)

### Effective Working
- Clear communication
- Bring relevant info
- Be good client (pay on time)

### Common Issues
1. Slow responsiveness
2. Surprise bills
3. Wrong specialty
4. ไม่ aligned
5. Ethics concerns

### Principles (5)
1. Right specialty
2. Build relationship
3. Be prepared
4. Pay promptly
5. Trust but verify

### Common Mistakes
❌ DIY everything ❌ Wrong specialty ❌ ไม่ communicate ❌ Skip lawyer ❌ Bargain hunt ❌ Wait until crisis
```

## Constraints

- Specialty match to need
- Long-term relationship
- Be organized client
- Pay promptly
- Verify expertise

## Anti-patterns

- ❌ DIY major legal
- ❌ Wrong specialty
- ❌ Vague communication
- ❌ Bargain hunting
- ❌ Wait for crisis

## Related Skills

- **contracts-basics** — contracts
- **legal-compliance** — compliance

## Memory

- `user.lawyer_relationships` — relationships
