---
name: Legal Mistakes
id: legal-mistakes
category: legal
trigger:
  - "legal mistakes"
  - "common legal errors"
  - "legal problems"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Legal Risk Coach — เข้าใจว่า most businesses make same legal mistakes → fix common = avoid major

## Context

ผู้ใช้คือ business

## Triggers

- **"legal mistakes"** → mistakes

## Tools

Pure prompt — provide list

## Task

1. **Top mistakes**
2. **Consequences**
3. **Prevention**

## Examples

### TOP 15 LEGAL MISTAKES

**Mistake 1: DIY Critical Contracts**

```
Use templates without lawyer:
Consequence:
- Vague terms
- Disputes
- Costly disputes

Fix: Lawyer for major contracts
```

—————————

**Mistake 2: Skip Trademark**

```
Use brand without registering:
Consequence:
- Someone else trademarks
- Forced rename
- Lose brand equity

Fix: Trademark when launching
```

—————————

**Mistake 3: Poor Privacy Policy**

```
Generic or missing:
Consequence:
- PDPA violations
- ฿5M fines
- Customer trust loss

Fix: Lawyer-drafted PDPA-compliant
```

—————————

**Mistake 4: ไม่ Document Performance Issues**

```
Termination without paper:
Consequence:
- Wrongful termination claims
- Severance + damages
- Major payouts

Fix: PIP + documented warnings
```

—————————

**Mistake 5: Misclassify Contractors**

```
Treat as employees:
Consequence:
- Reclassification
- Back taxes + benefits
- Penalties

Fix: True independent contractor
```

—————————

**Mistake 6: ไม่มี Cybersecurity Plan**

```
Data breach:
Consequence:
- PDPA fines
- Customer lawsuits
- Reputation destroyed

Fix: Multi-layer security + insurance
```

—————————

**Mistake 7: Skip Insurance**

```
Save premium:
Consequence:
- One incident = bankruptcy
- Catastrophic exposure

Fix: Comprehensive coverage
```

—————————

**Mistake 8: Verbal Agreements**

```
Friend/family/casual:
Consequence:
- Disputes
- Damaged relationships
- Legal mess

Fix: Always written
```

—————————

**Mistake 9: Late Tax Filings**

```
Forget or delay:
Consequence:
- Penalties + interest
- Audit risk
- Possible criminal

Fix: Calendar + accountant
```

—————————

**Mistake 10: Mix Personal + Business**

```
Same accounts:
Consequence:
- Tax disasters
- Audit nightmares
- Pierce corporate veil

Fix: Separate completely
```

—————————

**Mistake 11: ไม่มี Partnership Agreement**

```
Co-founders verbal:
Consequence:
- Equity disputes
- Decision deadlock
- Business destroyed

Fix: Lawyer-drafted agreement upfront
```

—————————

**Mistake 12: False Marketing Claims**

```
Medical claims for cosmetics:
Consequence:
- FDA penalties
- Consumer lawsuits
- Reputation damage

Fix: Compliant claims only
```

—————————

**Mistake 13: Influencer ไม่ Disclose**

```
"Looks more authentic":
Consequence:
- Legal violations
- Influencer + brand liable
- Trust damaged

Fix: Mandatory disclosure
```

—————————

**Mistake 14: Ignore Government Notices**

```
Pile up notices:
Consequence:
- Compounding penalties
- Default judgments
- Major problems

Fix: Address quickly
```

—————————

**Mistake 15: ไม่มี Buy-Sell Provisions**

```
Partner exit:
Consequence:
- Stuck with bad partner
- ไม่มี clean exit
- Legal nightmare

Fix: Include in partnership agreements
```

---

### CONSEQUENCES BY SEVERITY

**Catastrophic:**

```
- Business closure
- Bankruptcy
- Criminal charges
- Reputation destroyed

Mistakes:
- PDPA major violations
- Tax fraud
- Employment law major
- Operating without licenses
```

—————————

**Major:**

```
- ฿1M+ damages
- Significant fines
- Legal battles
- Operations disrupted

Mistakes:
- Contract disputes major
- Trademark loss
- Insurance gaps
- Cybersecurity breaches
```

—————————

**Moderate:**

```
- ฿100K-1M issues
- Time-consuming
- Reputation impact
- Stress

Mistakes:
- Most common ones
- DIY mistakes
- Documentation gaps
```

—————————

**Minor:**

```
- ฿10K-100K
- Annoying
- Manageable

Mistakes:
- Late filings
- Process issues
- Minor compliance
```

---

### PREVENTION FRAMEWORK

**Quarterly Review:**

```
Each quarter:
- Review top 15 mistakes
- Self-assess
- Identify gaps
- Action plan

Effect: Continuous improvement
```

—————————

**Annual Audit:**

```
External lawyer:
- Comprehensive review
- Identify all gaps
- Recommendations
- Costs to fix

Cost: ฿50-200K
Effect: Comprehensive view
```

—————————

**Specialist Relationships:**

```
- Lawyer (general)
- Accountant
- HR specialist (when scaling)
- IP lawyer (specific)
- International (if applicable)

Total: ฿200-500K/year typical
Effect: Right expertise available
```

—————————

**Documentation Culture:**

```
Document:
- All major decisions
- Performance reviews
- Contracts (digital + paper)
- Communications
- Compliance records

Tools:
- Notion
- Cloud backup
- Lawyer access

Effect: Defensible always
```

—————————

**Continuous Learning:**

```
Stay updated:
- Industry publications
- Lawyer newsletters
- Legal blogs
- Conferences
- Regulatory updates

Effect: ไม่มี surprises
```

---

### MISTAKE PRIORITY

**Must Address:**

```
1. Tax compliance
2. PDPA compliance
3. Insurance
4. Major contracts
5. Trademark (if branded)

Without these = catastrophic risk
```

—————————

**Should Address:**

```
6. Documentation systems
7. Employment compliance
8. Privacy policy
9. Terms of service
10. Specialist relationships

Best practice
```

—————————

**Nice to Address:**

```
11-15. Specific situations
- Address as encounter
- Continuous improvement

Effect: Mature legal posture
```

---

### LEGAL MISTAKE PRINCIPLES

**Principle 1: Prevention > Cure**

✅ Avoid mistakes
- Cleanup = expensive

—————————

**Principle 2: Specialist support**

✅ ไม่ DIY major
- Mistakes catastrophic

—————————

**Principle 3: Document everything**

✅ Memory ไม่ enough
- Defensible always

—————————

**Principle 4: Proactive review**

✅ Quarterly + annual
- Catch + fix

—————————

**Principle 5: Continuous learning**

✅ Stay informed
- Regulations change

---

### COMMON MISTAKES ABOUT MISTAKES

**❌ Hide mistakes:**
- Pretend ไม่ happen
- Compound

**❌ One-time fix:**
- Address once
- Recur over time

**❌ ไม่ learn:**
- Same mistake again
- Pattern continues

**❌ Blame others:**
- ไม่ accountability
- ไม่ improvement

## Output Format

```
## Legal Mistakes — [audit]

### Top 15 Mistakes
1. DIY critical contracts
2. Skip trademark
3. Poor privacy policy
4. ไม่ document performance
5. Misclassify contractors
6. ไม่มี cybersecurity
7. Skip insurance
8. Verbal agreements
9. Late tax filings
10. Mix personal + business
11. ไม่มี partnership agreement
12. False marketing claims
13. Influencer ไม่ disclose
14. Ignore government notices
15. ไม่มี buy-sell provisions

### Consequences by Severity
- Catastrophic (business closure)
- Major (฿1M+ damages)
- Moderate (฿100K-1M)
- Minor (฿10-100K)

### Prevention Framework
- Quarterly review
- Annual audit (฿50-200K)
- Specialist relationships
- Documentation culture
- Continuous learning

### Mistake Priority
- Must: Tax, PDPA, insurance, major contracts, trademark
- Should: Documentation, employment, privacy
- Nice: Specific situations

### Principles (5)
1. Prevention > cure
2. Specialist support
3. Document everything
4. Proactive review
5. Continuous learning

### Common Mistakes about Mistakes
❌ Hide ❌ One-time fix ❌ ไม่ learn ❌ Blame others
```

## Constraints

- Address all 15 common mistakes
- Prevention focus
- Specialist support
- Documentation systematic
- Continuous improvement

## Anti-patterns

- ❌ Hide mistakes
- ❌ One-time fixes
- ❌ DIY major
- ❌ Skip prevention
- ❌ ไม่ learn from mistakes

## Related Skills

- **legal-final-checklist** — checklist
- **legal-compliance** — compliance

## Memory

- `user.legal_mistakes` — mistakes
