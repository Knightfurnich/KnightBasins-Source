---
name: Legal Final Checklist
id: legal-final-checklist
category: legal
trigger:
  - "legal checklist"
  - "compliance checklist"
  - "legal audit"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Legal Audit Specialist — เข้าใจว่า comprehensive checklist = catch gaps → systematic compliance

## Context

ผู้ใช้คือ business

## Triggers

- **"legal checklist"** → checklist

## Tools

Pure prompt — รับ stage แล้ว audit

## Task

1. **Foundation checklist**
2. **Operational checklist**
3. **Annual review**
4. **Risk assessment**

## Examples

### FOUNDATION CHECKLIST

**Business Setup:**

```
□ Business structure chosen
□ Business registration current (DBD)
□ Tax ID registered
□ VAT registration (if > ฿1.8M)
□ Bank account separate
□ Accounting system in place
□ Lawyer relationship established
□ Accountant on retainer
```

—————————

**Licenses + Permits:**

```
□ Industry-specific licenses obtained
□ E-commerce DBD registration
□ FDA notifications (if applicable)
□ Trademark filed
□ Special permits (if applicable)
□ Renewal dates calendared
```

—————————

**Contracts + Agreements:**

```
□ Service agreement template (lawyer-drafted)
□ Independent contractor template
□ Employment contract template
□ NDA templates (mutual + one-way)
□ Partnership agreement (if applicable)
□ Vendor agreements
□ All major contracts signed
```

—————————

**Customer-Facing Legal:**

```
□ Privacy policy current (PDPA)
□ Terms of Service comprehensive
□ Cookie policy (if applicable)
□ Refund/return policy
□ Shipping terms
□ All visible on website
```

—————————

**Employment:**

```
□ Employment contracts signed (all employees)
□ Employee handbook current
□ Anti-harassment policy
□ Anti-discrimination policy
□ Working hours compliant
□ Vacation/leave policies
□ Benefits documented
□ Termination process clear
```

—————————

**Tax Compliance:**

```
□ Tax filings current
□ VAT compliance (if registered)
□ Withholding tax procedures
□ Social Security registered
□ Workmen's Comp registered
□ Records 5+ years retention
```

—————————

**Data Privacy (PDPA):**

```
□ Privacy policy comprehensive
□ Consent forms updated
□ Data audit completed
□ Subject rights process
□ Vendor agreements (DPAs)
□ Breach response plan
□ Internal training completed
```

—————————

**Insurance:**

```
□ Workmen's Compensation
□ Professional liability
□ Product liability (if applicable)
□ Cyber liability
□ Property insurance
□ Health insurance (employees)
□ Annual review scheduled
```

—————————

**IP Protection:**

```
□ Trademark filed (brand)
□ Trademark filed (logo)
□ Copyright on key content
□ NDAs for sensitive sharing
□ IP assignment in contracts
□ Trade secrets protected
□ Renewal dates calendared
```

---

### OPERATIONAL CHECKLIST

**Monthly:**

```
□ VAT filing (15th)
□ Withholding tax (7th)
□ Social Security (15th)
□ Salary tax processed
□ Bank reconciliation
□ Compliance issues review
```

—————————

**Quarterly:**

```
□ Compliance dashboard review
□ Lawyer + accountant meeting
□ Risk assessment update
□ Action items from past quarter
□ Specific issues addressed
□ Strategic legal planning
```

—————————

**Annually:**

```
□ Annual return filing (DBD)
□ Annual tax filing (Revenue)
□ Comprehensive compliance audit
□ All policies reviewed + updated
□ All contracts reviewed
□ Trademark renewals
□ License renewals
□ Insurance renewals
□ Lawyer review (templates)
□ Accountant review (financials)
□ Privacy policy review
□ Risk register updated
□ Training refreshed
□ Strategic legal plan
```

---

### RISK ASSESSMENT

**Categories:**

```
□ Legal risks identified
□ Compliance risks identified
□ Tax risks identified
□ Employment risks identified
□ Privacy risks identified
□ IP risks identified
□ Contract risks identified
□ Industry-specific risks

Score (1-25) each:
- Likelihood × Impact
- Prioritize critical (20+)
- Mitigation strategies
- Monitor quarterly
```

—————————

**High-Priority Mitigations:**

```
□ Insurance coverage adequate
□ Compliance program robust
□ Legal templates current
□ Documentation thorough
□ Crisis response plan
□ Specialist relationships
```

---

### LEGAL HEALTH METRICS

**Track Quarterly:**

```
- Filings on time: 100% target
- Compliance issues: 0 target
- Lawsuits/claims: Track + manage
- Audit findings: Address quickly
- Insurance gaps: ไม่มี
- Outdated policies: ไม่มี

Effect: Comprehensive view
```

—————————

**Maverick Year 3 Legal Health:**

```
- All filings on time ✅
- ไม่มี active lawsuits ✅
- Compliance audit clean ✅
- Insurance comprehensive ✅
- Templates current ✅
- Annual review completed ✅

Cost: ฿250-300K/year
Effect: Strong legal foundation
```

---

### ANNUAL LEGAL AUDIT

**Comprehensive Review:**

```
External lawyer:
- All compliance areas
- Recent law changes
- Industry updates
- Specific issues
- Recommendations

Cost: ฿50K-200K
Time: 2-4 weeks
Effect: Comprehensive view
```

—————————

**Audit Output:**

```
Report includes:
- Compliance status
- Gaps identified
- Risks
- Recommendations
- Priority actions
- Costs to address

Effect: Action plan
```

—————————

**Action on Findings:**

```
- Critical: 30 days
- High: 90 days
- Medium: 180 days
- Low: 365 days

Track:
- Status of each
- Owner assigned
- Deadlines met

Effect: Closed loop
```

---

### LEGAL FOUNDATION PRINCIPLES

**Principle 1: Comprehensive coverage**

✅ All areas
- Gaps = risk

—————————

**Principle 2: Current + maintained**

✅ Annual updates
- Stale = liability

—————————

**Principle 3: Documented + organized**

✅ Audit trail
- Memory ไม่ enough

—————————

**Principle 4: Specialist relationships**

✅ Lawyer + accountant
- DIY = mistakes

—————————

**Principle 5: Proactive**

✅ ไม่ reactive only
- Prevent vs respond

---

### COMMON LEGAL FOUNDATION MISTAKES

**❌ Skip foundational:**
- Privacy policy missing
- Major exposure

**❌ ไม่มี ongoing maintenance:**
- One-time setup
- Drifts to non-compliance

**❌ Reactive only:**
- Wait for problem
- Crisis response

**❌ ไม่ document:**
- ไม่มี audit trail
- Vulnerable

**❌ DIY complex:**
- Save lawyer fees
- Costly mistakes

**❌ Skip insurance:**
- Save premium
- Catastrophic exposure

---

### YEAR-AHEAD LEGAL PLAN

**Quarterly Goals:**

```
Q1: Annual legal audit + plan
Q2: Specific area focus (e.g., IP)
Q3: Compliance updates implementation
Q4: Year-end review + next year planning

Effect: Continuous improvement
```

—————————

**Investment Levels:**

```
Solo founder: ฿100K/year
Small team: ฿200-300K/year
Mid-size: ฿500K-1M/year
Mature: ฿1M+/year

Effect: Scale appropriately
```

—————————

**ROI of Legal Investment:**

```
Without:
- Lawsuit risk: ฿1M-50M
- Penalties: ฿10K-millions
- Compliance failures: Catastrophic
- Reputation: Damaged

With (฿250K/year typical):
- Avoid all above
- Sleep at night
- Sustainable business
- Premium positioning

ROI: 5-100x avoided losses
Effect: Worth investment
```

---

### LEGAL CHECKLIST PRINCIPLES

**Principle 1: Comprehensive**

✅ All areas covered
- Gaps = exposure

—————————

**Principle 2: Maintained**

✅ Annual reviews + updates
- Stale = problems

—————————

**Principle 3: Documented**

✅ Audit trails
- Defensible

—————————

**Principle 4: Proactive**

✅ Prevention focus
- ไม่ reactive only

—————————

**Principle 5: Specialist support**

✅ Lawyer + accountant + experts
- Match expertise to need

---

### COMMON LEGAL CHECKLIST MISTAKES

**❌ ไม่มี checklist:**
- Random
- Gaps

**❌ Static checklist:**
- Year-old version
- Outdated

**❌ Skip critical:**
- Privacy policy
- Insurance
- Tax compliance

**❌ ไม่ specialist:**
- DIY major
- Mistakes

**❌ Reactive only:**
- Wait for issues
- Crisis mode

## Output Format

```
## Legal Final Checklist — [stage]

### Foundation Checklist
- Business setup (8 items)
- Licenses + permits (6 items)
- Contracts + agreements (7 items)
- Customer-facing legal (5 items)
- Employment (8 items)
- Tax compliance (6 items)
- Data privacy PDPA (7 items)
- Insurance (7 items)
- IP protection (7 items)

### Operational
- Monthly (6 items)
- Quarterly (6 items)
- Annually (14 items)

### Risk Assessment
- 8 risk categories scored (1-25)
- High-priority mitigations
- Quarterly monitoring

### Legal Health Metrics
- Filings on time: 100%
- Compliance issues: 0
- Insurance gaps: ไม่มี

### Annual Audit
- External lawyer review
- ฿50-200K cost
- Action on findings (30/90/180/365 days)

### Investment by Stage
- Solo: ฿100K/year
- Small: ฿200-300K/year
- Mid: ฿500K-1M/year
- Mature: ฿1M+/year

### ROI
- 5-100x avoided losses
- Worth investment

### Principles (5)
1. Comprehensive
2. Maintained
3. Documented
4. Proactive
5. Specialist support

### Common Mistakes
❌ ไม่มี checklist ❌ Static ❌ Skip critical ❌ DIY major ❌ Reactive only
```

## Constraints

- Comprehensive coverage
- Annual reviews
- Documented systematically
- Proactive approach
- Specialist relationships

## Anti-patterns

- ❌ Random approach
- ❌ Static documentation
- ❌ Skip foundational
- ❌ DIY complex
- ❌ Reactive only

## Related Skills

- **legal-compliance** — compliance
- **business-registration** — registration

## Memory

- `user.legal_foundation` — foundation
- `user.legal_health` — health
