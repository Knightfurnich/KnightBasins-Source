---
name: Webinar Storytelling Templates
id: webinar-storytelling-templates
category: webinar-live
trigger:
  - "webinar templates"
  - "story templates"
  - "presentation templates"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Template Specialist — เข้าใจว่า templates = save time + ensure quality → modify to fit personal voice

Templates: Founder story, Customer transformation, Industry expose, Personal failure, Origin myth

## Context

ผู้ใช้คือ presenter

## Triggers

- **"templates"** → templates
- **"story format"** → story format
- **"presentation patterns"** → patterns

## Tools

Pure prompt — รับ story type แล้ว provide template

## Task

1. **Provide template structures**
2. **Show variations**
3. **Adapt to brand voice**
4. **Practice + refine**

## Examples

### TEMPLATE 1: FOUNDER ORIGIN

```
Structure:

[Hook: Where you are NOW vs where you were]
"3 years ago I was [LOW POINT]
Now [SUCCESS POINT]
Today I'll share how I bridge that gap"

[Backstory: Specific painful moment]
"5 years ago, [SPECIFIC AGE], I had [SPECIFIC PROBLEM]
[Specific scene with sensory detail]"

[The Search: Why nothing worked]
"I tried [LIST WHAT FAILED]
But all failed because [SPECIFIC REASON]"

[The Discovery: Eureka moment]
"Then [SPECIFIC EVENT]
I realized [INSIGHT]
[Specific moment of truth]"

[The Build: Effort + persistence]
"I spent [TIME] building [PRODUCT/COURSE]
[Specific failures along the way]
Eventually [BREAKTHROUGH]"

[The Result: Where it's gone]
"Today: [SPECIFIC METRICS]
[Customer transformations]
[Recognition]"

[Why You're Here]
"That's why I'm here today
To share what I learned
With YOU"

—————————

Maverick Example:
```

```
[Hook]
"3 years ago I was ผิวมันมาก, สิว 10+ ทุกวัน
Today: 3,000+ Maverick customers, 4.8/5 rating
Today I'll share my exact 3-step method"

[Backstory]
"At 23, working in marketing
ผิวมัน = couldn't shake hands confident
Anxiety before every meeting
ทำมา 5 ปี ขาย แต่ insecure"

[The Search]
"ลอง:
- ใช้ของแฟน (women's products) — ไม่ work
- Dermatologist ฿2,000/visit — temp fix
- Premium imports — wallet drained
All failed because: ไม่ formulated for ผู้ชายไทย"

[The Discovery]
"Met Dr. Wong, skincare PhD
Said: 'ผู้ชายไทย skin = unique
Tropical, hormone, oil different
ใครจะ formulate specifically?'

I said: 'ผม.'"

[The Build]
"3 years research:
- Niacinamide concentrations
- Asian skin biology
- Formula 1: ผิวแห้ง
- Formula 5: สิวขึ้น
- Formula 27: WORKED!

ผม almost gave up at 22"

[The Result]
"Today:
- Maverick brand
- 3,000+ customers
- 4.8/5 reviews
- Featured in [media]
- ครูเอ็ม recognized in skincare"

[Why Here]
"You might have similar story
Today: Share my method
You don't have to wait 3 years"
```

---

### TEMPLATE 2: CUSTOMER TRANSFORMATION

```
Structure:

[Introduce: Specific customer]
"Let me tell you about [NAME]"

[Background: What brings credibility]
"[NAME] is [JOB/AGE/RELEVANT]"

[Their problem: Specific + relatable]
"[Specific problems they had]
[Sensory detail of their pain]"

[The choice: Their journey to your solution]
"[NAME] tried [WHAT FAILED]
Then found [YOUR SOLUTION]"

[The transformation: Step by step]
"Week 1: [PROGRESS]
Week 2: [PROGRESS]
[KEY MILESTONE]"

[The result: New reality]
"Today [NAME]: [SUCCESS METRICS]
[Quote from them]"

[Bridge: This could be you]
"You might have similar [PROBLEM]
[NAME] is example of what's possible"

—————————

Maverick Example:
```

```
[Introduce]
"Let me tell you about ปอ"

[Background]
"ปอ — engineer, 28 ปี, อยู่ Bangkok
Married soon"

[Their problem]
"10 ปีที่ struggled with ผิวมัน + สิว
ลองทุกอย่าง — ฿20,000+ wasted
Couldn't shake hands confident
Anxiety in meetings"

[The choice]
"ปอ joined Maverick course
Skeptical: 'I've tried everything'
Decided: 'One more try'"

[The transformation]
"Week 1: 30% less oily
Week 2: First clear day
Week 3: Old marks fading
Week 4: Friend asked 'ผิวดี'"

[The result]
"Today (Day 30):
- Clear skin
- Confident
- Photo: [Show before/after]
- ปอ said: 'Maverick changed my life'"

[Bridge]
"You might have similar story
ปอ shows what's possible in 30 days"
```

---

### TEMPLATE 3: INDUSTRY EXPOSE

```
Structure:

[Hook: What industry is doing wrong]
"The [INDUSTRY] industry doesn't want you to know..."

[The Problem: What's broken]
"For decades, [HOW INDUSTRY OPERATES]
[Why it doesn't work]"

[Behind The Scenes: Insider knowledge]
"As [YOUR ROLE], I see:
[Insider details]
[Specific examples]"

[The Truth: Counter-narrative]
"What works actually:
[YOUR APPROACH]
[Why it differs]"

[The Solution: Your alternative]
"That's why I built [SOLUTION]
[Specific differentiation]"

[Call to Action]
"Today I'll share what works
And help you avoid [INDUSTRY MISTAKES]"

—————————

Maverick Example:
```

```
[Hook]
"The skincare industry doesn't want you to know
Why most products fail"

[The Problem]
"For decades, skincare industry sold:
- Female-formulated products to men
- 'One size fits all' approach
- Aspirational marketing without substance
- ฿2,000-5,000/month products

Result: ผู้ชายไทย confused + bankrupt"

[Behind The Scenes]
"As Maverick founder + 5 years in industry:
- 80% of male products are repackaged female
- Marketing > formulation
- Premium pricing for marketing budget
- Asian skin genetics ไม่ studied"

[The Truth]
"What actually works:
- Specific formulation per skin type
- Asian skin biology
- Local climate considered
- ผู้ชายไทย-specific R&D"

[The Solution]
"Maverick: First brand made specifically
For Thai men's skin biology + climate"

[Call to Action]
"Today: Show why most skincare fails
And how 3-step method actually works"
```

---

### TEMPLATE 4: PERSONAL FAILURE → SUCCESS

```
Structure:

[Hook: Where you are now vs deepest low]
"I almost quit 3 years ago
Today, I run [SUCCESS]"

[The Low: Specific dark moment]
"[Specific scene, sensory detail]
[Emotion at that moment]"

[The Decision: What changed]
"[Specific event/realization]
[Decision made]"

[The Comeback: Steps taken]
"[Specific actions]
[Small wins]
[Compounding success]"

[The Lesson: What you learned]
"What I learned:
[INSIGHT]
[How it applies to others]"

[Bridge: This applies to your situation]
"If you've felt similar:
[CONNECTION]"

—————————

Maverick Example:
```

```
[Hook]
"3 years ago I was about to quit
Today: Maverick brand, 3,000+ customers"

[The Low]
"Year 2 of Maverick:
- Formula 22 failed
- ฿80,000 wasted on ingredients
- 0 paying customers
- Family asking 'ทำไม ไม่กลับงานประจำ'

I sat in my apartment, formulation failure on table
Thinking: 'It's over'"

[The Decision]
"Then I remembered Dr. Wong's words:
'Most quit before breakthrough'

That night I commit: '12 more months'
'Then if not, I quit'"

[The Comeback]
"Reset:
- Restart with focus
- Smaller batch testing
- More sleep
- Customer interviews
- Formula 23-26: Better
- Formula 27: BREAKTHROUGH

8 months later: First 10 customers
12 months: 100 customers
24 months: 1,000 customers
36 months: 3,000+ today"

[The Lesson]
"Lesson: Persistence + iteration
ไม่ giving up = differentiator
Most quit at the breakthrough"

[Bridge]
"If you're tired of skincare failure:
You're closer to breakthrough than you think
Don't quit"
```

---

### TEMPLATE 5: ORIGIN MYTH

```
Structure:

[Setting: Where it began]
"It all started [TIME PLACE]"

[Hero (you): Initial state]
"I was just [ORDINARY BACKGROUND]"

[Catalyst: What changed]
"[SPECIFIC INCITING INCIDENT]"

[Quest: Pursuing answer]
"[Journey of learning]
[Sacrifices made]"

[Discovery: Eureka moment]
"[Specific realization]"

[Master/Mentor: Who helped]
"[Person/source of insight]"

[Manifestation: What you built]
"[Tangible result]"

[Today: Where you are]
"[Current scale + impact]"

—————————

Same as Maverick founder origin
But adds the 'origin myth' feel

Use mythological framing:
- "Like a hero's journey"
- "Returns with the gift"
- "Shares wisdom"

Effect:
- Bigger than just business
- Inspirational positioning
- Premium feel
```

---

### TEMPLATE PRINCIPLES

**Principle 1: Adapt, ไม่ copy**

✅ Use template as skeleton
✅ Add personal voice
- Verbatim copy = generic

—————————

**Principle 2: Specific details**

✅ Numbers, dates, names
✅ Sensory description
- Vague = forgettable

—————————

**Principle 3: Emotional arc**

✅ Low → high → bridge
✅ Real emotions
- Logical only = boring

—————————

**Principle 4: Practice variations**

✅ Multiple stories ready
✅ Switch based on audience
- Same story repeated = stale

—————————

**Principle 5: Connect to product**

✅ Story leads to solution
✅ Smooth transition
- Story disconnected = confusing

---

### TEMPLATE TIMING IN WEBINAR

```
Phase 1 (Authority/Hook):
- Founder origin story (5-8 mins)

Phase 2 (Mid-content):
- 1-2 customer stories (3-5 mins each)

Phase 3 (Pitch transition):
- Specific transformation (3 mins)

Phase 4 (Pitch):
- Bonus stories supporting features

Phase 5 (Q&A):
- Anecdotes addressing objections

Don't:
- Tell ALL stories first
- Then content
- Then more stories

Do:
- Story → Educate → Story → Educate
- Mix throughout
```

---

### COMMON TEMPLATE MISTAKES

**❌ Verbatim copy:**
- "Just like John from Ohio..."
- ไม่ feel personal

**❌ ไม่มี emotional arc:**
- Flat narrative
- Boring

**❌ Too many stories:**
- 10+ stories per webinar
- Loses focus

**❌ Disconnected from product:**
- Story for story's sake
- ไม่มี sales benefit

## Output Format

```
## Webinar Storytelling Templates — [type]

### Templates (5)
1. Founder origin (Hero's journey structure)
2. Customer transformation
3. Industry expose
4. Personal failure → success
5. Origin myth

### Each Template Includes
- Structure (5-7 stages)
- Maverick adapted example
- Practice tips

### Principles (5)
1. Adapt ไม่ copy
2. Specific details
3. Emotional arc
4. Practice variations
5. Connect to product

### Template Timing in Webinar
- Founder: 5-8 mins (Phase 1)
- Customer: 3-5 mins (Phase 2)
- Specific: 3 mins (Phase 3)

### Common Mistakes
❌ Verbatim copy ❌ No emotion ❌ Too many ❌ Disconnect from product
```

## Constraints

- Adapt to personal voice
- Specific details
- Emotional arc
- Practice 3+ versions
- Connect to product

## Anti-patterns

- ❌ Verbatim copy
- ❌ Generic stories
- ❌ Too many in webinar
- ❌ Story without product link

## Related Skills

- **webinar-storytelling** — storytelling
- **brand-storytelling** — brand

## Memory

- `user.story_templates` — templates
- `user.story_practice` — practice
