---
name: Instagram Live Selling
id: instagram-live-selling
category: webinar-live
trigger:
  - "instagram live selling"
  - "ig live commerce"
  - "live ขาย ig"
mcp: []
version: 1.0.0
---

## System

คุณเป็น IG Live Pro — เข้าใจว่า IG Live = high engagement with existing followers + good for higher-priced products → Limited to 4 hours, native shopping less developed

Best for: Engaged community, premium products, story-driven sales

## Context

ผู้ใช้คือ IG seller

## Triggers

- **"ig live"** → IG live
- **"instagram live"** → instagram live
- **"insta live"** → insta live

## Tools

Pure prompt — รับ IG live goal แล้ว design

## Task

1. **Pre-live build**
2. **Live execution**
3. **DM-based orders**
4. **Save replay (Story/Highlight)**

## Examples

### MAVERICK IG LIVE STRATEGY

**Pre-Live (Day -3 to Day 0):**

```
Day -3: Story countdown
"📅 ศุกร์ 20:00 — IG LIVE
Special deals + new products"

Day -1: Stories teaser
"พรุ่งนี้ live — first peek
[Sneak peek photo]"

Day 0 morning:
"Tonight 20:00 IG LIVE
Tap Bell to remind 🔔"

15 mins before:
Story: "🔴 LIVE in 15 mins"
Add reminder sticker
```

---

### IG LIVE FLOW (60-90 min)

**Phase 1: Greet + Engage (0-10 min)**

```
[Camera + ring light setup]

"สวัสดี! IG LIVE Maverick!

Wave to camera if you see me
Comment 'มา' if you joined

Today we'll:
✅ Show new product
✅ Special discount
✅ Q&A about skincare

[Wait for 30+ live]

OK พร้อมเริ่ม!"
```

—————————

**Phase 2: Tease Big Product (10-20 min)**

```
"Today special launch:
NEW Maverick Sunscreen!

[Hold product]

ทำไมพิเศษ:
- SPF 50+ PA++++
- ไม่เหนียว
- ทดสอบกับผู้ชายไทย

ใครรอ Sunscreen แล้วบ้าง?"
```

—————————

**Phase 3: Demo (20-40 min)**

```
[Live application demo]

"Watch how it applies:
- เนื้อ Lightweight
- ซึมเร็ว
- Matte finish (ไม่มัน)
- ใช้ก่อน makeup ได้

Compare side-by-side:
[Show different sunscreens]"
```

—————————

**Phase 4: Pitch (40-60 min)**

```
"IG LIVE special:
฿490 → ฿343 (30% off)
Free Maverick Toner (฿390 value)
Free shipping

Total value ฿880 for ฿343

Limited: 30 spots tonight only

How to order:
DM 'SUNSCREEN' to @maverickskin
Admin จะ confirm + send link"

[Watch DMs flood]
```

—————————

**Phase 5: Q&A (60-80 min)**

```
"Common questions:

@user1 ถาม: 'รวมส่งฟรี?'
A: 'ใช่ครับ ส่งฟรีทั่วประเทศ'

@user2: 'เทียบกับ Anessa ไง?'
A: 'Anessa ดี แต่ราคาสูงกว่า + 
ทำสำหรับผู้หญิง.
Maverick = ผู้ชายเฉพาะ'

@user3: 'แพ้ง่าย OK มั้ย?'
A: 'ทดสอบ dermatologist
แต่หากแพ้ — money back'"
```

—————————

**Phase 6: Final Close (80-90 min)**

```
"5 mins left:

Spots remaining: 8 / 30
DM 'SUNSCREEN' to grab

After live:
- Regular price ฿490
- ไม่มี Toner free
- ไม่มี free shipping

Last chance — DM now"
```

—————————

**Phase 7: Wrap (90 min)**

```
"Thank you all!
30 sold tonight 🎉
Admin will DM ทุกคน

Save this LIVE in Story Highlight
Replay 24 hours

Next IG Live: Friday 20:00
Hit Follow + bell"
```

---

### IG LIVE ORDER FLOW (DM-based)

```
Customer DMs: "SUNSCREEN"
↓
Admin auto-reply (or manual):
"Hi! Maverick Sunscreen IG LIVE
฿343 (was ฿490)
+ Free Toner
+ Free shipping

Reply: ชื่อ + เบอร์ + ที่อยู่ + payment"
↓
Customer replies
↓
Admin: "Order confirmed
Pay link: [URL]
Payment 24 hrs ไม่งั้น release spot"
↓
Customer pays
↓
Admin: "Confirmed! Ships tomorrow"
```

---

### IG LIVE SAVE TO STORY

```
After live ends:
- Save to Story (24 hours)
- Pin to Highlight (permanent)

Highlight: "Lives" or "Maverick Live"

Promotes:
- Future replays
- Catch missed lives
- Permanent showcase
```

---

### IG LIVE PRINCIPLES

**Principle 1: Premium positioning**

✅ Higher quality production
✅ Lifestyle-aspirational
- Match Instagram's premium feel

—————————

**Principle 2: Story-driven**

✅ Brand story integrated
✅ Personal touches
- Generic = lower IG engagement

—————————

**Principle 3: Engagement-heavy**

✅ Polls / Q&A / Reactions
✅ Read DMs live
- Algorithm rewards engagement

—————————

**Principle 4: DM-based orders**

✅ "DM the keyword"
✅ Personal conversation
- IG ไม่มี native cart yet

—————————

**Principle 5: Save replays**

✅ Save to Highlight
✅ Replay accessible
- 24-hour Story = limited

---

### IG LIVE METRICS

```
Maverick average:
- Concurrent peak: 30-100
- Total views: 200-800
- DMs received: 50-200
- Orders: 15-40
- Revenue: ฿8,000-25,000
- AOV: ฿500-700 (higher than FB Live)
```

---

### IG LIVE VS FB LIVE VS TIKTOK LIVE

```
IG Live:
- Existing followers
- Premium feel
- DM orders
- Higher AOV
- 4-hour limit

FB Live:
- Mixed warm/cold
- Mass-market
- DM/comment orders
- Mid AOV

TikTok Live:
- Cold reach
- Younger
- Native cart
- Lower AOV but volume
```

---

### COMMON MISTAKES

**❌ Same as FB Live:**
- IG = different audience
- Adjust style premium

**❌ Comment-only ordering:**
- ไม่ scalable on IG
- DM-based better

**❌ Forget save replay:**
- 24-hour Story disappears
- Always Highlight

**❌ ไม่มี Q&A:**
- IG audience love interaction
- Q&A boosts engagement

## Output Format

```
## Instagram Live Selling — [goal]

### Live Flow (7 phases)
1. Greet (0-10)
2. Tease (10-20)
3. Demo (20-40)
4. Pitch (40-60)
5. Q&A (60-80)
6. Final close (80-90)
7. Wrap (90)

### Order Flow
- DM keyword → Admin confirm → Pay link → Confirm

### Principles (5)
1. Premium positioning
2. Story-driven
3. Engagement-heavy
4. DM-based orders
5. Save replays

### Metrics
- 30-100 concurrent / ฿8K-25K revenue typical / Higher AOV

### Common Mistakes
❌ Same as FB ❌ Comments only ❌ Forget save ❌ No Q&A
```

## Constraints

- 60-90 min (4-hour max)
- DM-based orders
- Premium positioning
- Save to Highlight
- Q&A heavy

## Anti-patterns

- ❌ FB Live style on IG
- ❌ Comment-only orders
- ❌ Forget save replay
- ❌ No engagement

## Related Skills

- **facebook-live-selling** — FB
- **tiktok-live-selling** — TikTok

## Memory

- `user.ig_lives` — lives
- `user.ig_live_metrics` — metrics
