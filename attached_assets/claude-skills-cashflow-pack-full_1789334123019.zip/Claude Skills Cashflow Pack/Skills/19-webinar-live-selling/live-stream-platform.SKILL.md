---
name: Live Stream Platform Selection
id: live-stream-platform
category: webinar-live
trigger:
  - "live platform"
  - "streaming platform"
  - "choose live tool"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Platform Specialist — เข้าใจว่า platform = where audience is + features matter → wrong choice = wasted effort

Top platforms: Zoom, FB Live, IG Live, TikTok Live, YouTube Live, LINE Live

## Context

ผู้ใช้คือ creator

## Triggers

- **"which platform"** → choose
- **"live tool"** → tool
- **"streaming software"** → streaming

## Tools

Pure prompt — รับ goal + audience แล้ว recommend

## Task

1. **Match platform to goal**
2. **Compare features**
3. **Cost analysis**
4. **Multi-platform strategy**

## Examples

### PLATFORM SELECTION MATRIX

```
| Platform   | Cold Reach | Warm Audience | Native Cart | AOV    | Best For        |
|------------|------------|---------------|-------------|--------|-----------------|
| Zoom       | None       | Email list    | None        | High   | B2B webinars    |
| FB Live    | Mixed      | Page fans     | DM-based    | Mid    | Mass-market     |
| IG Live    | Followers  | Followers     | DM-based    | High   | Premium brand   |
| TikTok     | High       | New           | Native      | Low    | Volume / discovery |
| YouTube    | High       | Subscribers   | DM/link     | Mid    | Education       |
| LINE Live  | Friends    | Friends       | Link        | Mid    | Thai-specific   |
```

---

### MAVERICK PLATFORM STRATEGY

**Webinar (Course sale ฿4,990):**

```
Platform: Zoom + LINE
- Zoom: Professional feel, registration tracking
- LINE: Promo + reminder + follow-up

Why:
- Higher-priced product needs trust
- Existing audience converts better
- Need detailed registration (email + LINE)

Setup:
- Zoom Pro: ฿800/month
- LINE OA: Already setup
- Landing page: Webflow / Notion
```

—————————

**Live Selling (Product sale ฿390-1,290):**

```
Platform: Facebook Live + LINE Broadcast
- FB Live: Page audience already trust
- LINE: Pre-promote + reminder

Why:
- Lower price = quick decisions
- FB Page = existing customers
- DM-based ordering works fine

Setup:
- FB Page: Free
- Mobile streaming app: Free
- LINE OA: Existing
```

—————————

**Discovery / New Customer:**

```
Platform: TikTok Live
- Algorithm-driven cold reach
- Native shopping integration
- Younger demographic

Why:
- Need new customers
- Lower price products good for cold
- Build TikTok following

Setup:
- TikTok Shop registered
- 1,000+ followers required
- Mobile-first streaming
```

—————————

**Premium Audience:**

```
Platform: Instagram Live
- Followers already premium
- Story/aesthetic-driven
- Higher AOV

Why:
- Existing IG community
- Premium brand positioning
- Higher AOV from quality audience

Setup:
- IG Business account
- Highlights for replays
- DM-based ordering
```

---

### MULTI-PLATFORM STRATEGY

```
Strategy 1: Stream once, multi-platform

Tools:
- Restream.io (~฿800/month)
- StreamYard
- Or vMix Pro

Stream same content to:
- Facebook Live
- YouTube Live
- LINE Live (if compatible)
- Twitter (if relevant)

Pros: Maximum reach
Cons: Complex setup, ไม่ optimize each platform
```

—————————

**Strategy 2: Repurpose**

```
Live on Platform A
Then:
- Cut highlights for TikTok (60s)
- Long version on YouTube
- Stories on IG
- Recap article on blog

Pros: Maximum content from 1 live
Cons: Significant editing time
```

—————————

**Strategy 3: Specialized**

```
Different live for different platforms:

Monday: TikTok Live (cold acquisition)
Wednesday: FB Live (mass-market)
Friday: IG Live (premium engagement)

Pros: Optimized per platform
Cons: 3x effort, 3x prep
```

---

### PLATFORM COST COMPARISON

```
Free options:
- Facebook Live: ฿0
- Instagram Live: ฿0
- TikTok Live: ฿0 (but TikTok takes 5% commission)
- YouTube Live: ฿0
- LINE Live: ฿0

Paid options:
- Zoom: ฿800-3,000/month
- WebinarJam: ฿1,500-3,000/month
- StreamYard: ฿700/month
- Restream: ฿800-2,500/month

For Maverick: ฿800-2,000/month total
- Zoom Pro: ฿800
- Optional: StreamYard ฿700 (multi-platform)
```

---

### PLATFORM PROS & CONS

**Zoom Webinar:**
- ✅ Professional, registration data
- ✅ Q&A panel feature
- ✅ Reliable
- ❌ Paid (฿800+/month)
- ❌ Limited cold reach

**Facebook Live:**
- ✅ Free
- ✅ Existing audience reach
- ✅ Easy DM follow-up
- ❌ Algorithm reach declining
- ❌ Limited features

**Instagram Live:**
- ✅ Free
- ✅ Premium audience
- ✅ Save to Highlight
- ❌ 4-hour limit
- ❌ DM-based orders only

**TikTok Live:**
- ✅ Cold reach
- ✅ Native shopping
- ✅ Algorithm-driven
- ❌ 5% commission
- ❌ Younger audience only

**YouTube Live:**
- ✅ SEO benefit
- ✅ Permanent replay
- ✅ Subscriber notifications
- ❌ Lower live engagement
- ❌ Requires subscribe base

---

### COMMON MISTAKES

**❌ One platform only:**
- Miss audience on others
- Diversify

**❌ Wrong platform for audience:**
- TikTok for ผู้ชาย 50+ = wrong
- Match audience to platform

**❌ Too many platforms:**
- 5 platforms simultaneously
- Quality drops
- Pick 2-3 max

**❌ Pay platform when free works:**
- Spending ฿3K/month
- FB Live free + good enough

## Output Format

```
## Live Stream Platform Selection — [goal]

### Platform Matrix
- Cold reach / Warm / Cart / AOV / Best for

### Platform Strategy by Goal
- Webinar (course): Zoom + LINE
- Live selling (product): FB Live + LINE
- Discovery: TikTok Live
- Premium: IG Live

### Multi-Platform (3 strategies)
1. Stream once, multi-platform (Restream)
2. Repurpose (long → short)
3. Specialized (different per platform)

### Cost Comparison
- Free: FB / IG / TikTok / YouTube / LINE
- Paid: Zoom / StreamYard / WebinarJam

### Common Mistakes
❌ One platform ❌ Wrong audience ❌ Too many ❌ Pay when free works
```

## Constraints

- Match platform to audience
- 2-3 platforms max
- Test free before paid
- Track platform-specific metrics
- Multi-platform for reach

## Anti-patterns

- ❌ Single platform forever
- ❌ Mismatched audience
- ❌ 5+ platforms diluted
- ❌ Pay when free works

## Related Skills

- **facebook-live-selling** — FB
- **tiktok-live-selling** — TikTok
- **instagram-live-selling** — IG

## Memory

- `user.platform_strategy` — strategy
- `user.platform_metrics` — metrics
