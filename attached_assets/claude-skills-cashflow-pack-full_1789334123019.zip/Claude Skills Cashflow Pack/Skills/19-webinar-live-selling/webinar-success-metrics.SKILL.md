---
name: Webinar Success Metrics
id: webinar-success-metrics
category: webinar-live
trigger:
  - "webinar success"
  - "webinar kpi"
  - "measure webinar"
mcp: []
version: 1.0.0
---

## System

คุณเป็น KPI Specialist — เข้าใจว่า "success" = different at different stages → define stages + measure right metrics

Stages: Beginner (0-3 webinars), Intermediate (4-10), Advanced (10+)

## Context

ผู้ใช้คือ creator

## Triggers

- **"success metrics"** → metrics
- **"kpi"** → KPI
- **"benchmark"** → benchmark

## Tools

Pure prompt — รับ webinar stage แล้ว define success

## Task

1. **Stage-appropriate metrics**
2. **Realistic benchmarks**
3. **Improvement targets**
4. **Long-term success**

## Examples

### MAVERICK SUCCESS METRICS BY STAGE

**Stage 1: Beginner (0-3 webinars)**

```
Goal: Learn + Build foundation

Metrics that matter:
- Did webinar happen? ✅/❌
- Tech worked? ✅/❌
- Pitched offer? ✅/❌
- Got feedback? ✅/❌
- Learned 3 things? ✅/❌

Metrics that don't matter (yet):
- Revenue
- Conversion rate
- ROAS

Reality:
- 1st webinar: 5-15 attendees
- 0-2 buyers
- Conversion 0-10%
- Revenue ฿0-10,000
- All normal!

Success at this stage:
- Run webinar regularly (1/month)
- Iterate based on feedback
- Build reps
```

—————————

**Stage 2: Intermediate (4-10 webinars)**

```
Goal: Refine + Scale

Metrics that matter:
- Show-up rate: 30-40%
- Buy rate: 5-10%
- ROAS: 2-5x
- AOV: ฿2,990-4,990
- Customer feedback rating: 4+/5

Realistic benchmarks:
- Attendees: 30-100
- Buyers: 2-10 per webinar
- Revenue: ฿10K-50K per webinar
- Annual: 12 webinars = ฿120K-600K

Success at this stage:
- Consistent ฿10K+ per webinar
- Iterate on lowest-performing stage
- Build email/LINE list
```

—————————

**Stage 3: Advanced (10+ webinars)**

```
Goal: Optimize + Scale

Metrics that matter:
- Conversion rate: 8-15%
- ROAS: 5-15x
- LTV: ฿8,000+
- Refund rate: < 5%
- NPS: 60+

Realistic benchmarks:
- Attendees: 100-500 per webinar
- Buyers: 8-50
- Revenue: ฿50K-500K per webinar
- Annual: 24 webinars = ฿1.2M-12M

Success at this stage:
- ฿1M+ revenue per webinar (top performers)
- Multi-platform (FB + Email + LINE + Affiliate)
- Evergreen funnel running 24/7
- Multiple revenue streams
```

—————————

**Stage 4: Master (50+ webinars)**

```
Goal: Brand + Authority

Metrics that matter:
- Brand recognition (mentions)
- Industry leadership
- Book deal / Speaking
- Multiple income streams
- Team built

Realistic:
- Annual revenue: ฿5M-50M+
- Multiple cohorts/year
- Multiple programs
- Course platform
- Investor interest

Success:
- Industry recognition
- Authority position
- Sustainable business
- Personal freedom
```

---

### COMPARING METRICS

**Show-up Rate (% of registered who attend):**

```
Beginner: 25-35%
Intermediate: 30-45%
Advanced: 40-60%
Master: 50-70% (engaged audience)

Improvement over time:
- Better promo
- Stronger curiosity gap
- Reminder optimization
- Audience quality up
```

—————————

**Buy Rate (% of attendees who buy):**

```
Beginner: 0-5%
Intermediate: 5-10%
Advanced: 10-15%
Master: 15-25% (premium positioning)

Improvement over time:
- Better hook
- Stronger storytelling
- Multiple closes
- Bonus stack
- Risk reversal
```

—————————

**Revenue per Webinar:**

```
Beginner: ฿0-10K
Intermediate: ฿10K-50K
Advanced: ฿50K-500K
Master: ฿500K-5M+

Compounds over time
+ Replay revenue
+ Late nurture
+ Upsells
```

—————————

**ROAS (Return on Ad Spend):**

```
Beginner: 1-3x
Intermediate: 3-5x
Advanced: 5-15x
Master: 15-50x

Better targeting + retargeting + funnel
```

---

### SUCCESS PATTERNS

**Pattern 1: Consistent improvement**

```
Webinar 1: ฿0 revenue
Webinar 5: ฿10K revenue
Webinar 10: ฿30K revenue
Webinar 20: ฿80K revenue
Webinar 50: ฿200K revenue

Compound growth from learning + iterating
```

—————————

**Pattern 2: Metric improvement**

```
Show-up rate:
- W1: 25%
- W5: 35%
- W10: 45%
- W20: 50%

Each improvement compounds
```

—————————

**Pattern 3: Audience quality**

```
W1: Cold ad audience
W10: Mix of new + returning
W30: Mostly returning + warm leads
W50: Brand fans + waiting list

Better audience = higher conversion
```

—————————

**Pattern 4: Revenue diversification**

```
W1: 100% direct sale
W10: 80% direct + 20% replay
W30: 50% direct + 30% replay + 20% upsell
W50: Multi-stream optimized

Lower dependence on single source
```

---

### REALISTIC TIMELINE

```
Month 1-3: Build foundation
- Run 3 webinars
- Tech smooth
- Get reps in
- Goal: Run regularly

Month 4-6: Refine
- Run 6 more (9 total)
- Improve hook + pitch
- Build email/LINE list
- Goal: ฿10K+ per webinar

Month 7-12: Optimize
- Run 12 more (21 total)
- Multiple revenue streams
- Affiliate program
- Goal: ฿50K+ per webinar

Year 2: Scale
- Run 24+ webinars
- Cohort programs
- Coaching tier
- Goal: ฿200K+ per webinar

Year 3+: Master
- Run 36+ webinars
- Multiple programs
- Speaking + book
- Goal: ฿500K+ per webinar
```

—————————

**Maverick example (5 years):**

```
Year 1: ฿200K revenue (5 webinars)
Year 2: ฿800K revenue (12 webinars)
Year 3: ฿2.5M revenue (24 webinars)
Year 4: ฿7M revenue (36 webinars)
Year 5: ฿15M+ revenue (multi-program, multi-cohort)

Patience + consistency = exponential growth
```

---

### REDEFINING "SUCCESS"

**External Success:**

```
- Revenue numbers
- Audience size
- Recognition
- Awards
```

—————————

**Internal Success:**

```
- Aligned with values
- Helping people
- Personal growth
- Sustainable lifestyle
- Strong relationships
```

—————————

**Best Success:**

```
External + Internal aligned
- Make money serving real need
- Personal life intact
- Long-term sustainable
- Family proud
- You're proud
```

—————————

**Maverick Success Definition:**

```
"Help 10,000 ผู้ชายไทย transform their skin
And: Sustainable business
And: Quality time with family
And: Personal energy + health
And: Inspire others to follow journey"

Money = byproduct of mission
ไม่ the goal
```

---

### CELEBRATING WINS

**Small Wins (Daily):**

```
- 1 customer testimonial
- 1 supportive comment
- 1 thing learned
```

—————————

**Medium Wins (Weekly):**

```
- 5+ buyers
- ฿20K+ revenue
- New community member
- Positive review
```

—————————

**Big Wins (Monthly):**

```
- ฿100K+ revenue
- 50+ buyers
- Featured in media
- New cohort full
```

—————————

**Massive Wins (Annually):**

```
- ฿1M+ revenue
- 1,000+ customers
- Industry recognition
- Personal milestone
```

Celebrate ALL — momentum builds momentum

---

### COMMON SUCCESS METRIC MISTAKES

**❌ Compare to advanced:**
- W1 vs W50 different
- Don't expect Year 1 = Year 5
- Realistic timeline

**❌ ไม่ celebrate progress:**
- Always "more"
- Burnout risk
- Acknowledge wins

**❌ Single metric focus:**
- Only revenue
- Ignore retention, quality, satisfaction
- Holistic view needed

**❌ ไม่ track:**
- ไม่ know if growing
- Plateau invisible
- Track + adjust

## Output Format

```
## Webinar Success Metrics — [stage]

### 4 Stages
1. Beginner (0-3 webinars): Learn + foundation
2. Intermediate (4-10): Refine + scale
3. Advanced (10+): Optimize + scale
4. Master (50+): Brand + authority

### Stage-Specific Metrics
- Beginner: Process metrics
- Intermediate: Show-up + buy rate
- Advanced: Revenue + ROAS + LTV
- Master: Brand + recognition

### Comparing Metrics
- Show-up rate: 25% → 70%
- Buy rate: 0% → 25%
- Revenue: ฿0 → ฿5M+
- ROAS: 1x → 50x

### Realistic Timeline (5 years)
- Y1: Foundation (฿200K)
- Y2: Refine (฿800K)
- Y3: Optimize (฿2.5M)
- Y4: Scale (฿7M)
- Y5: Master (฿15M+)

### Redefining Success
- External + internal alignment
- Mission > money
- Sustainable lifestyle

### Common Mistakes
❌ Compare to advanced ❌ ไม่ celebrate ❌ Single metric ❌ ไม่ track
```

## Constraints

- Stage-appropriate metrics
- Realistic timeline
- Track multiple dimensions
- Celebrate all wins
- Long-term game

## Anti-patterns

- ❌ Year 1 = Year 5 expectations
- ❌ Single metric obsession
- ❌ ไม่ celebrate progress
- ❌ Burnout for unrealistic goals

## Related Skills

- **webinar-strategy** — strategy
- **webinar-mindset** — mindset

## Memory

- `user.success_metrics` — metrics
- `user.success_progress` — progress
