---
name: Webinar Conversion Optimization
id: webinar-conversion-optimization
category: webinar-live
trigger:
  - "webinar conversion"
  - "increase conversion"
  - "optimize webinar"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Conversion Optimizer — เข้าใจว่า small improvements ที่ multiple stages = big revenue lift

Stages with optimization potential: Landing page, Show-up rate, Buy rate, Order value

## Context

ผู้ใช้คือ marketer

## Triggers

- **"optimize"** → optimize
- **"increase conversion"** → increase
- **"improve webinar"** → improve

## Tools

Pure prompt — รับ webinar metrics แล้ว optimize

## Task

1. **Audit current funnel**
2. **Identify weakest stages**
3. **Test improvements**
4. **Measure lift**

## Examples

### MAVERICK WEBINAR FUNNEL AUDIT

**Current Performance:**

```
Stage 1: Ad CTR
- 1.5% (industry: 1-3%)
- Status: Average

Stage 2: Landing Page Conversion
- 22% (target: 30%+)
- Status: WEAK ⚠️

Stage 3: Show-up Rate
- 35% (target: 40-50%)
- Status: WEAK ⚠️

Stage 4: Live Buy Rate
- 8% (target: 10%+)
- Status: WEAK ⚠️

Stage 5: Replay Buy Rate
- 4% (target: 5%+)
- Status: Average

Stage 6: Order Value (AOV)
- ฿4,990 (single tier)
- Opportunity: Add upsell

Total revenue per ฿1,000 ad spend:
- Currently: ฿15,000 (15x ROAS)
- Potential: ฿28,000 (28x ROAS)
```

—————————

**Highest Impact Improvements:**

```
Priority 1: Landing Page (22% → 35% = +59%)
Priority 2: Show-up Rate (35% → 50% = +43%)
Priority 3: Buy Rate (8% → 12% = +50%)
Priority 4: Add Upsell (฿4,990 → ฿5,990 AOV = +20%)

Compound: 1.59 × 1.43 × 1.50 × 1.20 = 4.1x revenue
```

---

### LANDING PAGE OPTIMIZATION

**Test 1: Headline**

```
A: "3 ขั้นตอน Skincare ผู้ชายไทย"
B: "ผิวชุ่มชื้น ไม่มัน — 30 Day Method"
C: "เปลี่ยนผิวมัน → ผิวสะอาด ใน 30 วัน"

Winner test:
B got 38% conversion (vs A 22%)
Specific outcome > generic

Apply: B + variations
```

—————————

**Test 2: Above-fold CTA**

```
A: "Reserve Your Spot"
B: "Yes! Save My Spot Free"
C: "Get Free Webinar Access"

Winner: B (44% click-through)
Active language wins
```

—————————

**Test 3: Form fields**

```
A: Name + Email + Phone (3 fields)
B: Email only (1 field)
C: Email + LINE ID (2 fields)

Winner: B (54% conversion)
Less friction = more signups

Apply: Email only minimum
```

—————————

**Test 4: Social proof position**

```
A: Testimonials at bottom
B: Testimonials right after headline
C: Floating testimonials (sticky)

Winner: B (35% conversion)
Trust early in journey
```

—————————

**Test 5: Bonus list**

```
A: Plain text bonuses
B: Bullet bonuses with prices
C: Bonuses table with crossed-out values

Winner: C (38% conversion)
Visual + price stacking wins
```

---

### SHOW-UP RATE OPTIMIZATION

**Test 1: Reminder frequency**

```
A: 1 reminder (day before)
B: 3 reminders (-3 days, -1 day, day-of)
C: 5 reminders (-3 days, -1 day, morning, 2hrs, 30 mins)

Winner: C (52% show-up)
More reminders = better
But diminishing returns at 5+
```

—————————

**Test 2: Calendar invite**

```
A: No calendar invite
B: Auto-add to Google Calendar
C: Manual download .ics file

Winner: B (48% show-up)
Frictionless = compliance
```

—————————

**Test 3: Pre-webinar value**

```
A: Just reminder emails
B: Pre-webinar PDF/video
C: Pre-webinar cohort discussion

Winner: C (55% show-up)
Pre-engagement = commitment
```

—————————

**Test 4: SMS reminders**

```
A: Email only
B: Email + LINE
C: Email + LINE + SMS

Winner: C (58% show-up)
Multi-channel = max coverage
```

---

### LIVE WEBINAR OPTIMIZATION

**Test 1: Hook strength**

```
A: "Welcome to webinar"
B: "Tonight: 1 thing 99% ของผู้ชายไทย ไม่รู้"
C: "If you've struggled with skin... this is for you"

Winner: B (audience stays 78%)
Curiosity gap = retention
```

—————————

**Test 2: Time to first poll**

```
A: First poll at 15 mins
B: First poll at 5 mins
C: First poll at 2 mins

Winner: C (avg watch time 65 mins)
Early engagement = stays longer
```

—————————

**Test 3: Bonus stack order**

```
A: Reveal bonuses → Then price
B: Price first → Then bonuses
C: Bonus 1 → Price → Bonus 2 → Bonus 3

Winner: A (12% buy rate)
Bonus pile reduces price shock
```

—————————

**Test 4: Number of closes**

```
A: 1 close (end only)
B: 3 closes (50, 70, 85 mins)
C: 5 closes (every 15 mins)

Winner: B (10% buy rate)
3 closes optimal
5 = audience overwhelmed
```

—————————

**Test 5: Q&A handling**

```
A: Q&A at end only
B: Q&A throughout
C: Hybrid (Q&A in pitch + end)

Winner: C (15% buy rate)
Address objections in moment + final
```

---

### POST-WEBINAR OPTIMIZATION

**Test 1: Replay window**

```
A: 7 days replay
B: 5 days replay
C: 3 days replay

Winner: C (8% replay buy rate)
Shorter window = more urgency
But too short loses laggards

Optimal: 5 days
```

—————————

**Test 2: Late nurture frequency**

```
A: 1 email day after
B: 3 emails over 7 days
C: 7 emails over 14 days

Winner: B (14% additional buyers)
3-7 emails sweet spot
14+ = unsubscribe
```

—————————

**Test 3: Bonus removal timing**

```
A: Bonuses available always
B: Bonuses end 5 days after live
C: Bonuses end 3 days after live

Winner: B
Aligns with replay window
Creates urgency without too short
```

---

### CONVERSION OPTIMIZATION PRINCIPLES

**Principle 1: Test biggest leverage**

✅ Landing page (22% → 35%) = +59% lift
✅ Other stages 1.4x lift compound
- Don't optimize lowest-impact stage first

—————————

**Principle 2: Test 1 thing**

✅ Same audience, same setup
✅ Change only headline
- Multi-test = ไม่ know what worked

—————————

**Principle 3: Significance threshold**

✅ Min 100 visitors per variant
✅ 95%+ confidence
- 30 visitors = noise

—————————

**Principle 4: Apply learnings**

✅ Winner becomes new control
✅ Test next variable
- Set + forget = stagnant

—————————

**Principle 5: Document everything**

✅ Test bank: variable, hypothesis, result
✅ Build playbook
- Memory loss = repeat tests

---

### CONVERSION OPTIMIZATION STACK

```
A/B Test Tools:
- Google Optimize: Free
- VWO: ฿3,000+/month
- Convertkit Tests: Built-in

Analytics:
- Google Analytics: Free
- Mixpanel: Free + paid
- Hotjar: ฿1,500/month (heatmaps)

Goal Tracking:
- GA4 events
- Facebook Pixel
- Custom conversions

Recommended:
- GA + Pixel + Hotjar
- ฿1,500/month total
- ROI: 5-10x from optimization
```

---

### COMMON MISTAKES

**❌ Optimize wrong stage:**
- Tweak emails when LP conversion is 5%
- Fix biggest leak first

**❌ Insufficient sample:**
- 50 visitors
- Random noise

**❌ Test multiple variables:**
- Headline + image + form together
- Don't know what worked

**❌ ไม่ apply winners:**
- Run tests, ignore results
- Wasted effort

## Output Format

```
## Webinar Conversion Optimization — [funnel]

### Funnel Audit
- Each stage conversion rate
- Weakest stages identified
- Compound improvement potential

### Optimization Areas
1. Landing page (5 tests)
2. Show-up rate (4 tests)
3. Live webinar (5 tests)
4. Post-webinar (3 tests)

### Highest Impact Tests
- Landing page headline
- Form field reduction
- Reminder frequency
- Hook strength
- Number of closes

### Principles (5)
1. Test biggest leverage
2. Test 1 thing
3. Significance threshold
4. Apply learnings
5. Document everything

### Common Mistakes
❌ Wrong stage ❌ Small sample ❌ Multi-variable ❌ ไม่ apply
```

## Constraints

- Test biggest leverage stages
- 1 variable per test
- 100+ visitors per variant
- 95% confidence
- Document all tests

## Anti-patterns

- ❌ Tweak minor variables
- ❌ Tiny sample sizes
- ❌ Multi-variable confused
- ❌ Forget to apply winners

## Related Skills

- **webinar-funnel** — funnel
- **ab-test-designer** — A/B

## Memory

- `user.optimization_tests` — tests
- `user.optimization_lift` — lift
