---
name: TikTok Live Selling
id: tiktok-live-selling
category: webinar-live
trigger:
  - "tiktok live selling"
  - "tiktok shop live"
  - "tiktok ขายของ"
mcp: []
version: 1.0.0
---

## System

คุณเป็น TikTok Live Pro — เข้าใจว่า TikTok Live = highest growth live commerce platform → algorithm-driven cold reach + younger audience

Best for: New customer acquisition, viral products, lower price (฿200-฿1,500)

## Context

ผู้ใช้คือ TikTok seller

## Triggers

- **"tiktok live"** → TikTok live
- **"tiktok shop"** → TikTok Shop
- **"live tiktok"** → live tiktok

## Tools

Pure prompt — รับ TikTok live goal แล้ว design

## Task

1. **Setup TikTok Shop**
2. **Live execution**
3. **Algorithm optimization**
4. **Track + scale**

## Examples

### MAVERICK TIKTOK LIVE STRATEGY

**Pre-Live Setup:**

```
Requirements:
- TikTok Shop registered (TT Seller Center)
- Products approved
- Live access enabled (1,000+ followers)

Equipment:
- iPhone/Android with good camera
- Ring light
- External mic
- Tripod
- Products visible
```

---

### TIKTOK ALGORITHM OPTIMIZATION

```
Algorithm rewards:
✅ Concurrent viewers (high)
✅ Watch time (avg minutes)
✅ Engagement (likes, comments, shares)
✅ Conversion (orders during live)
✅ Repeat viewers

Therefore:
- First 5 mins = critical (warm-up fast)
- Engagement prompts every 2 mins
- Visible product demos
- Live orders create signals
```

---

### TIKTOK LIVE FLOW (60-120 min)

**Phase 1: Hook (0-5 min)**

```
"Hi! Maverick TikTok LIVE!
ผู้ชายมาคุยกับครูเอ็ม

Tonight: 
- Free Maverick samples (first 100)
- Live deals 50% off
- Skincare tips

Hi to everyone joining! 
ใครจอยมา ใครเป็น first time?"

[Algorithm boost first 5 mins]
```

—————————

**Phase 2: Education + Demo (5-30 min)**

```
"ผู้ชายไทยมีปัญหาอะไรกับผิว?
Comment ทันที!

[Read comments]
'ผิวมัน' 'สิว' 'รูขุมขน'

OK — Today's product:
Maverick Reset

[Demo on hand]

Niacinamide 5%
- ลดความมัน
- ปรับรูขุมขน
- ผู้ชายไทยเหมาะ

LIVE price: ฿390 (ปกติ ฿590)
TikTok Shop link active

[Tap Yellow Cart Icon]"
```

—————————

**Phase 3: Order Push (30-90 min)**

```
"จำนวน: 50 ขวดเท่านั้น live นี้

Tap yellow cart → Add → Checkout
ส่งฟรี ทุก order

[Watch live order count]
'5 sold... 12 sold... 25 sold!'

Live testimonials:
@user1 ซื้อแล้ว — ขอบคุณ!
@user2 also bought — welcome!

Bundle (3 ตัว) ลด 50%:
฿1,470 → ฿730
Tap cart bundle"
```

—————————

**Phase 4: Last Push (90-110 min)**

```
"Last 30 mins!
ตัวเลข live:
- 80 sold today
- 35 spots left

ใครยังไม่ตัดสินใจ?
After tonight:
- Regular price
- ไม่มี bundle deal

[Tap Cart]"
```

—————————

**Phase 5: Wrap (110-120 min)**

```
"Thanks for joining!
Total: 100+ orders today

Order processing tomorrow
ส่งภายใน 2 days

Follow @maverickskin for next live
Hit follow + bell"
```

---

### TIKTOK SHOP INTEGRATION

```
Native shopping:
- Yellow cart icon during live
- Tap = add to cart
- Checkout in TikTok app
- Pay via TikTok Pay / COD / Bank

Conversion: 3-8% of viewers (vs 1-2% off-platform)

Commission: TikTok takes 5%
Worth it for cold reach + native UX
```

---

### TIKTOK LIVE METRICS

```
Maverick average:
- Concurrent peak: 100-300
- Total views: 1,000-3,000
- Comments: 500-1,500
- Orders: 50-150
- Revenue: ฿20,000-80,000
- TikTok commission: ฿1,000-4,000

Top performers (viral):
- Concurrent peak: 1,000-3,000
- Revenue: ฿200,000-500,000
```

---

### TIKTOK LIVE TACTICS

**Tactic 1: Repeat hook**

```
Every 5-10 mins, repeat hook:
"For new joiners — tonight Maverick LIVE
50% off, free samples first 100"

Cold viewers join continuously
ไม่ assume context
```

—————————

**Tactic 2: Comment engagement**

```
"Comment 'YES' if you have oily skin"
"Comment '1' if you're using serum"
"Comment '🔥' for the deal"

Algorithm sees engagement
Boosts to more cold audience
```

—————————

**Tactic 3: Affiliate collab**

```
Invite TikTok creators (5K-50K followers)
- Co-host live
- Cross-promote audiences
- Split commission

Reach +200-500%
```

—————————

**Tactic 4: Lengthy lives**

```
2+ hour lives = better algorithm signal
- Multiple discovery waves
- More cold audience reached

ไม่ short 30-min lives
```

---

### TIKTOK LIVE VS FB LIVE

```
TikTok Live:
- Cold reach (algorithm)
- Younger audience (16-30)
- Native cart
- Lower trust (need stronger pitch)

FB Live:
- Warm reach (existing followers)
- Older audience (25-50)
- DM-based orders
- Higher trust (existing relationship)

Strategy:
- Use BOTH for full coverage
```

---

### COMMON MISTAKES

**❌ Short lives:**
- 30 mins
- ไม่ enough algorithm signal

**❌ ไม่มี yellow cart:**
- Manual DM orders
- High friction
- Lower conversion

**❌ ไม่ engage comments:**
- One-way broadcast
- ไม่มี algorithm boost

**❌ Same product entire live:**
- Boring
- Mix 3-5 products

## Output Format

```
## TikTok Live Selling — [goal]

### Setup Requirements
- TikTok Shop / 1K followers / Products approved

### Live Flow (5 phases)
1. Hook (0-5)
2. Education + demo (5-30)
3. Order push (30-90)
4. Last push (90-110)
5. Wrap (110-120)

### Algorithm Optimization
- 5-min hook critical
- Engagement every 2 mins
- Live orders create signals

### Tactics (4)
1. Repeat hook
2. Comment engagement
3. Affiliate collab
4. Lengthy lives (2+ hours)

### Metrics
- 100-300 concurrent / ฿20K-80K revenue typical

### Common Mistakes
❌ Short lives ❌ No cart ❌ No engagement ❌ Single product
```

## Constraints

- 60-120 min sessions
- Use TikTok Shop yellow cart
- Engagement every 2 mins
- Multiple products (3-5)
- Repeat hook for new viewers

## Anti-patterns

- ❌ Short 30-min lives
- ❌ Off-platform orders
- ❌ Static delivery
- ❌ Single product only

## Related Skills

- **live-selling-tactics** — tactics
- **facebook-live-selling** — FB live

## Memory

- `user.tiktok_lives` — lives
- `user.tiktok_metrics` — metrics
