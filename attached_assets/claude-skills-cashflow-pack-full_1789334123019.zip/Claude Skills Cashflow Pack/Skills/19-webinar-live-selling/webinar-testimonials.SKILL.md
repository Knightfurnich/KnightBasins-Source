---
name: Webinar Testimonials
id: webinar-testimonials
category: webinar-live
trigger:
  - "webinar testimonials"
  - "course testimonials"
  - "social proof"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Testimonial Specialist — เข้าใจว่า testimonials = strongest social proof → 5 great testimonials = ฿millions in incremental sales

Types: Before/After, Video, Written, Specific Outcome, Founder Story

## Context

ผู้ใช้คือ creator

## Triggers

- **"testimonial"** → testimonial
- **"social proof"** → social proof
- **"reviews"** → reviews

## Tools

Pure prompt — รับ goal แล้ว design testimonial strategy

## Task

1. **Collect testimonials**
2. **Format properly**
3. **Use strategically**
4. **Track impact**

## Examples

### MAVERICK TESTIMONIAL TYPES

**Type 1: Before/After Photo Testimonial**

```
[Photo: ปอ Day 0 vs Day 30]

"From oily skin + 10 acne to clear skin in 30 days.
ลองทุก product มา 5 ปี
Maverick course = first thing that worked
ครูเอ็มเก่งมาก ขอบคุณครับ"

— ปอ, อายุ 28, Bangkok
Engineer, Maverick Cohort 3

Effect:
- Visual proof
- Specific timeframe
- Real name + age + city
- Specifies background
```

—————————

**Type 2: Video Testimonial (60-90 seconds)**

```
ปอ on camera:
"สวัสดีครับ ผมปอ engineer 28 ปี

[Show face — clear skin]

3 เดือนก่อน:
- ผิวมันมาก
- สิว 10+ ทุกวัน
- ไม่กล้าออกไปเที่ยวกลางวัน

ตอนนี้ post 30 วัน Maverick course:
- ผิวดี
- ไม่มีสิว
- Confidence กลับมา

Course ราคา ฿4,990
Worth every Baht
ลองได้ — money-back guarantee

ผมขอบคุณครูเอ็มมากๆ"

[Show before photo + after photo overlay]

Effect:
- Voice + face = max trust
- Specific story
- Real journey
- Recommends with confidence
```

—————————

**Type 3: Written Testimonial (Detailed)**

```
"I'm posting this from genuine gratitude.

Background:
- Age 28, engineer in Bangkok
- 10 years of skincare struggles
- Spent ฿20,000+ on failed products
- Skeptical of all 'solutions'

Before:
- Daily acne, cystic
- Oily face within 1 hour
- Embarrassed in meetings

Bought Maverick Course (skeptical):
Week 1: Saw 30% improvement
Week 2: Less oily
Week 3: New acne nearly stopped
Week 4: Old marks fading

Today (Day 30):
- Clear skin
- Confident
- People comment ผิวดี

What worked:
- Specific to ผู้ชายไทย
- Niacinamide protocol
- Step-by-step
- Community support
- ครูเอ็ม personal accessibility

Worth: ฿4,990 = best ฿ I've spent on skincare

ขอบคุณ Maverick"

— ปอ, อายุ 28
Engineer, Bangkok

Effect:
- Detailed = high credibility
- Specific numbers
- Story arc
- Identifies what worked
```

—————————

**Type 4: Specific Outcome**

```
"Dropped 80% of my acne in 30 days
- ครูเอ็ม personally helped me
- No false promises
- Real systematic approach
- Continue using daily

— ปอ, อายุ 28
Bangkok engineer"

Effect:
- Quantified result (80%)
- Specific timeframe
- Specifies founder involvement
```

—————————

**Type 5: Different Demographic**

```
[Photo: 50-year-old man]

"Aged 52, Maverick changed my routine.

Different concern at my age:
- Wrinkles
- Dehydration
- Sun damage

Course adapted for older skin:
- Hydration focus
- Sensitive approach
- Anti-aging tips

Result: Younger-looking skin in 8 weeks

— อาจารย์สมชาย, อายุ 52
Bangkok University

Effect:
- Different demographic = broader appeal
- Specific concerns addressed
- Authority figure (Aor)"
```

---

### COLLECTING TESTIMONIALS

**Method 1: Day 30 Email Request**

```
Subject: 🎁 ฿200 voucher for your testimonial

สวัสดีครับ คุณ [Name]

ขอบคุณที่ complete Maverick course

Your transformation = inspires others
Help me share your story?

If yes:
🎁 ฿200 voucher for your time
📸 Day 0 photo (if you took)
📸 Day 30 photo (now)
✏️ Quick written: 100-300 words

Reply this email with photos + words

— ครูเอ็ม
```

—————————

**Method 2: Video Testimonial Requests**

```
"Maverick is recording video stories!

Top 5 best stories =
- ฿1,000 voucher
- Featured on website
- Founder thank you note

If interested:
- Record 60-90 secs on phone
- Show face + share story
- Send via Drive link

Email: [video URL]

— ครูเอ็ม"

Effect:
- Higher rewards = better video quality
- Selection process
- Featured = social benefit
```

—————————

**Method 3: Live Capture During Course**

```
During group calls:
"Anyone seeing big results?
Share + I'll feature you"

Capture:
- Live testimonials
- Real-time reactions
- Authentic enthusiasm

Use:
- For replays
- Social media
- Future webinars
```

—————————

**Method 4: Customer Success Stories Series**

```
Monthly: Featured Customer of the Month

Profile in detail:
- Background story
- Transformation journey
- What they learned
- Photos + video
- Their advice for others

Effect:
- Long-form content
- Multiple-use asset
- Customer feels valued
```

---

### TESTIMONIAL FORMATTING

**Visual Elements:**

```
✅ Photo (face = trust)
✅ Name + Age + City + Profession
✅ Before/After (when relevant)
✅ Direct quote
✅ Specific outcome metric

❌ Stock photo
❌ Vague "Customer"
❌ No specifics
❌ Generic "Great course!"
```

—————————

**Format Examples:**

**Short:**

```
"30 days. Clear skin. Worth it."

— ปอ, 28
Bangkok engineer

[Photo]
```

**Medium:**

```
"3 weeks of Maverick = result I couldn't get from 5 years of trial.

Niacinamide approach is real.
Course covers what needed.
Community supported me through.

Best ฿4,990 I've spent on skincare."

— ปอ, อายุ 28
Bangkok engineer
Maverick Cohort 3 (Mar 2026)
```

**Long (Featured Story):**

[Use Type 3 detailed example]

---

### USING TESTIMONIALS STRATEGICALLY

**Use 1: Webinar (Authority Phase)**

```
"Let me share results from past students:"

[Show 5 testimonials in 30 seconds]
- ปอ: 80% acne reduction
- อาจารย์สมชาย: anti-aging
- ดร. Chen: dermatologist endorsement
- เอ็ม: doubled confidence
- จิม: 30 days transformation

Effect:
- Authority before pitch
- Diverse demographics shown
- Trust built
```

—————————

**Use 2: Landing Page**

```
Above-fold:
- 3 starred reviews
- 1 photo testimonial
- 1 video testimonial preview

Below-fold:
- Detailed customer stories
- Stat: "3,000+ students"
```

—————————

**Use 3: Social Media**

```
Weekly testimonial posts:
- Tuesday: Customer story IG
- Thursday: Video testimonial Reel
- Saturday: Before/After post

Effect:
- Daily social proof
- Builds reputation
- Cold audience sees results
```

—————————

**Use 4: Email Sequence**

```
Day 3 of nurture:
"Real customer story:
[Insert ปอ's story]
This could be you"

Builds anticipation
```

—————————

**Use 5: Sales Pitch**

```
During pitch:
"You might think:
'Will this work for me?'

Listen to ปอ — same story:
[Read his testimonial]"

Address objection with testimonial
```

---

### TESTIMONIAL IMPACT METRICS

```
A/B Test: With vs Without Testimonials

Without:
- Landing page conversion: 22%
- Webinar buy rate: 7%

With (added 5 testimonials):
- Landing page conversion: 35%
- Webinar buy rate: 12%

Lift: +59% landing / +71% buy
Annual revenue impact: +฿2M+
```

—————————

**Best testimonial impact:**

```
Test: Single best testimonial
Result: +25% buy rate

Test: 3 testimonials
Result: +35% buy rate

Test: 5 testimonials
Result: +40% buy rate

Test: 10 testimonials
Result: +42% buy rate

Diminishing returns at 5
Optimal: 3-5 best
```

---

### TESTIMONIAL PRINCIPLES

**Principle 1: Real names + faces**

✅ Real photo
✅ Real name
✅ Real city/profession
- Generic = doubt

—————————

**Principle 2: Specific outcomes**

✅ Numbers, dates, percentages
- "80% acne reduction in 30 days"
- ไม่ "felt better"

—————————

**Principle 3: Before/After visible**

✅ Photos when possible
✅ Side-by-side comparison
- Words alone = lower trust

—————————

**Principle 4: Story arc**

✅ Background → Problem → Solution → Result
- Generic = forgettable

—————————

**Principle 5: Diverse demographics**

✅ Different ages, jobs, concerns
- Single demographic = limited appeal

—————————

**Principle 6: Authentic > Polished**

✅ Real customer voice
✅ Some imperfections OK
- Too polished = ไม่ believable

---

### COMMON TESTIMONIAL MISTAKES

**❌ Stock photos:**
- Recognizable
- Trust destroyed

**❌ Generic quotes:**
- "Best course ever!"
- ไม่ specific

**❌ No demographics:**
- "Customer"
- ไม่ relatable

**❌ Same demographic:**
- All 25-year-olds
- Limited appeal

**❌ ไม่ refresh:**
- 2-year-old testimonials
- Outdated

**❌ Pay for fake:**
- Bot/paid testimonials
- Detected easily
- Brand killer

## Output Format

```
## Webinar Testimonials — [goal]

### Testimonial Types (5)
1. Before/After photo
2. Video (60-90 secs)
3. Written detailed
4. Specific outcome
5. Different demographic

### Collection Methods (4)
1. Day 30 email
2. Video request (rewards)
3. Live capture during course
4. Featured customer series

### Strategic Use (5)
1. Webinar authority
2. Landing page
3. Social media
4. Email sequence
5. Sales pitch

### Impact Metrics
- +59% landing / +71% buy rate
- 5 testimonials = optimal

### Principles (6)
1. Real names + faces
2. Specific outcomes
3. Before/After visible
4. Story arc
5. Diverse demographics
6. Authentic > Polished

### Common Mistakes
❌ Stock photos ❌ Generic ❌ No demographics ❌ Same type ❌ ไม่ refresh ❌ Fake
```

## Constraints

- Real customer names
- Photos when possible
- Specific outcomes
- 3-5 per pitch
- Refresh annually

## Anti-patterns

- ❌ Stock photos
- ❌ Generic quotes
- ❌ No demographics
- ❌ Single type
- ❌ Fake testimonials

## Related Skills

- **webinar-strategy** — strategy
- **social-proof-strategy** — proof

## Memory

- `user.testimonials` — testimonials
- `user.testimonial_impact` — impact
