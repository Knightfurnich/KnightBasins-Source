---
name: Webinar Recording
id: webinar-recording
category: webinar-live
trigger:
  - "webinar recording"
  - "record live"
  - "save webinar"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Recording Specialist — เข้าใจว่า recording = asset to monetize forever → 1 webinar = many uses

Uses: Replay, Evergreen, Course content, Social clips, Podcast

## Context

ผู้ใช้คือ creator

## Triggers

- **"recording"** → recording
- **"save webinar"** → save
- **"webinar replay"** → replay

## Tools

Pure prompt — รับ recording goal แล้ว plan

## Task

1. **Recording setup**
2. **Editing for replay**
3. **Repurposing strategy**
4. **Storage + access**

## Examples

### MAVERICK RECORDING SETUP

**Recording Settings:**

```
Resolution: 1080p (HD minimum)
Frame rate: 30fps
Audio: 48kHz, 320kbps stereo
File format: MP4 (H.264)
Recording mode: Cloud + Local backup

Recommended:
- Zoom Cloud Recording (auto)
- Local backup (computer)
- StreamYard (browser-based)
- OBS recording (advanced)
```

—————————

**Pre-Live Recording Checklist:**

```
□ Confirm recording is enabled
□ Test recording quality (5-min test before live)
□ Check storage space (1080p = ~1GB/hour)
□ Set automatic recording start
□ Cloud backup activated
□ Confirm recording layouts (gallery vs speaker view)
```

—————————

**During Live:**

```
- Recording starts automatically
- ไม่ pause/stop accidentally
- Verify red recording indicator
- ถ้า issues: Restart recording, note timestamp
```

—————————

**Post-Live:**

```
- Save to Cloud (Zoom auto)
- Backup to Google Drive (or external)
- Backup to YouTube unlisted
- Download MP4 (raw)
- Save edited version
- 3 backups minimum
```

---

### EDITING FOR REPLAY

**Edit 1: Trim and Clean (5-10% time savings)**

```
Remove:
- 5 mins waiting for crowd
- "Checking sound..."
- Long pauses (Reset awkward silence)
- Off-topic moments

Keep:
- All content
- Q&A
- Pitch
- Engagement moments

Tools:
- iMovie (free Mac)
- DaVinci Resolve (free)
- CapCut (free, easier)
- Adobe Premiere (paid)
```

—————————

**Edit 2: Add Polish**

```
- Lower thirds (your name, title)
- Brand intro/outro animation
- Background music (low volume in pitch)
- Captions/subtitles (auto-generated then verify)
- Chapter markers (timestamps for sections)

Effect:
- Looks more professional
- Easier to navigate
- Higher perceived value
```

—————————

**Edit 3: Optimize for Replay Page**

```
- Add countdown overlay (replay closing)
- Add buy CTAs at strategic points
- Highlight key learnings
- Bonus content for replay viewers

Tools:
- Wistia/Vimeo: Smart calls-to-action
- YouTube: End screens + cards
```

---

### REPURPOSING STRATEGY

**Asset 1: Full Webinar Replay (90 mins)**

```
Use: Replay page, Email funnel
Platform: Wistia (paid) or YouTube unlisted
Access: Time-limited (5-7 days)
Goal: Late conversions
Revenue: 30-40% of webinar revenue
```

—————————

**Asset 2: Course Material (Modular)**

```
Cut into 30 lessons:
- 5-15 mins each
- Specific topic per lesson
- Add intro/outro per lesson

Use: 30-day course content
Goal: Course backbone
Save 30+ hours of new recording
```

—————————

**Asset 3: Short Clips (60 secs)**

```
Cut highlights:
- "1 ขั้นตอน Skincare"
- "Niacinamide explained"
- "Founder story 60 secs"

Use:
- TikTok / IG Reels
- YouTube Shorts
- Twitter videos

Goal: Top of funnel content
1 webinar = 30+ short clips
```

—————————

**Asset 4: Audio (Podcast)**

```
Strip audio from video:
- Convert to MP3
- Add intro/outro
- Upload to Apple Podcasts, Spotify

Use: Audio-first audience
Goal: New audience reach
1 webinar = 90 min episode
```

—————————

**Asset 5: Blog/Article**

```
Transcribe webinar:
- Tools: Otter.ai, Rev.com
- Edit for written format
- Add headers, formatting
- Publish on blog

Use: SEO traffic
Goal: Long-term organic
1 webinar = 5,000+ word article
```

—————————

**Asset 6: Social Quote Posts**

```
Identify key quotes:
- "ผิวมัน ≠ Bad genetics"
- "3 ขั้นตอน = Lifetime healthy skin"

Design as quote cards:
- IG post / Pinterest
- Tag in tweets

Use: Daily content
1 webinar = 20+ quote posts
```

---

### REPURPOSING ECONOMICS

```
1 Webinar (90 mins recording)

Direct revenue:
- Live webinar sales: ฿200,000
- Replay sales: ฿100,000
- Late nurture: ฿50,000

Repurposed revenue:
- Course backbone: Saves 30 hours = ฿15,000 value
- Short clips: 30 × engagement
- Article: 5,000 SEO visits/month × 12 months
- Podcast: 1,000 downloads/episode

Total value from 1 webinar: ฿500,000+

ไม่ repurpose = leave ฿200,000+ on table
```

---

### STORAGE + ACCESS STRATEGY

```
Storage Tiers:

Tier 1: Original Raw (3 backups)
- Local hard drive
- Cloud backup (Google Drive)
- Cold storage (S3 Glacier)

Tier 2: Edited Versions
- Replay page (Wistia/Vimeo)
- Course platform (Teachable/Kajabi)
- YouTube unlisted

Tier 3: Distributed
- TikTok / IG / YouTube (public)
- Podcast (Apple/Spotify)
- Blog (website)

Access:
- Replay: Limited 5-7 days
- Course: Lifetime (paid)
- Public: Always available
```

—————————

**Tools + Costs:**

```
- Zoom Cloud: ฿800/month (storage + recording)
- Wistia: ฿2,500/month (replay platform)
- Vimeo Pro: ฿700/month (alternative)
- Google Drive: ฿70-700/month
- Teachable: ฿1,200-3,500/month (course)

Total: ฿3,000-7,500/month
ROI: Easy (compared to ฿500K+ value)
```

---

### RECORDING PRINCIPLES

**Principle 1: Multiple backups**

✅ Local + Cloud + External
- 1 backup = single point of failure

—————————

**Principle 2: Repurpose maximum**

✅ Each recording = 5-10 outputs
✅ Different formats for different audiences
- 1 use = waste

—————————

**Principle 3: Edit for replay**

✅ Remove dead time
✅ Add polish
✅ Keep core content
- Raw = lower replay viewing

—————————

**Principle 4: Track replay metrics**

✅ Watch percentage
✅ Drop-off points
✅ Conversion rate
- Optimize based on data

—————————

**Principle 5: Asset library**

✅ Organize by topic + format
✅ Searchable
- Random folder = waste

---

### COMMON MISTAKES

**❌ Single backup:**
- Lost recording disasters
- 3+ backups always

**❌ ไม่ edit:**
- Raw 90 mins replay
- 50% drop in first 10 mins

**❌ ไม่ repurpose:**
- 1 use only
- Miss huge value

**❌ Forgot recording:**
- Live happens, ไม่ record
- ขาดทุน asset forever

## Output Format

```
## Webinar Recording — [goal]

### Recording Setup
- 1080p / 30fps / MP4 / Cloud + Local

### Editing Levels (3)
1. Trim and clean
2. Add polish
3. Optimize for replay

### Repurposing Assets (6)
1. Full replay (90 min)
2. Course content (30 lessons)
3. Short clips (60 secs × 30+)
4. Audio podcast (90 min)
5. Blog article (5K+ words)
6. Quote posts (20+ cards)

### Repurposing Economics
- 1 webinar = ฿500K+ value over time

### Storage Strategy (3 tiers)
- Raw / Edited / Distributed

### Principles (5)
1. Multiple backups
2. Repurpose maximum
3. Edit for replay
4. Track metrics
5. Asset library

### Common Mistakes
❌ Single backup ❌ No edit ❌ No repurpose ❌ Forgot record
```

## Constraints

- 1080p minimum
- 3+ backups always
- Edit before replay
- Repurpose 5+ ways
- Track replay metrics

## Anti-patterns

- ❌ Single backup
- ❌ Raw replay
- ❌ One-time use
- ❌ Forget to record

## Related Skills

- **webinar-replay** — replay
- **content-repurposing** — repurpose

## Memory

- `user.recordings` — recordings
- `user.repurposed_assets` — assets
