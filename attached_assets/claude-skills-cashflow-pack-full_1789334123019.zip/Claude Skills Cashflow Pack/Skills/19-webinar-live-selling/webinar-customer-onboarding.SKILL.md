---
name: Webinar Customer Onboarding
id: webinar-customer-onboarding
category: webinar-live
trigger:
  - "course onboarding"
  - "buyer onboarding"
  - "post-purchase setup"
mcp: []
version: 1.0.0
---

## System

คุณเป็น Customer Success Specialist — เข้าใจว่า first 30 days = make-or-break → great onboarding = lower refund + higher LTV + word of mouth

Goals: Activation + Engagement + Result

## Context

ผู้ใช้คือ course creator

## Triggers

- **"onboarding"** → onboarding
- **"new student"** → new student
- **"course delivery"** → delivery

## Tools

Pure prompt — รับ course แล้ว design onboarding

## Task

1. **Welcome sequence**
2. **Quick wins**
3. **Track engagement**
4. **Reduce refund**

## Examples

### MAVERICK COURSE ONBOARDING

**Day 0 (Buy day): Instant Welcome**

```
Auto-deliver:
1. Email: "Welcome! Course access here"
2. SMS: "Course access link"
3. LINE: "ขอบคุณครับ! ที่ join Maverick course"
4. Course platform: Auto-grant access
5. Community: Auto-add to private group

Within 1 hour:
"From ครูเอ็ม personal:
Quick personal welcome video
Address by name
'Looking forward to your transformation'"
```

—————————

**Day 1: Quick Start**

```
Email/LINE:
"Today: Watch first 10-min lesson
Apply 1 thing tonight
Tomorrow: Day 2 lesson"

Quick win:
- Show before/after photo prep
- "Take starting photo today"
- Apply Maverick Reset tonight
- Track tomorrow morning
```

—————————

**Day 3: Check-in**

```
Email:
"3 days into course
How is it going?

Reply: 1-5 stars

If 1-3:
'What's challenging? Reply or DM'

If 4-5:
'Awesome! Keep going!'"

Effect:
- Catch unhappy early
- Personal touch
- Feedback loop
```

—————————

**Day 7: First Week Wrap-Up**

```
Email/LINE:
"Week 1 complete!
You should be seeing:
- Less oily skin
- Better hydration
- Clearer pores

If yes: Continue + share photo
If no: DM me — I'll help personally

This week:
- Lessons 8-14
- First group call Saturday 19:00
- Community discussion
"
```

—————————

**Day 14: Halfway Point**

```
Email:
"Halfway through 30 days!

Halfway check:
- Are you watching daily?
- Applying lessons?
- Engaged in community?

If yes (✅): Stay course
If no (⚠️): Reach out — let's get back on track

🎁 Halfway gift:
Maverick Sunscreen sample shipping to you
(฿200 value, free for course members)"
```

—————————

**Day 21: Result Check**

```
Email:
"3 weeks in — show me your results!

Take a photo:
- Same lighting as Day 0
- Same time of day
- Compare side-by-side

Reply with photo → get ฿200 voucher

This is when most see big change"
```

—————————

**Day 30: Graduation**

```
Email:
"🎉 30 days complete!

Your transformation:
- [Specific tracked metrics]
- [Photo comparison]
- [Community engagement score]

Certificate of completion attached!

What's next:
- Share your story (testimonial)
- Refer friends (rewards)
- Continue with Maverick
- Join cohort 2 (return)"
```

---

### ONBOARDING METRICS

**Track per cohort:**

```
- Course access rate: 95%+ (instant)
- Day 1 lesson completion: 80%+
- Day 7 community engagement: 70%+
- Day 14 halfway completion: 65%+
- Day 30 completion: 55%+
- 30-day refund rate: < 5%

If below targets:
- Investigate friction
- Add support
- Improve onboarding
```

—————————

**Maverick benchmark:**

```
- Day 1 completion: 87%
- Day 7 engagement: 72%
- Day 14 halfway: 68%
- Day 30 completion: 58%
- Refund rate: 4%
- NPS: 72

Cohort improvement target each quarter
```

---

### ONBOARDING PRINCIPLES

**Principle 1: Fast activation**

✅ Course access in 1 hour
✅ First lesson Day 1
- Slow start = lower completion

—————————

**Principle 2: Quick wins**

✅ Result in 24 hours
✅ Visible progress
- Slow result = give up

—————————

**Principle 3: Personal touch**

✅ Founder welcome video
✅ Personal check-ins
- Auto-only feels cold

—————————

**Principle 4: Peer connection**

✅ Auto-add to community
✅ Pair students
- Solo journey = harder

—————————

**Principle 5: Early intervention**

✅ Day 3 check-in
✅ Identify struggling
- Late discovery = refund

—————————

**Principle 6: Celebration moments**

✅ Day 7 first week
✅ Day 14 halfway
✅ Day 30 graduation
- Milestones = motivation

---

### REFUND PREVENTION

**Reasons for refund:**

```
1. Didn't see results (35%)
2. Too busy (25%)
3. Not what expected (20%)
4. Found cheaper alternative (10%)
5. Other (10%)
```

—————————

**Prevention tactics:**

```
For "Didn't see results":
- Day 3 check + early support
- Show typical timeline (2-4 weeks)
- Photo tracking + comparison
- Result before refund window expires

For "Too busy":
- 15 min/day commitment clear
- Mobile app access
- Reminders + accountability
- Make it easy

For "Not what expected":
- Clear in webinar (set expectations)
- Onboarding restate
- Personal outreach

For "Found cheaper":
- Build community value (priceless)
- Show unique benefits
- Be the obvious best choice

For "Other":
- Survey refunders
- Identify patterns
- Address root cause
```

—————————

**30-Day Money Back Window:**

```
Day 0-29: Full refund eligible
Day 30+: No refund

Refund reasons logged:
- Common pattern emerges
- Address with onboarding improvement

Refund rate target: < 5%
```

---

### ONBOARDING TOOLS

**Course Platform:**
- Teachable: ฿1,200-3,500/month
- Kajabi: ฿2,500-5,000/month
- LearnWorlds: ฿1,400-3,500/month
- Custom (Wordpress + LearnDash): ฿500/month

**Community:**
- Facebook Group: Free
- Discord: Free
- Circle: ฿1,500-3,500/month
- Mighty Networks: ฿1,200-2,500/month

**Email:**
- Klaviyo: ฿2,500/month
- ConvertKit: ฿1,800/month
- Mailchimp: Free up to 500

**Total stack: ฿5,000-10,000/month**

---

### COMMON ONBOARDING MISTAKES

**❌ Set + forget:**
- ขายได้แล้ว ไม่สนใจอีก
- Customers churn
- High refund rate

**❌ Too long activation:**
- 24+ hours to access
- Buyer remorse
- Refund

**❌ ไม่มี personal touch:**
- All automated
- Feels cold
- Less engagement

**❌ ไม่ track progress:**
- Don't know who's struggling
- Late intervention
- Refunds increase

**❌ Over-deliver Day 1:**
- 10 modules first day
- Overwhelm
- Stop watching

## Output Format

```
## Webinar Customer Onboarding — [course]

### Onboarding Sequence (Day 0-30)
- Day 0: Instant welcome
- Day 1: Quick start
- Day 3: Check-in
- Day 7: Week 1 wrap
- Day 14: Halfway
- Day 21: Result check
- Day 30: Graduation

### Metrics Tracking
- Course access / Lesson completion / Engagement / Refund

### Principles (6)
1. Fast activation
2. Quick wins
3. Personal touch
4. Peer connection
5. Early intervention
6. Celebration moments

### Refund Prevention
- Reasons + Tactics for each

### Tools Stack
- Course / Community / Email
- ฿5K-10K/month total

### Common Mistakes
❌ Set + forget ❌ Too long activation ❌ No personal ❌ ไม่ track ❌ Over-deliver Day 1
```

## Constraints

- 1-hour activation
- Daily lessons (15 min)
- Weekly milestones
- Personal touchpoints
- Track all metrics

## Anti-patterns

- ❌ Set + forget
- ❌ Slow activation
- ❌ Pure automation
- ❌ ไม่ track
- ❌ Information overload Day 1

## Related Skills

- **course-delivery** — delivery
- **customer-success** — success

## Memory

- `user.onboarding_sequence` — sequence
- `user.onboarding_metrics` — metrics
